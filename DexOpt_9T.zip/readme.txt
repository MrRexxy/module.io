Effect Blur (0) => ( Ubah Ke Nilai 1. Untuk Mengnonaktifkannya )
Kalau terasa lebih lag atau sering reload aplikasi, ubah ZRAM_SIZE_MB ke 2048 di config.conf, atau 0 untuk tidak mengubah zRAM.
Dexopt tidak akan langsung jalan. Charger Dulu Hpnya Baru Jalan DexOptnya. Biar Bisa Kerasa Hasilnya Tunggu 1-2 Hari.


Kalau terjadi bootloop, hapus folder modul di /data/adb/modules/ lewat TWRP atau mode aman.

Cek hasilnya di /data/local/tmp/lime_extra.log. Tunggu sekitar satu menit setelah boot. Baris OK berarti berhasil, dan SKIP berarti bagian itu tidak berlaku di ROM Anda.

Makasih Udah Make Modulenya.