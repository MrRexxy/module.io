#!/system/bin/sh
MODDIR=${0%/*}
LOG=/data/local/tmp/lime_extra.log
. "$MODDIR/config.conf"

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 45

echo "== Lime Extra Smooth $(date) ==" > "$LOG"

w() {
  if [ -w "$1" ]; then
    echo "$2" > "$1" 2>/dev/null && echo "OK   $1 = $2" >> "$LOG" || echo "FAIL $1" >> "$LOG"
  else
    echo "SKIP $1 (tidak ada/tidak writable)" >> "$LOG"
  fi
}

# ---------- Blur ----------
if [ "$DISABLE_BLUR" = "1" ]; then
  settings put global disable_window_blurs 1 && echo "OK   disable_window_blurs = 1" >> "$LOG"
fi

# ---------- zRAM ----------
Z=/sys/block/zram0
ZDEV=/dev/block/zram0
if [ "$ZRAM_SIZE_MB" -gt 0 ] 2>/dev/null && [ -d "$Z" ]; then
  want=$(( ZRAM_SIZE_MB * 1024 * 1024 ))
  cur=$(cat "$Z/disksize" 2>/dev/null)
  curalgo=$(sed 's/.*\[\(.*\)\].*/\1/' "$Z/comp_algorithm" 2>/dev/null)

  if [ "$cur" = "$want" ] && [ "$curalgo" = "$ZRAM_ALGO" ]; then
    echo "SKIP zram sudah sesuai ($ZRAM_SIZE_MB MB, $curalgo)" >> "$LOG"
  else
    st=0; sf=0; av=0
    while read k v u; do
      case $k in
        SwapTotal:) st=$v ;;
        SwapFree:) sf=$v ;;
        MemAvailable:) av=$v ;;
      esac
    done < /proc/meminfo
    used=$(( st - sf ))

    # Aman: hanya ubah ukuran jika swap terpakai < 60% RAM tersedia
    if [ "$used" -lt $(( av * 6 / 10 )) ]; then
      if swapoff "$ZDEV" 2>>"$LOG"; then
        echo 1 > "$Z/reset"
        if [ -w "$Z/comp_algorithm" ] && grep -qw "$ZRAM_ALGO" "$Z/comp_algorithm"; then
          echo "$ZRAM_ALGO" > "$Z/comp_algorithm"
        fi
        if echo "$want" > "$Z/disksize" 2>/dev/null; then
          echo "OK   zram disksize = $ZRAM_SIZE_MB MB, algo = $ZRAM_ALGO" >> "$LOG"
        else
          echo "$cur" > "$Z/disksize" 2>/dev/null
          echo "FAIL zram disksize, dikembalikan ke $cur" >> "$LOG"
        fi
        mkswap "$ZDEV" >> "$LOG" 2>&1 && swapon "$ZDEV" >> "$LOG" 2>&1 \
          && echo "OK   swapon zram0" >> "$LOG" || echo "FAIL swapon zram0" >> "$LOG"
      else
        echo "SKIP zram: swapoff gagal" >> "$LOG"
      fi
    else
      echo "SKIP zram: swap terpakai terlalu besar (${used} kB), coba lagi setelah reboot" >> "$LOG"
    fi
  fi
else
  echo "SKIP zram (dimatikan di config atau zram0 tidak ada)" >> "$LOG"
fi

[ "$SWAPPINESS" -gt 0 ] 2>/dev/null && w /proc/sys/vm/swappiness "$SWAPPINESS"
[ "$PAGE_CLUSTER" -ge 0 ] 2>/dev/null && w /proc/sys/vm/page-cluster "$PAGE_CLUSTER"

# ---------- Dexopt otomatis (latar belakang) ----------
if [ "$DEXOPT" = "1" ]; then
  (
    STAMP=/data/local/tmp/lime_extra.dexopt
    while true; do
      now=$(date +%s)
      last=$(cat "$STAMP" 2>/dev/null); [ -z "$last" ] && last=0
      if [ $(( now - last )) -ge $(( DEXOPT_INTERVAL_DAYS * 86400 )) ]; then
        bs=$(cat /sys/class/power_supply/battery/status 2>/dev/null)
        if [ "$bs" = "Charging" ] || [ "$bs" = "Full" ]; then
          if dumpsys power 2>/dev/null | grep -q "mWakefulness=Asleep"; then
            echo "$(date) dexopt mulai" >> "$LOG"
            cmd package compile -m speed-profile -a >> "$LOG" 2>&1
            date +%s > "$STAMP"
            echo "$(date) dexopt selesai" >> "$LOG"
          fi
        fi
      fi
      sleep 1800
    done
  ) &
  echo "OK   dexopt otomatis aktif (tiap $DEXOPT_INTERVAL_DAYS hari)" >> "$LOG"
fi

echo "== selesai (dexopt berjalan di latar belakang) ==" >> "$LOG"
