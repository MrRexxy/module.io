#!/system/bin/sh
settings delete global disable_window_blurs
rm -f /data/local/tmp/lime_extra.log /data/local/tmp/lime_extra.dexopt
# zRAM/swappiness kembali ke bawaan ROM setelah reboot
