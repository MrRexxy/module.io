#!/system/bin/sh
MODDIR=${0%/*}
SYS=${SYSROOT:-/sys}
. $MODDIR/common.sh
detect_all >/dev/null 2>&1
CONF=/data/adb/modulehub_universal_red.conf
BAT_TEMP_LIMIT_C=43; CPU_TEMP_LIMIT_C=80; MASTER=0; WATCHDOG=1
[ -f "$CONF" ] && . "$CONF"

if [ -d /data/adb/ap ]; then R="APatch"
elif [ -f /data/adb/ksud ] || [ -d /data/adb/ksu ]; then R="KernelSU"
elif command -v magisk >/dev/null 2>&1; then R="Magisk $(magisk -v 2>/dev/null | cut -d: -f1)"
else R="Tidak diketahui"; fi

MT=0; ST=0; SF=0
while read k v u; do case "$k" in MemTotal:) MT=$v ;; SwapTotal:) ST=$v ;; SwapFree:) SF=$v ;; esac; done < /proc/meminfo

echo "MODVER|$(grep '^version=' $MODDIR/module.prop | cut -d= -f2)"
echo "ROOT|$R"; echo "BRAND|$BRAND"; echo "MODEL|$MODEL"; echo "DEVICE|$DEVICE"
echo "CHIP|$CHIP"; echo "SOC|$SOCNAME"; echo "RAM|$((MT/1024))"; echo "ANDROID|$ANDROID|$SDK"; echo "KERNEL|$KERNEL"

avail() {
  f="$(cat $1/scaling_available_frequencies 2>/dev/null)"
  if [ -z "$f" ] && [ -f $1/stats/time_in_state ]; then while read a b; do f="$f $a"; done < $1/stats/time_in_state; fi
  echo $f
}
for p in $SYS/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  n="${p##*/}"
  cpus="$(cat $p/related_cpus 2>/dev/null | tr ' ' ',' | sed 's/,$//')"
  echo "CPU|$n|$cpus|$(cat $p/scaling_governor 2>/dev/null)|$(cat $p/scaling_cur_freq 2>/dev/null)|$(cat $p/scaling_min_freq 2>/dev/null)|$(cat $p/scaling_max_freq 2>/dev/null)|$(cat $p/cpuinfo_max_freq 2>/dev/null)"
  echo "CPUF|$n|$(avail $p)"
done

GP=""; [ -d $SYS/class/kgsl/kgsl-3d0/devfreq ] && GP="$SYS/class/kgsl/kgsl-3d0/devfreq"
for d in $SYS/class/devfreq/*; do [ -d "$d" ] || continue; case "$(lc "${d##*/}")" in *gpu*|*mali*|*kgsl*|*adreno*|*gpufreq*) GP="$GP $d" ;; esac; done
first=1
for g in $GP; do
  [ -f "$g/cur_freq" ] || continue
  hm=""; for f in $(cat $g/available_frequencies 2>/dev/null); do if [ -z "$hm" ] || [ "$f" -gt "$hm" ]; then hm=$f; fi; done
  nm="${g##*/}"; [ "$nm" = "devfreq" ] && nm="kgsl-3d0"
  echo "GPU|$nm|$(cat $g/cur_freq 2>/dev/null)|$(cat $g/min_freq 2>/dev/null)|$(cat $g/max_freq 2>/dev/null)|$(cat $g/governor 2>/dev/null)|$hm"
  if [ "$first" = 1 ]; then echo "GPUF|$nm|$(cat $g/available_frequencies 2>/dev/null)"; first=0; fi
done

echo "SWAP|$((ST/1024))|$(((ST-SF)/1024))"
Z=$SYS/block/zram0
if [ -d "$Z" ]; then ds=0; [ -f $Z/disksize ] && read ds < $Z/disksize
  echo "ZRAM|$((ds/1048576))|$(cat $Z/comp_algorithm 2>/dev/null | tr ' ' '\n' | grep '^\[' | tr -d '[]')"; fi
echo "SWAPPINESS|$(cat /proc/sys/vm/swappiness 2>/dev/null)"
echo "TCP|$(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null)"

bt=""
for f in $SYS/class/power_supply/battery/temp $SYS/class/power_supply/Battery/temp; do
  if [ -f "$f" ]; then read bt < "$f"; [ "$bt" -gt 150 ] 2>/dev/null && bt=$((bt/10)); break; fi
done
m=""
for z in $SYS/class/thermal/thermal_zone*; do
  [ -f "$z/type" ] || continue; read ty < "$z/type"
  case "$(lc "$ty")" in *cpu*|*tsens*|*soc*|*cluster*|*big*|*little*|*apc*) ;; *) continue ;; esac
  read v < "$z/temp" 2>/dev/null || continue
  case "$v" in ''|*[!0-9]*) continue ;; esac
  [ "$v" -gt 1000 ] && v=$((v/1000))
  if [ "$v" -gt 0 ] && [ "$v" -lt 150 ]; then if [ -z "$m" ] || [ "$v" -gt "$m" ]; then m=$v; fi; fi
done
echo "TEMP|$bt|$m"
echo "LIMITS|$BAT_TEMP_LIMIT_C|$CPU_TEMP_LIMIT_C|$MASTER|$WATCHDOG"
thr=0; [ -f /data/local/tmp/modulehub_red_state ] && read thr < /data/local/tmp/modulehub_red_state
sf=0; [ -f /data/adb/modulehub_red_safe ] && sf=1
pd=0; [ -f /data/adb/modulehub_red_pending ] && pd=1
sk=0; [ -f /data/adb/modulehub_red_strikes ] && read sk < /data/adb/modulehub_red_strikes
echo "STATE|$sf|${thr:-0}|$pd|${sk:-0}"
echo "SELINUX|$(getenforce 2>/dev/null)"
echo "VBS|$(getprop ro.boot.verifiedbootstate)|$(getprop ro.boot.flash.locked)|$(getprop ro.boot.slot_suffix)"
if [ -w $SYS/devices/system/cpu/cpu0/cpufreq/UV_mV_table ]; then echo "UVNODE|ada"; else echo "UVNODE|tidak ada"; fi
bc=0; [ -f /data/adb/modulehub_red_bootcount ] && read bc < /data/adb/modulehub_red_bootcount
echo "BOOTCNT|${bc:-0}"
if [ -f $MODDIR/disable ]; then echo "DISABLED|1"; else echo "DISABLED|0"; fi
