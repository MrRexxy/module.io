#!/system/bin/sh
LOG=/data/local/tmp/modulehub_universal_red.log
[ -f "$LOG" ] && cat "$LOG" || echo "Log belum ada. Reboot dulu."
