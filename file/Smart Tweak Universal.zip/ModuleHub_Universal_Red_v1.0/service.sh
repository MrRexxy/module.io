#!/system/bin/sh
MODDIR=${0%/*}
SYS=${SYSROOT:-/sys}
LOG=/data/local/tmp/modulehub_universal_red.log
CONF=/data/adb/modulehub_universal_red.conf
ORIG=/data/local/tmp/modulehub_red_orig
SELORIG=/data/local/tmp/modulehub_red_sel_orig
UVORIG=/data/local/tmp/modulehub_red_uv_orig
STATE=/data/local/tmp/modulehub_red_state
WDPID=/data/local/tmp/modulehub_red_wd.pid
PEND=/data/adb/modulehub_red_pending
STRK=/data/adb/modulehub_red_strikes
SAFE=/data/adb/modulehub_red_safe
CNT=/data/adb/modulehub_red_bootcount
WD_INTERVAL=${WD_INTERVAL:-10}

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
[ -f "$MODDIR/disable" ] && exit 0
[ -z "$NOWAIT" ] && sleep 45
echo 0 > "$CNT"   # boot selesai & stabil 45 dtk: reset bootloop guard

. $MODDIR/common.sh
MASTER=0; CPU_LOCK=off; GPU_LOCK=0; GPU_MAX_FREQ=default; UV_OFFSET_MV=0
SELINUX_PERMISSIVE=0; WATCHDOG=1; BAT_TEMP_LIMIT_C=43; CPU_TEMP_LIMIT_C=80
[ -f "$CONF" ] && . "$CONF"
detect_all

log() { echo "$*" >> $LOG; }
[ "$ACTION" = "revert" ] || echo "== $(date) ==" > $LOG

wr() { # wr nilai file  (menyimpan nilai asli sekali sebelum menulis)
  if [ ! -w "$2" ]; then log "SKIP $2"; return 1; fi
  grep -q "^$2|" $ORIG 2>/dev/null || echo "$2|$(cat $2)" >> $ORIG
  if echo "$1" > "$2" 2>/dev/null; then log "OK   $2 = $1"; return 0; fi
  log "FAIL $2"; return 1
}

avail_freqs() {
  f="$(cat $1/scaling_available_frequencies 2>/dev/null)"
  if [ -z "$f" ] && [ -f $1/stats/time_in_state ]; then
    while read a b; do f="$f $a"; done < $1/stats/time_in_state
  fi
  echo $f
}

read_bat_temp() {
  for f in $SYS/class/power_supply/battery/temp $SYS/class/power_supply/Battery/temp; do
    if [ -f "$f" ]; then
      read t < "$f"
      case "$t" in ''|*[!0-9]*) ;; *) [ "$t" -gt 150 ] && t=$((t/10)); echo "$t"; return ;; esac
    fi
  done
}
read_cpu_temp() {
  m=""
  for z in $SYS/class/thermal/thermal_zone*; do
    [ -f "$z/type" ] || continue
    read ty < "$z/type"
    case "$(lc "$ty")" in *cpu*|*tsens*|*soc*|*cluster*|*big*|*little*|*apc*) ;; *) continue ;; esac
    read v < "$z/temp" 2>/dev/null || continue
    case "$v" in ''|*[!0-9]*) continue ;; esac
    [ "$v" -gt 1000 ] && v=$((v/1000))
    if [ "$v" -gt 0 ] && [ "$v" -lt 150 ]; then
      if [ -z "$m" ] || [ "$v" -gt "$m" ]; then m=$v; fi
    fi
  done
  echo "$m"
}

# ---------- CPU / GPU / UV ----------
apply_perf() {
  maxhw=0; bigp=""
  for p in $SYS/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    hm="$(cat $p/cpuinfo_max_freq 2>/dev/null)"; [ -n "$hm" ] || continue
    if [ "$hm" -ge "$maxhw" ]; then maxhw=$hm; bigp=$p; fi
  done
  for p in $SYS/devices/system/cpu/cpufreq/policy*; do
    [ -d "$p" ] || continue
    n="${p##*/}"; up="$(echo $n | tr 'a-z' 'A-Z')"
    v=""; eval "v=\$CPU_MAX_$up"
    if [ -n "$v" ] && [ "$v" != "default" ]; then
      if has_word "$v" "$(avail_freqs $p)"; then
        smin="$(cat $p/scaling_min_freq 2>/dev/null)"
        [ -n "$smin" ] && [ "$v" -lt "$smin" ] && wr "$v" $p/scaling_min_freq
        wr "$v" $p/scaling_max_freq && CHANGED=1
      else log "$n: $v bukan OPP yang tersedia, dilewati"; fi
    fi
    dolock=0
    case "$CPU_LOCK" in all) dolock=1 ;; big) [ "$p" = "$bigp" ] && dolock=1 ;; esac
    if [ "$dolock" = 1 ]; then
      cap="$(cat $p/scaling_max_freq 2>/dev/null)"
      [ -n "$cap" ] && wr "$cap" $p/scaling_min_freq && CHANGED=1
    fi
  done

  GP=""
  [ -d $SYS/class/kgsl/kgsl-3d0/devfreq ] && GP="$SYS/class/kgsl/kgsl-3d0/devfreq"
  for d in $SYS/class/devfreq/*; do
    [ -d "$d" ] || continue
    case "$(lc "${d##*/}")" in *gpu*|*mali*|*kgsl*|*adreno*|*gpufreq*) GP="$GP $d" ;; esac
  done
  for g in $GP; do
    [ -f "$g/available_frequencies" ] || continue
    gf="$(cat $g/available_frequencies 2>/dev/null)"
    if [ "$GPU_MAX_FREQ" != "default" ] && [ -n "$GPU_MAX_FREQ" ]; then
      if has_word "$GPU_MAX_FREQ" "$gf"; then
        wr "$GPU_MAX_FREQ" $g/max_freq && CHANGED=1
      else log "GPU: $GPU_MAX_FREQ bukan OPP tersedia"; fi
    fi
    if [ "$GPU_LOCK" = "1" ]; then
      cap="$(cat $g/max_freq 2>/dev/null)"
      [ -n "$cap" ] && wr "$cap" $g/min_freq && CHANGED=1
    fi
    break   # hanya GPU utama
  done

  uv_apply
}

uv_apply() {
  [ "$UV_OFFSET_MV" -gt 0 ] 2>/dev/null || return
  n=$SYS/devices/system/cpu/cpu0/cpufreq/UV_mV_table
  [ -w "$n" ] || { log "UV: node UV_mV_table tidak ada, dilewati"; return; }
  [ "$UV_OFFSET_MV" -le 100 ] || { log "UV: maksimum 100 mV"; return; }
  orig=""; new=""
  while read a b c; do
    fq="${a%:}"
    case "$fq" in ''|*[!0-9]*) log "UV: format tabel tidak dikenal, dibatalkan"; return ;; esac
    case "$b" in ''|*[!0-9]*) log "UV: format tabel tidak dikenal, dibatalkan"; return ;; esac
    nv=$((b - UV_OFFSET_MV))
    [ "$nv" -ge 600 ] || { log "UV: tegangan < 600 mV, dibatalkan"; return; }
    orig="$orig $b"; new="$new $nv"
  done < "$n"
  [ -n "$orig" ] || return
  [ -s "$UVORIG" ] || echo $orig > "$UVORIG"
  if echo $new > "$n" 2>/dev/null; then CHANGED=1; log "UV: -${UV_OFFSET_MV} mV diterapkan"; else log "UV: gagal menulis"; fi
}

revert_perf() {
  if [ -s "$ORIG" ]; then
    while IFS='|' read p v; do case "$p" in *min_freq) echo "$v" > "$p" 2>/dev/null ;; esac; done < "$ORIG"
    while IFS='|' read p v; do case "$p" in *min_freq) ;; *) echo "$v" > "$p" 2>/dev/null ;; esac; done < "$ORIG"
    : > "$ORIG"; log "revert: CPU/GPU dikembalikan ke nilai awal"
  fi
  if [ -s "$UVORIG" ]; then
    echo $(cat "$UVORIG") > $SYS/devices/system/cpu/cpu0/cpufreq/UV_mV_table 2>/dev/null
    : > "$UVORIG"; log "revert: undervolt dikembalikan"
  fi
}
apply_sel() {
  [ "$SELINUX_PERMISSIVE" = "1" ] || return
  if [ "$(getenforce 2>/dev/null)" = "Enforcing" ]; then
    echo Enforcing > "$SELORIG"
    setenforce 0 && { CHANGED=1; log "SELinux -> Permissive (keamanan turun, Play Integrity bisa gagal)"; }
  fi
}
revert_sel() {
  if [ -s "$SELORIG" ]; then setenforce 1 2>/dev/null; : > "$SELORIG"; log "revert: SELinux -> Enforcing"; fi
}

stop_wd() {
  if [ -f "$WDPID" ]; then read pid < "$WDPID"; [ -n "$pid" ] && kill "$pid" 2>/dev/null; rm -f "$WDPID"; fi
}

watchdog() {
  thr=0; ev=0
  while :; do
    sleep $WD_INTERVAL
    bt="$(read_bat_temp)"; ct="$(read_cpu_temp)"
    over=0
    [ -n "$bt" ] && [ "$bt" -ge "$BAT_TEMP_LIMIT_C" ] && over=1
    [ -n "$ct" ] && [ "$ct" -ge "$CPU_TEMP_LIMIT_C" ] && over=1
    if [ "$thr" = 0 ]; then
      if [ "$over" = 1 ]; then
        revert_perf; thr=1; ev=$((ev+1)); echo 1 > $STATE
        log "WATCHDOG: bat=${bt}C cpu=${ct}C melewati batas -> kembali ke bawaan (kejadian $ev)"
      fi
    else
      cool=1
      [ -n "$bt" ] && [ "$bt" -gt $((BAT_TEMP_LIMIT_C - 5)) ] && cool=0
      [ -n "$ct" ] && [ "$ct" -gt $((CPU_TEMP_LIMIT_C - 10)) ] && cool=0
      if [ "$cool" = 1 ]; then
        if [ "$ev" -lt 3 ]; then apply_perf; thr=0; echo 0 > $STATE; log "WATCHDOG: suhu turun, diterapkan lagi"
        else log "WATCHDOG: 3x overheat, tetap bawaan sampai reboot"; break; fi
      fi
    fi
  done
}

# ---------------- alur utama ----------------
if [ "$ACTION" = "revert" ]; then
  stop_wd; revert_perf; revert_sel; rm -f "$PEND"; echo 0 > $STATE
  log "== revert manual $(date) =="; exit 0
fi

[ -z "$NOWAIT" ] && { : > "$ORIG"; : > "$SELORIG"; : > "$UVORIG"; }   # saat boot nilai sudah bawaan
echo "brand=$BRAND model=$MODEL chip=$CHIP soc=$SOCNAME" >> $LOG
stop_wd; revert_perf; revert_sel; echo 0 > $STATE

if [ -f "$SAFE" ]; then
  log "SAFE MODE aktif (sesi sebelumnya tidak stabil). Tidak ada perubahan diterapkan. Bersihkan lewat WebUI > Alat."
  exit 0
fi
if [ "$MASTER" != "1" ]; then log "MASTER=0, tidak ada perubahan berisiko diterapkan."; exit 0; fi

if [ "$WATCHDOG" = "1" ] && [ -z "$(read_bat_temp)" ]; then
  log "ABORT: sensor suhu baterai tidak terbaca, fitur berisiko tidak diterapkan (watchdog tidak bisa melindungi)."
  exit 0
fi

CHANGED=0
apply_perf
apply_sel
if [ "$CHANGED" = "1" ]; then
  date +%s > "$PEND"
  ( sleep ${STABLE_SECS:-600}; rm -f "$PEND"; echo 0 > "$STRK" ) >/dev/null 2>&1 &
  if [ "$WATCHDOG" = "1" ]; then
    ( watchdog ) >/dev/null 2>&1 &
    echo $! > "$WDPID"; log "watchdog aktif (bat<${BAT_TEMP_LIMIT_C}C, cpu<${CPU_TEMP_LIMIT_C}C)"
  else log "PERINGATAN: watchdog dimatikan pengguna"; fi
else
  log "tidak ada perubahan yang diterapkan"
fi
log "selesai"
