#!/system/bin/sh
# Cek kesiapan: CHK|level|judul|detail   (level: ok warn bad info)
MODDIR=${0%/*}
SYS=${SYSROOT:-/sys}
. $MODDIR/common.sh
detect_all >/dev/null 2>&1
c() { echo "CHK|$1|$2|$3"; }

vbs="$(getprop ro.boot.verifiedbootstate)"; lk="$(getprop ro.boot.flash.locked)"; dst="$(getprop ro.boot.vbmeta.device_state)"
if [ "$lk" = "0" ] || [ "$vbs" = "orange" ] || [ "$dst" = "unlocked" ]; then c ok "Bootloader" "Unlocked (verifiedbootstate=${vbs:-?})"
elif [ "$lk" = "1" ] || [ "$dst" = "locked" ]; then c warn "Bootloader" "Terdeteksi LOCKED. Flash kernel/vbmeta lewat fastboot tidak akan bisa"
else c info "Bootloader" "Status tidak terbaca (verifiedbootstate=${vbs:-?})"; fi
c info "dm-verity / AVB" "veritymode=$(getprop ro.boot.veritymode) avb=$(getprop ro.boot.avb_version) slot=$(getprop ro.boot.slot_suffix)"

BK=0; for d in /sdcard/ModuleHub_Backup /data/media/0/ModuleHub_Backup; do [ -d "$d" ] && BK=$(ls "$d" 2>/dev/null | wc -l) && break; done
if [ "$BK" -gt 0 ]; then c ok "Backup partisi" "$BK set backup ditemukan di ModuleHub_Backup"
else c bad "Backup partisi" "BELUM ada. Buka tab Alat > Backup partisi sebelum mengaktifkan fitur merah"; fi

fr=0; set -- $(df -k /data 2>/dev/null | tail -1); [ -n "$4" ] && fr=$(($4/1024))
if [ "$fr" -ge 500 ]; then c ok "Ruang /data" "${fr} MB bebas"; else c warn "Ruang /data" "hanya ${fr} MB bebas (butuh >= 500 MB untuk backup)"; fi
bl=""; [ -f $SYS/class/power_supply/battery/capacity ] && read bl < $SYS/class/power_supply/battery/capacity
if [ -n "$bl" ]; then if [ "$bl" -ge 40 ]; then c ok "Baterai" "${bl}%"; else c warn "Baterai" "${bl}% (isi >= 40% sebelum eksperimen)"; fi; fi
bt=""; [ -f $SYS/class/power_supply/battery/temp ] && read bt < $SYS/class/power_supply/battery/temp
if [ -n "$bt" ]; then [ "$bt" -gt 150 ] && bt=$((bt/10)); if [ "$bt" -lt 40 ]; then c ok "Suhu baterai" "${bt}C"; else c warn "Suhu baterai" "${bt}C terlalu panas untuk eksperimen"; fi
else c bad "Sensor suhu baterai" "tidak terbaca: watchdog tidak bisa bekerja, fitur berisiko akan ditolak"; fi
nz=0; for z in $SYS/class/thermal/thermal_zone*; do [ -d "$z" ] && nz=$((nz+1)); done
c info "Thermal zone" "$nz zona (thermal sistem TIDAK dimatikan modul ini)"

for p in $SYS/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  n="${p##*/}"; f="$(cat $p/scaling_available_frequencies 2>/dev/null)"; cnt=0; top=0
  for x in $f; do cnt=$((cnt+1)); [ "$x" -gt "$top" ] && top=$x; done
  [ -w "$p/scaling_max_freq" ] && w="bisa ditulis" || w="TIDAK bisa ditulis"
  if [ "$cnt" -gt 0 ]; then c info "CPU $n" "$cnt OPP, tertinggi $((top/1000)) MHz, $w. Jika kernel OC, OPP ekstra muncul di sini"
  else c warn "CPU $n" "daftar OPP tidak tersedia, $w"; fi
done
[ -d $SYS/devices/system/cpu/cpufreq ] || c warn "cpufreq" "folder cpufreq tidak ada (kernel tidak membuka kontrol frekuensi)"

GP=""; [ -d $SYS/class/kgsl/kgsl-3d0/devfreq ] && GP="$SYS/class/kgsl/kgsl-3d0/devfreq"
for d in $SYS/class/devfreq/*; do [ -d "$d" ] || continue; case "$(lc "${d##*/}")" in *gpu*|*mali*|*kgsl*|*adreno*|*gpufreq*) GP="$GP $d" ;; esac; done
if [ -n "$GP" ]; then c ok "GPU devfreq" "ditemukan: $(echo $GP | cut -d' ' -f1)"; else c info "GPU devfreq" "tidak ditemukan, kontrol GPU dilewati"; fi

if [ -w $SYS/devices/system/cpu/cpu0/cpufreq/UV_mV_table ]; then c ok "Undervolt" "UV_mV_table tersedia (kernel mendukung)"; else c info "Undervolt" "tidak tersedia di kernel ini (normal untuk kernel stok)"; fi
c info "SELinux" "$(getenforce 2>/dev/null) (permissive menurunkan keamanan, tidak diperlukan untuk modul ini)"
c info "Kernel" "$KERNEL"
[ -f /data/adb/modulehub_red_safe ] && c bad "Safe mode" "AKTIF: sesi sebelumnya tidak stabil. Bersihkan di tab Alat" || c ok "Safe mode" "tidak aktif"
