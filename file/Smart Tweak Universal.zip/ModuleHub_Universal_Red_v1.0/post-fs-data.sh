#!/system/bin/sh
MODDIR=${0%/*}
CNT=/data/adb/modulehub_red_bootcount
PEND=/data/adb/modulehub_red_pending
STRK=/data/adb/modulehub_red_strikes
SAFE=/data/adb/modulehub_red_safe

# 1) Bootloop guard: 3x boot berturut-turut tidak selesai -> modul dimatikan
n=0; [ -f "$CNT" ] && read n < "$CNT"
n=$((n+1)); echo "$n" > "$CNT"
if [ "$n" -ge 3 ]; then touch "$MODDIR/disable"; rm -f "$CNT"; fi

# 2) Stability guard: sesi sebelumnya menerapkan fitur berisiko tapi tidak bertahan 10 menit
if [ -f "$PEND" ]; then
  s=0; [ -f "$STRK" ] && read s < "$STRK"
  s=$((s+1)); echo "$s" > "$STRK"; rm -f "$PEND"
  [ "$s" -ge 2 ] && touch "$SAFE"
fi
