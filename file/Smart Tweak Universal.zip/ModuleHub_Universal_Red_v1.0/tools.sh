#!/system/bin/sh
case "$1" in
  clearsafe) rm -f /data/adb/modulehub_red_safe /data/adb/modulehub_red_pending; echo 0 > /data/adb/modulehub_red_strikes; echo "safe mode dibersihkan" ;;
  *) echo "pakai: tools.sh clearsafe" ;;
esac
