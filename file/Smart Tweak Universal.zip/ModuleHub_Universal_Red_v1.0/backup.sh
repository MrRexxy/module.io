#!/system/bin/sh
# Backup partisi penting ke /sdcard/ModuleHub_Backup/<waktu>. Output: BK|nama|status|detail
DEST_ROOT=/sdcard/ModuleHub_Backup
[ -w /sdcard ] || DEST_ROOT=/data/media/0/ModuleHub_Backup
TS="$(date +%Y%m%d-%H%M%S)"
DEST="$DEST_ROOT/$TS"
mkdir -p "$DEST" 2>/dev/null || { echo "BK|-|gagal|tidak bisa membuat $DEST"; exit 1; }

BYNAME=""
for d in /dev/block/by-name /dev/block/bootdevice/by-name /dev/block/platform/*/by-name /dev/block/platform/*/*/by-name; do
  [ -d "$d" ] && { BYNAME="$d"; break; }
done
[ -n "$BYNAME" ] || { echo "BK|-|gagal|folder by-name tidak ditemukan"; exit 1; }
SLOT="$(getprop ro.boot.slot_suffix)"

set -- $(df -k "$DEST" 2>/dev/null | tail -1); FREE_MB=$(( ${4:-0} / 1024 ))
n=0
for part in boot init_boot vendor_boot dtbo vbmeta vbmeta_system recovery; do
  dev=""
  for cand in "$BYNAME/${part}${SLOT}" "$BYNAME/$part"; do [ -e "$cand" ] && { dev="$cand"; break; }; done
  [ -n "$dev" ] || continue
  real="$(readlink -f "$dev")"; base="${real##*/}"
  sz=0; [ -f "/sys/class/block/$base/size" ] && read sz < "/sys/class/block/$base/size"
  mb=$(( sz / 2048 + 1 ))
  if [ "$mb" -gt "$((FREE_MB - 100))" ]; then echo "BK|$part|lewati|ruang tidak cukup (butuh ${mb}MB, bebas ${FREE_MB}MB)"; continue; fi
  if dd if="$dev" of="$DEST/$part.img" bs=1048576 2>/dev/null && [ -s "$DEST/$part.img" ]; then
    sum="$(sha256sum "$DEST/$part.img" 2>/dev/null | cut -d' ' -f1)"
    echo "$sum  $part.img" >> "$DEST/SHA256SUMS.txt"
    short="$(echo "$sum" | cut -c1-8)"
    echo "BK|$part|ok|${mb}MB sha256=${short}"
    n=$((n+1)); FREE_MB=$((FREE_MB - mb))
  else
    rm -f "$DEST/$part.img"; echo "BK|$part|gagal|dd gagal"
  fi
done
echo "BKDIR|$DEST|$n"
