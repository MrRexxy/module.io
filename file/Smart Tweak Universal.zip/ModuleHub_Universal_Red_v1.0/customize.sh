#!/system/bin/sh
SKIPUNZIP=0
. $MODPATH/common.sh
detect_all
if [ "$KSU" = "true" ]; then ROOTIMPL="KernelSU ${KSU_VER:-}"
elif [ "$APATCH" = "true" ]; then ROOTIMPL="APatch ${APATCH_VER:-}"
else ROOTIMPL="Magisk ${MAGISK_VER:-}"; fi
ui_print "======================================"
ui_print "  ModuleHub Universal Pro (RED) v1.0"
ui_print "======================================"
ui_print "- Root    : $ROOTIMPL"
ui_print "- Merk    : $BRAND | $MODEL ($DEVICE)"
ui_print "- Chipset : $CHIP ($SOCNAME) | RAM ${RAM_MB}MB"
ui_print ""
ui_print "! ZONA MERAH. Semua fitur berisiko OFF secara default."
ui_print "! Langkah aman: buka WebUI > Alat > Cek kesiapan,"
ui_print "! lalu Backup partisi, baru aktifkan fitur satu per satu."
ui_print "! Pengaman: watchdog suhu, stability guard, bootloop guard."

CONF=/data/adb/modulehub_universal_red.conf
if [ ! -f "$CONF" ]; then
cat > "$CONF" <<'CFG'
# ModuleHub Universal Pro (Red). Ubah lewat WebUI atau edit di sini.
# MASTER=0 berarti tidak ada perubahan berisiko yang diterapkan.
MASTER=0
CPU_LOCK="off"
GPU_LOCK=0
GPU_MAX_FREQ="default"
UV_OFFSET_MV=0
SELINUX_PERMISSIVE=0
WATCHDOG=1
BAT_TEMP_LIMIT_C=43
CPU_TEMP_LIMIT_C=80
# Frekuensi maksimum per cluster: CPU_MAX_POLICYn="default" atau angka kHz (harus ada di daftar OPP)
CFG
ui_print "- Config dibuat: $CONF"
fi

set_perm_recursive $MODPATH 0 0 0755 0644
for f in service.sh post-fs-data.sh action.sh common.sh status.sh setcfg.sh check.sh backup.sh tools.sh; do set_perm $MODPATH/$f 0 0 0755; done
ui_print "- WebUI   : tersedia (buka dari manager setelah reboot)"
ui_print "- Selesai. Reboot."
