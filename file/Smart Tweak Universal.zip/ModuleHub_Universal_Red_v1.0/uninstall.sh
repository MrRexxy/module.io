#!/system/bin/sh
rm -f /data/local/tmp/modulehub_universal_red.log /data/local/tmp/modulehub_red_* /data/adb/modulehub_red_*
