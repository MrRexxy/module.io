#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done

setprop debug.hwui.renderer vulkan
setprop persist.sys.ui.hwc vds
setprop ro.hardware.vulkan adreno