#!/system/bin/sh
resetprop --delete debug.hwui.renderer
resetprop --delete persist.sys.ui.hwc
resetprop --delete ro.hardware.vulkan