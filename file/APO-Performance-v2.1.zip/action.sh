#!/system/bin/sh
MODDIR=${0%/*}
CFG=/data/local/tmp/apo_performance
if grep -q '^enabled=1' "$CFG/settings.conf" 2>/dev/null; then
  MODDIR=$MODDIR sh "$MODDIR/core.sh" disable >/dev/null
  echo "APO Performance: OFF  - everything restored"
else
  MODDIR=$MODDIR sh "$MODDIR/core.sh" enable >/dev/null
  echo "APO Performance: ON"
fi
echo "Open the WebUI for every function."
