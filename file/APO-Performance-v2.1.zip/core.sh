#!/system/bin/sh
# APO Performance - core
# ADB only (shell uid). No root. Performance first, battery-aware: nothing polls while the screen is off
# except a slow 60 s check, heavy jobs only run while charging. Every change saves the
# original value once and restores it exactly when the function is turned off or removed.

MODDIR=${MODDIR:-${0%/*}}
CFG=/data/local/tmp/apo_performance   # outside the module dir: survives updates
[ -n "$APO_CFG" ] && CFG=$APO_CFG
BK=$CFG/bk          # global backups: one file per key, holds the original value
GBK=$CFG/gbk        # in-game backups (reverted when the game closes)
TBK=$CFG/tbk        # thermal backups (reverted when it cools down)
SET=$CFG/settings.conf
GAMES=$CFG/games.conf
LOG=$CFG/engine.log
mkdir -p "$BK" "$GBK" "$TBK"

# ---------------------------------------------------------------- defaults
# mode: off | balance | perf | extreme | custom   (enabled is derived from mode)
DEFAULTS='enabled=0
mode=off
turbo=1
touch=1
renderer=keep
smarthz=1
ram=1
maint=1
hidden=1
dns=off
gameauto=1
gamednd=0
hibernate=0
thermal=1
lang=auto'

KNOWN_GAMES='com.dts.freefireth com.dts.freefiremax com.activision.callofduty.shooter com.garena.game.codm com.tencent.ig com.pubg.imobile com.pubg.krmobile com.vng.pubgmobile com.rekoo.pubgm com.tencent.tmgp.pubgmhd com.mobile.legends com.mobiin.gp com.riotgames.league.wildrift com.levelinfinite.sgameGlobal com.tencent.tmgp.sgame com.pokemon.unite com.supercell.brawlstars com.supercell.clashofclans com.supercell.clashroyale com.gameloft.android.ANMP.GloftA9HM com.konami.pesam jp.konami.pesam com.ea.gp.fifamobile com.miHoYo.GenshinImpact com.HoYoverse.hkrpgoversea com.kurogame.wutheringwaves.global com.roblox.client com.mojang.minecraftpe com.netease.newspike com.proximabeta.mf.uamo com.farlightgames.farlight84.gp com.YoStarEN.Arknights com.gravity.romg com.ngame.allstar.eu com.tencent.lolm com.blizzard.diablo.immortal com.carxtech.sr com.firsttouchgames.dls7 com.criticalforceentertainment.criticalops com.axlebolt.standoff2 com.innersloth.spacemafia com.kiloo.subwaysurf com.imangi.templerun2 com.sega.pjsekai com.hypergryph.arknights com.garena.game.df com.netease.idv.googleplay com.blueteam.bloodstrike'

cfg_init() {
  [ -f "$CFG/.init2" ] && [ -f "$SET" ] && [ -f "$GAMES" ] && return 0
  [ -f "$SET" ] || echo "$DEFAULTS" > "$SET"
  echo "$DEFAULTS" | while IFS='=' read -r k v; do
    grep -q "^$k=" "$SET" || echo "$k=$v" >> "$SET"
  done
  [ -f "$GAMES" ] || touch "$GAMES"
  rm -f "$CFG"/.init*; touch "$CFG/.init2"
}
get() { grep -m1 "^$1=" "$SET" 2>/dev/null | cut -d= -f2-; }
put() {
  case "$1" in *[!a-z0-9_]*|'') return 1;; esac
  case "$2" in *[!A-Za-z0-9._-]*) return 1;; esac
  if grep -q "^$1=" "$SET"; then
    sed -i "s|^$1=.*|$1=$2|" "$SET"
  else
    echo "$1=$2" >> "$SET"
  fi
}
on() { [ "$(get "$1")" = 1 ]; }
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; [ "$(wc -l < "$LOG")" -gt 400 ] && sed -i '1,200d' "$LOG"; }
sdk() { getprop ro.build.version.sdk; }

# ---------------------------------------------------------------- backup helpers
# id = file name in backup dir; type: s:<ns>:<key> | p:<prop> | d:<ns>:<key> | u:night | l:logd | z:dnd
_read() {
  case "$1" in
    s:*) set -- $(echo "$1" | tr ':' ' '); settings get "$2" "$3" 2>/dev/null ;;
    p:*) getprop "${1#p:}" ;;
    d:*) set -- $(echo "$1" | tr ':' ' '); device_config get "$2" "$3" 2>/dev/null ;;
    u:night) cmd uimode night 2>/dev/null | awk '{print $NF}' ;;
    l:logd) logcat -g -b main 2>/dev/null | grep -oE '[0-9]+ ?[KM]i?B' | head -1 | tr -d ' i' | sed 's/B$//' ;;
    b:saver) settings get global low_power 2>/dev/null ;;
    f:fixed) cat "$CFG/fixed_state" 2>/dev/null || echo false ;;
    z:dnd) case "$(settings get global zen_mode 2>/dev/null)" in 1) echo priority;; 2) echo none;; 3) echo alarms;; *) echo off;; esac ;;
  esac
}
_write() { # $1 type, $2 value ("null"/"" means delete)
  local t="$1" v="$2"
  case "$t" in
    s:*) set -- $(echo "$t" | tr ':' ' ')
         if [ "$v" = null ] || [ -z "$v" ]; then settings delete "$2" "$3" >/dev/null 2>&1
         else settings put "$2" "$3" "$v" >/dev/null 2>&1; fi ;;
    p:*) setprop "${t#p:}" "$v" >/dev/null 2>&1 ;;
    d:*) set -- $(echo "$t" | tr ':' ' ')
         if [ "$v" = null ] || [ -z "$v" ]; then device_config delete "$2" "$3" >/dev/null 2>&1
         else device_config put "$2" "$3" "$v" >/dev/null 2>&1; fi ;;
    u:night) [ -n "$v" ] && cmd uimode night "$v" >/dev/null 2>&1 ;;
    l:logd) [ -n "$v" ] && logcat -G "$v" >/dev/null 2>&1 ;;
    b:saver) case "$v" in 1) cmd power set-mode 1 >/dev/null 2>&1;; *) cmd power set-mode 0 >/dev/null 2>&1;; esac ;;
    f:fixed) cmd power set-fixed-performance-mode-enabled "${v:-false}" >/dev/null 2>&1; echo "${v:-false}" > "$CFG/fixed_state" ;;
    z:dnd) cmd notification set_dnd "${v:-off}" >/dev/null 2>&1 ;;
  esac
}
_fn() { echo "$1" | tr ':/' '__'; }
# set with backup: dir type value
bset() {
  local f="$1/$(_fn "$2")"
  [ -f "$f" ] || { printf '%s\n%s' "$2" "$(_read "$2")" > "$f"; }
  _write "$2" "$3"
}
# restore one: dir type
brestore() {
  local f="$1/$(_fn "$2")"
  [ -f "$f" ] || return 0
  _write "$2" "$(sed -n 2p "$f")"
  rm -f "$f"
}
brestore_all() {
  for f in "$1"/*; do
    [ -f "$f" ] || continue
    _write "$(sed -n 1p "$f")" "$(sed -n 2p "$f")"
    rm -f "$f"
  done
}


# ---------------------------------------------------------------- device info
max_hz() {
  [ -s "$CFG/maxhz" ] && { cat "$CFG/maxhz"; return; }
  _max_hz | tee "$CFG/maxhz"
}
_max_hz() {
  dumpsys display 2>/dev/null | grep -oE '(fps|refreshRate|renderFrameRate)=[0-9]+(\.[0-9]+)?' \
    | cut -d= -f2 | awk 'BEGIN{m=60}{v=int($1+0.5); if(v>m && v<=240)m=v}END{print m}'
}
phys_size() {
  [ -s "$CFG/physsize" ] && { cat "$CFG/physsize"; return; }
  wm size 2>/dev/null | grep -m1 Physical | grep -oE '[0-9]+x[0-9]+' | tee "$CFG/physsize"
}
gpu_str() {
  local g
  g=$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES:' | sed 's/.*GLES: *//')
  [ -z "$g" ] && g="$(getprop ro.hardware.egl) $(getprop ro.board.platform)"
  echo "$g" | tr -d '"\\'
}
gpu_vendor() {
  case "$(gpu_str)" in
    *Adreno*|*Qualcomm*) echo adreno ;;
    *Immortalis*|*Mali*|*ARM*) echo mali ;;
    *PowerVR*|*Imagination*) echo powervr ;;
    *Xclipse*|*Samsung*) echo xclipse ;;
    *) echo other ;;
  esac
}
ram_gb() { awk '/MemTotal/{printf "%d", ($2/1048576)+0.5}' /proc/meminfo; }
tier() {
  local g r; g="$(gpu_str)"; r=$(ram_gb)
  [ "${r:-4}" -lt 4 ] && { echo low; return; }
  case "$g" in
    *Mali-T*|*Mali-G31*|*Mali-G51*|*Mali-G52*|*Mali-G57*|*Mali-G68*|*PowerVR*GE8*|*PowerVR*Rogue*|*"Adreno (TM) 3"*|*"Adreno (TM) 4"*|*"Adreno (TM) 5"*|*"Adreno (TM) 60"*|*"Adreno (TM) 61"*) echo low ;;
    *"Adreno (TM) 7"[3-9]*|*"Adreno (TM) 8"*|*Immortalis*|*Mali-G7[1-9]*|*Mali-G7[1-9]0*|*Mali-G6[1-9]0*|*Xclipse*|*Mali-G720*|*Mali-G925*) echo high ;;
    *) echo mid ;;
  esac
}
recommended_renderer() {
  case "$(gpu_vendor)" in
    adreno|xclipse) echo skiavk ;;
    mali) [ "$(tier)" = low ] && echo skiagl || echo skiavk ;;
    *) echo skiagl ;;
  esac
}


mem_free() { awk '/MemTotal/{t=$2}/MemAvailable/{a=$2}END{if(t) printf "%d", a*100/t}' /proc/meminfo; }
bat() { dumpsys battery 2>/dev/null; }
charging() { bat | grep -qE '(AC|USB|Wireless) powered: true'; }
screen_on() { dumpsys power 2>/dev/null | grep -q 'mWakefulness=Awake'; }
thermal_status() { dumpsys thermalservice 2>/dev/null | grep -m1 'Thermal Status' | grep -oE '[0-9]+'; }
fg_pkg() {
  dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' \
    | grep -oE '[A-Za-z0-9_.]+/' | head -1 | tr -d '/'
}

# ---------------------------------------------------------------- games
games_list() { awk 'NF{print $1}' "$GAMES"; }
game_add() {
  case "$1" in *[!A-Za-z0-9._]*|'') return 1;; esac
  grep -q "^$1\( \|$\)" "$GAMES" || echo "$1" >> "$GAMES"
}
game_del() {
  case "$1" in *[!A-Za-z0-9._]*|'') return 1;; esac
  cmd game mode standard "$1" >/dev/null 2>&1
  sed -i "/^$1\( \|$\)/d" "$GAMES"
}
# ---- game detection (no root): known list > publisher/engine name > engine libs inside the APK
GAME_PAT='game|games|gameloft|supercell|tencent|garena|netease|mihoyo|hoyoverse|miniclip|activision|ubisoft|com\.ea\.|electronicarts|\.king\.|rovio|zynga|playrix|voodoo|outfit7|kiloo|imangi|nexon|square_?enix|bandainamco|sega|konami|lilith|moonton|mobile\.legends|yostar|funplus|ngame|roblox|mojang|dts\.|levelinfinite|proximabeta|krafton|pubg|riotgames|blizzard|bethesda|epicgames|scopely|playtika|moonactive|kabam|netmarble|ncsoft|com2us|gamevil|devsisters|smilegate|kurogame|hypergryph|papergames|farlight|habby|ketchapp|crazylabs|saygames|azurgames|amanotes|bigfish|glu\.|gameinsight|tapblaze|dreamgames|peak\.|socialpoint|naturalmotion|frogmind|dotemu|herocraft|rockstargames|take2|2k\.|wb\.|unity3d|criticalforce|axlebolt|carxtech|firsttouch|innersloth|chess|sudoku|solitaire|puzzle|racing|shooter|soccer|football|basket|minecraft|craft|clash|battle|arena|legends|ludo|domino|poker|casino|slots'
NOT_GAME_PAT='launcher|keyboard|inputmethod|wallpaper|theme|gallery|camera|browser|whatsapp|telegram|instagram|facebook|messenger|tiktok|youtube|spotify|netflix|bank|wallet|paypal|bradesco|itau|nubank|caixa|santander|bancointer|picpay|mercadopago|ifood|uber|99app|maps|waze|translate|vpn|cleaner|antivirus|recorder|gamebooster|gameturbo|gamespace|gamecenter|gameassistant|gamelauncher|com\.google\.android\.play\.games|axeron|axmanager|shizuku|termux|stream|discord|twitch'
ENGINE_PAT='libunity.so libil2cpp.so libUE4.so libUnreal.so libUnrealEngine libcocos2d libcocos2dcpp.so libcocos2djs.so libgodot_android.so libgdx.so libxlua.so libtolua.so libslua.so libSDL2.so libfmod.so libAkSoundEngine.so libyoyo.so librenpy libdefold libMyGame.so libgame.so assets/bin/Data/ libtersafe libanogs.so libgcloud.so libGameCore'
GCACHE="$CFG/gamecache"
ENGINE_ARGS=$(for e in $ENGINE_PAT; do printf "%s %s " -e "$e"; done)
is_game() { # pkg [base.apk] -> 0 game / 1 not
  local p="$1" paths key hit=0 a
  echo " $KNOWN_GAMES " | grep -q " $p " && return 0
  if [ -n "$2" ]; then paths="$2"; else paths=$(pm path "$p" 2>/dev/null | sed 's/^package://' | head -1); fi
  [ -n "$paths" ] || return 1
  key="$p $paths"
  a=${paths%/*}; for a in "$a"/split_config.arm64*.apk "$a"/split_config.armeabi*.apk "$a"/split_*.apk; do [ -f "$a" ] && case " $paths " in *" $a "*) ;; *) paths="$paths $a";; esac; done
  [ -f "$GCACHE" ] && a=$(grep -m1 "^$key " "$GCACHE" 2>/dev/null) && [ -n "$a" ] && { [ "${a##* }" = 1 ]; return; }
  for a in $paths; do
    [ -r "$a" ] || continue
    # zip central directory (file names) sits at the end of the apk
    tail -c 2500000 "$a" 2>/dev/null | grep -aqF $ENGINE_ARGS && { hit=1; break; }
  done
  [ "$hit" = 0 ] && ! echo "$p" | grep -qiE "$NOT_GAME_PAT" && echo "$p" | grep -qiE "$GAME_PAT" && hit=1
  echo "$p" | grep -qiE 'gamebooster|gameturbo|gamespace|gamecenter|gameassistant|gamelauncher|play\.games' && hit=0
  touch "$GCACHE"; sed -i "/^$p /d" "$GCACHE" 2>/dev/null; echo "$key $hit" >> "$GCACHE"
  [ "$hit" = 1 ]
}
pkgs_f() { # "base.apk pkg" for every third-party app, one pm call
  pm list packages -3 -f 2>/dev/null | sed 's/^package://' | awk '{i=match($0,/\.apk=/); if(i) print substr($0,1,i+3), substr($0,i+5)}' | sort -k2
}
detected_games() {
  pkgs_f | while read -r ap p; do
    [ -n "$p" ] && is_game "$p" "$ap" && echo "$p"
  done
}
scan_games() { # replace the auto list with what is really a game (keeps user-added entries and their settings)
  local found p
  [ -n "$(pkgs_f | head -1)" ] || return 0   # package list unavailable: change nothing
  found=$(detected_games)
  if [ -f "$GAMES" ]; then
    while read -r p rest; do
      [ -n "$p" ] || continue
      echo "$found" | grep -qx "$p" && continue
      grep -qx "$p" "$CFG/manual" 2>/dev/null && continue
      game_del "$p"
    done < "$GAMES"
  fi
  for p in $found; do game_add "$p"; done
}



storage_free() { df /data 2>/dev/null | awk 'NR==2{u=$5; sub("%","",u); print 100-u}'; }
storage_freemb() { df -k /data 2>/dev/null | awk 'NR==2{printf "%d", $4/1024}'; }
sysbat() { # cycle count / capacity from sysfs when the kernel lets shell read it
  local d=/sys/class/power_supply/battery
  case "$1" in
    cycle) cat $d/cycle_count 2>/dev/null || dumpsys battery 2>/dev/null | grep -im1 'cycle' | grep -oE '[0-9]+$' ;;
    cap) local f g; f=$(cat $d/charge_full 2>/dev/null); g=$(cat $d/charge_full_design 2>/dev/null)
         [ -n "$f" ] && [ -n "$g" ] && [ "$g" -gt 0 ] && echo $(( f * 100 / g )) ;;
    design) local g; g=$(cat $d/charge_full_design 2>/dev/null); [ -n "$g" ] && echo $(( g / 1000 )) ;;
  esac
}
notify() { # tag text
  cok notify || return 0
  cmd notification post -S bigtext -t "APO Performance" "$1" "$2" >/dev/null 2>&1
}

# ---------------------------------------------------------------- compatibility
compat() {
  local s out; s=$(sdk); rm -f "$CFG/maxhz" "$CFG/physsize"
  out=$CFG/compat.conf; : > "$out"
  c() { echo "$1=$2" >> "$out"; }
  setprop debug.apo.probe 1 2>/dev/null; [ "$(getprop debug.apo.probe)" = 1 ] && c prop 1 || c prop 0
  setprop debug.apo.probe "" 2>/dev/null
  settings get global window_animation_scale >/dev/null 2>&1 && c settings 1 || c settings 0
  if device_config put apo_probe k 1 >/dev/null 2>&1 && [ "$(device_config get apo_probe k 2>/dev/null)" = 1 ]; then
    c devcfg 1; device_config delete apo_probe k >/dev/null 2>&1; else c devcfg 0; fi
  [ "$s" -ge 31 ] && c blur 1 || c blur 0
  [ "$(max_hz)" -gt 60 ] && c hz 1 || c hz 0
  [ "$s" -ge 30 ] && grep -q '^devcfg=1' "$out" && c freezer 1 || c freezer 0
  pm help 2>&1 | grep -q trim-caches && c trim 1 || c trim 0
  cmd package help 2>&1 | grep -q bg-dexopt-job && c art 1 || c art 0
  [ "$s" -ge 28 ] && c dns 1 || c dns 0
  [ "$s" -ge 31 ] && cmd game help >/dev/null 2>&1 && c gamemode 1 || c gamemode 0
  cmd power help 2>&1 | grep -q set-mode && c saver 1 || c saver 0
  command -v unzip >/dev/null 2>&1 && c icons 1 || c icons 0
  cmd power help 2>&1 | grep -q fixed-performance && c fixedperf 1 || c fixedperf 0
  cmd package compile 2>&1 | grep -qiE 'compile|usage|error' && c compile 1 || c compile 0
  dumpsys gfxinfo 2>&1 | grep -qiE 'gfxinfo|frames|Applications' && c jank 1 || c jank 0
  cmd notification help 2>&1 | grep -q set_dnd && c dnd 1 || c dnd 0
  cmd notification help 2>&1 | grep -q post && c notify 1 || c notify 0
  am help 2>&1 | grep -q set-standby-bucket && c bucket 1 || c bucket 0
  cmd appops help >/dev/null 2>&1 && c appops 1 || c appops 0
  dumpsys batterystats --help >/dev/null 2>&1 && c drain 1 || c drain 0
  dumpsys thermalservice 2>/dev/null | grep -q 'Thermal Status' && c thermal 1 || c thermal 0
}
cok() { [ "$(grep -m1 "^$1=" "$CFG/compat.conf" 2>/dev/null | cut -d= -f2)" != 0 ]; }

# ---------------------------------------------------------------- modes
mode_set() { # off | balance | perf | extreme
  case "$1" in
    off) put enabled 0 ;;
    balance) put enabled 1; put turbo 1; put touch 1; put smarthz 1; put ram 1; put hidden 1; put maint 1 ;;
    perf|extreme) put enabled 1; put turbo 1; put touch 1; put smarthz 1; put ram 1; put hidden 1; put maint 1; put gameauto 1
          put renderer "$(recommended_renderer)" ;;
    *) return 1 ;;
  esac
  put mode "$1"
}

# ---------------------------------------------------------------- global functions
sw() { if [ "$1" = 1 ] && cok "$2"; then bset "$3" "$4" "$5"; else brestore "$3" "$4"; fi; }
apply_global() {
  local en=0 m r hz d h k; on enabled && en=1; m=$(get mode)
  x() { [ $en = 1 ] && on "$1" && echo 1 || echo 0; }
  # interface turbo: animations 0.5x + no blur + debug overhead off
  for k in window_animation_scale transition_animation_scale animator_duration_scale; do sw "$(x turbo)" settings "$BK" s:global:$k 0.5; done
  sw "$(x turbo)" blur "$BK" s:global:disable_window_blurs 1
  for k in debug.hwui.overdraw debug.hwui.profile debug.hwui.show_dirty_regions debug.layout debug.egl.force_msaa; do sw "$(x turbo)" prop "$BK" p:$k false; done
  sw "$(x touch)" settings "$BK" s:secure:long_press_timeout 300
  sw "$(x touch)" settings "$BK" s:secure:multi_press_timeout 300
  # renderer
  r=$(get renderer)
  if [ $en = 1 ] && [ "$r" != keep ] && cok prop; then bset "$BK" p:debug.hwui.renderer "$r"; else brestore "$BK" p:debug.hwui.renderer; fi
  # refresh: max Hz allowed (min adaptive); extreme also locks the minimum at max
  if { [ "$(x smarthz)" = 1 ] || { [ $en = 1 ] && [ "$m" = extreme ]; }; } && cok hz; then hz=$(max_hz); bset "$BK" s:system:peak_refresh_rate "$hz.0"
  else brestore "$BK" s:system:peak_refresh_rate; fi
  if [ $en = 1 ] && [ "$m" = extreme ] && cok hz; then bset "$BK" s:system:min_refresh_rate "$(max_hz).0"; else brestore "$BK" s:system:min_refresh_rate; fi
  # performance modes: lift battery-saver throttling; extreme: sustained performance mode
  if [ $en = 1 ] && { [ "$m" = perf ] || [ "$m" = extreme ]; } && { [ "$(_read b:saver)" = 1 ] || [ -f "$BK/b_saver" ]; }; then sw 1 saver "$BK" b:saver 0; else brestore "$BK" b:saver; fi
  if [ $en = 1 ] && [ "$m" = extreme ]; then sw 1 fixedperf "$BK" f:fixed true; else brestore "$BK" f:fixed; fi
  # smart RAM: freezer (+ clean on lock in the loop)
  sw "$(x ram)" freezer "$BK" d:activity_manager_native_boot:use_freezer true
  sw "$(x ram)" freezer "$BK" s:global:cached_apps_freezer enabled
  # hidden drain: background scans, mobile data always on, logs, telemetry
  sw "$(x hidden)" settings "$BK" s:global:wifi_scan_always_enabled 0
  sw "$(x hidden)" settings "$BK" s:global:ble_scan_always_enabled 0
  sw "$(x hidden)" settings "$BK" s:global:mobile_data_always_on 0
  sw "$(x hidden)" settings "$BK" s:global:activity_starts_logging_enabled 0
  sw "$(x hidden)" settings "$BK" s:global:send_action_app_error 0
  [ -n "$(_read l:logd)" ] && sw "$(x hidden)" settings "$BK" l:logd 64K
  # ad-free / fast DNS
  d=$(get dns)
  case "$d" in cloudflare) h=one.one.one.one;; google) h=dns.google;; adguard) h=dns.adguard-dns.com;; *) h="";; esac
  if [ $en = 1 ] && [ -n "$h" ] && cok dns; then bset "$BK" s:global:private_dns_mode hostname; bset "$BK" s:global:private_dns_specifier "$h"
  else brestore "$BK" s:global:private_dns_mode; brestore "$BK" s:global:private_dns_specifier; fi
  # games: Game Mode performance
  for p in $(games_list); do
    if [ "$(x gameauto)" = 1 ] && cok gamemode; then cmd game mode performance "$p" >/dev/null 2>&1
    else cmd game mode standard "$p" >/dev/null 2>&1; fi
  done
}

# ---------------------------------------------------------------- battery drain hunter
uid_of() { echo "$1" | awk -F'a' '{u=$1; sub("u","",u); printf "%d", u*100000+10000+$2}'; }
drain_json() { # top third-party apps by estimated mAh since last full charge
  local map tmp=$CFG/drain.tmp
  pm list packages -3 -U 2>/dev/null | sed 's/^package://; s/ uid:/ /' > "$CFG/uids"
  dumpsys batterystats --charged 2>/dev/null | grep -oE 'UID u[0-9]+a[0-9]+: [0-9.]+' | awk '{sub(":","",$2); print $2, $3}' > "$tmp"
  awk 'NR==FNR{split($1,a,"a"); u=a[1]; sub("u","",u); uid=u*100000+10000+a[2]; if(!(uid in m) || $2>m[uid]) m[uid]=$2; next}
       ($2 in m){print m[$2], $1}' "$tmp" "$CFG/uids" | sort -rn | head -10 > "$CFG/drain.top"
  printf '['
  awk -v R="$CFG/restricted" 'BEGIN{while((getline l < R)>0){split(l,a," "); r[a[1]]=1}}
    {printf "%s{\"p\":\"%s\",\"mah\":\"%s\",\"r\":%d}", (n++?",":""), $2, $1, ($2 in r)}' "$CFG/drain.top"
  printf ']\n'
  rm -f "$tmp"
}
BUCKETS='5:exempted 10:active 20:working_set 30:frequent 40:rare 45:restricted 50:never'
bucket_name() { local b; for b in $BUCKETS; do [ "${b%%:*}" = "$1" ] && { echo "${b#*:}"; return; }; done; echo active; }
restrict() { # pkg on|off  (manual: background off + restricted bucket)
  local p="$1" b
  case "$p" in *[!A-Za-z0-9._]*|'') return 1;; esac
  touch "$CFG/restricted"
  if [ "$2" = on ]; then
    grep -q "^$p " "$CFG/restricted" && return 0
    b=$(am get-standby-bucket "$p" 2>/dev/null | grep -oE '[0-9]+' | head -1)
    echo "$p ${b:-10} $(cmd appops get "$p" RUN_ANY_IN_BACKGROUND 2>/dev/null | grep -oE 'allow|ignore|deny|default' | head -1)" >> "$CFG/restricted"
    cok appops && cmd appops set "$p" RUN_ANY_IN_BACKGROUND ignore >/dev/null 2>&1
    cok bucket && am set-standby-bucket "$p" restricted >/dev/null 2>&1
    am force-stop "$p" >/dev/null 2>&1
    log "restricted $p"
  else
    set -- $(grep -m1 "^$p " "$CFG/restricted")
    [ -n "$1" ] || return 0
    cmd appops set "$p" RUN_ANY_IN_BACKGROUND "${3:-allow}" >/dev/null 2>&1
    am set-standby-bucket "$p" "$(bucket_name "${2:-10}")" >/dev/null 2>&1
    sed -i "/^$p /d" "$CFG/restricted"; log "unrestricted $p"
  fi
}
KEEP_AWAKE='whatsapp|telegram|messenger|signal|discord|instagram|facebook\.orca|\.mail|gmail|outlook|clock|alarm|calendar|launcher|keyboard|inputmethod|swiftkey|bank|itau|bradesco|nubank|caixa|santander|inter|picpay|mercadopago|uber|99app|ifood|maps|waze|spotify|deezer|music|podcast|authenticator|authy|vpn|axeron|axmanager|shizuku|termux|health|fit|watch|wear|band'
hibernate_run() { # apps the system already marks rare/never -> restricted bucket (auto-wakes on use)
  on enabled && on hibernate && cok bucket || return 0
  local p b n=0
  touch "$CFG/hibernated"
  for p in $(pm list packages -3 2>/dev/null | sed 's/^package://'); do
    echo "$p" | grep -qiE "$KEEP_AWAKE" && continue
    grep -q "^$p " "$CFG/restricted" 2>/dev/null && continue
    grep -q "^$p\( \|$\)" "$GAMES" 2>/dev/null && continue
    b=$(am get-standby-bucket "$p" 2>/dev/null | grep -oE '[0-9]+' | head -1)
    if [ "${b:-10}" -ge 40 ] && [ "${b:-10}" -lt 45 ]; then
      am set-standby-bucket "$p" restricted >/dev/null 2>&1
      grep -qx "$p" "$CFG/hibernated" || echo "$p" >> "$CFG/hibernated"; n=$((n+1))
    fi
  done
  log "hibernated $n apps"
}
unhibernate_all() { local p; for p in $(cat "$CFG/hibernated" 2>/dev/null); do am set-standby-bucket "$p" rare >/dev/null 2>&1; done; rm -f "$CFG/hibernated"; }

# ---------------------------------------------------------------- bloatware (reversible: pm disable-user / pm enable)
BLOAT='com.facebook.appmanager com.facebook.services com.facebook.system com.netflix.partner.activation com.google.android.videos com.google.android.feedback com.android.dreams.basic com.android.dreams.phototable com.android.bips com.android.printspooler com.google.android.apps.wellbeing.overlay com.amazon.appmanager com.linkedin.android com.booking com.ebay.mobile com.ebay.carrier com.spotify.music.partner
com.samsung.android.bixby.agent com.samsung.android.bixby.wakeup com.samsung.android.visionintelligence com.samsung.android.bixbyvision.framework com.samsung.android.app.spage com.samsung.android.app.tips com.samsung.android.ardrawing com.samsung.android.aremoji com.samsung.android.arzone com.samsung.android.mateagent com.samsung.android.kidsinstaller com.samsung.android.app.routines com.samsung.android.samsungpass com.samsung.android.samsungpassautofill com.samsung.android.svoiceime com.samsung.android.app.watchmanagerstub com.samsung.android.stickercenter com.samsung.android.livestickers com.samsung.android.da.daagent com.samsung.android.service.peoplestripe com.samsung.android.forest com.sec.android.app.kidshome com.samsung.android.app.sharelive com.samsung.android.bbc.bbcagent
com.miui.analytics com.miui.msa.global com.miui.daemon com.miui.hybrid com.miui.hybrid.accessory com.miui.bugreport com.xiaomi.mipicks com.miui.yellowpage com.xiaomi.glgm com.miui.miservice com.mi.android.globalminusscreen com.miui.player com.miui.android.fashiongallery com.xiaomi.midrop com.miui.compass com.xiaomi.payment com.mipay.wallet.in com.miui.cloudbackup com.xiaomi.micloud.sdk com.miui.cloudservice com.miui.micloudsync com.mi.globalbrowser
com.motorola.help com.motorola.demo com.motorola.ccc.notification com.motorola.genie com.motorola.brapps com.motorola.moto.gamemode com.motorola.timeweatherwidget
com.heytap.pictorial com.oplus.pictorial com.coloros.childrenspace com.opos.ads com.heytap.browser com.heytap.music com.heytap.cloud com.oppo.market com.heytap.market com.coloros.video com.oplus.games com.realme.gamecenter
com.vivo.browser com.vivo.easyshare com.bbk.theme com.vivo.globalsearch com.vivo.hiboard com.iqoo.secure.ads com.vivo.appstore
com.transsion.phoenix com.transsion.aivoiceassistant com.transsion.hilauncher.ads com.afmobi.boomplayer com.transsion.magazineservice com.zaz.translate com.hoffnung'
bloat_json() {
  local all dis p n=0
  all=" $(pm list packages 2>/dev/null | sed 's/^package://' | tr '\n' ' ') "
  dis=" $(pm list packages -d 2>/dev/null | sed 's/^package://' | tr '\n' ' ') "
  printf '['
  for p in $BLOAT; do
    case "$all" in *" $p "*) ;; *) continue;; esac
    case "$dis" in *" $p "*) d=1;; *) d=0;; esac
    printf '%s{"p":"%s","d":%s}' "$( [ $n -gt 0 ] && echo ,)" "$p" "$d"; n=$((n+1))
  done
  printf ']\n'
}
debloat() { # pkg on|off
  case " $(echo $BLOAT) " in *" $1 "*) ;; *) return 1;; esac
  touch "$CFG/debloated"
  if [ "$2" = on ]; then pm disable-user --user 0 "$1" >/dev/null 2>&1; grep -qx "$1" "$CFG/debloated" || echo "$1" >> "$CFG/debloated"; log "disabled $1"
  else pm enable "$1" >/dev/null 2>&1; sed -i "/^$1$/d" "$CFG/debloated"; log "enabled $1"; fi
}
bloat_count() { bloat_json | grep -o '"d":0' | wc -l; }

# ---------------------------------------------------------------- health / diagnosis
health_json() {
  local b; b=$(bat)
  printf '{"level":"%s","temp":"%s","volt":"%s","health":"%s","status":"%s","tech":"%s","cycle":"%s","cap":"%s","design":"%s","charging":%s}\n' \
    "$(echo "$b" | grep -m1 ' level:' | grep -oE '[0-9]+')" "$(echo "$b" | grep -m1 'temperature:' | grep -oE '[0-9]+')" \
    "$(echo "$b" | grep -m1 'voltage:' | grep -oE '[0-9]+')" "$(echo "$b" | grep -m1 ' health:' | grep -oE '[0-9]+')" \
    "$(echo "$b" | grep -m1 ' status:' | grep -oE '[0-9]+')" "$(echo "$b" | grep -m1 'technology:' | sed 's/.*: *//' | json_esc)" \
    "$(sysbat cycle)" "$(sysbat cap)" "$(sysbat design)" "$(echo "$b" | grep -qE '(AC|USB|Wireless) powered: true' && echo true || echo false)"
}
diagnose_json() { # score + checks: {"id":..,"ok":0/1,"v":"value"}
  local s=100 ram st tp an bl sc md dbg dn bc cap items=""
  it() { items="$items${items:+,}{\"id\":\"$1\",\"ok\":$2,\"v\":\"$3\"}"; [ "$2" = 0 ] && s=$((s-$4)); return 0; }
  ram=$(mem_free); st=$(storage_free); tp=$(bat | grep -m1 'temperature:' | grep -oE '[0-9]+'); tp=${tp:-300}
  [ "${ram:-50}" -ge 20 ] && it ram 1 "$ram%" 0 || it ram 0 "$ram%" 10
  [ "${st:-50}" -ge 15 ] && it storage 1 "$st%" 0 || it storage 0 "$st%" 12
  [ "$tp" -lt 400 ] && it temp 1 "$((tp/10))°C" 0 || it temp 0 "$((tp/10))°C" 10
  cap=$(sysbat cap); [ -n "$cap" ] && { [ "$cap" -ge 80 ] && it bathealth 1 "$cap%" 0 || it bathealth 0 "$cap%" 6; }
  an=$(settings get global window_animation_scale 2>/dev/null); [ "$an" = null ] && an=1.0; [ "$an" = 0.5 ] || [ "$an" = 0.0 ] || [ "$an" = 0 ] && it anim 1 "${an}x" 0 || it anim 0 "${an:-1.0}x" 6
  if cok blur; then bl=$(settings get global disable_window_blurs 2>/dev/null); [ "$bl" = 1 ] && it blur 1 off 0 || it blur 0 on 5; fi
  sc=$(settings get global wifi_scan_always_enabled 2>/dev/null); [ "$sc" = 0 ] && it scans 1 off 0 || it scans 0 on 6
  md=$(settings get global mobile_data_always_on 2>/dev/null); [ "$md" = 0 ] && it mobiledata 1 off 0 || it mobiledata 0 on 8
  dbg=0; for k in debug.hwui.overdraw debug.hwui.profile debug.layout; do v=$(getprop $k); [ -n "$v" ] && [ "$v" != false ] && dbg=1; done
  [ "$(settings get system show_touches 2>/dev/null)" = 1 ] && dbg=1
  [ $dbg = 0 ] && it debug 1 off 0 || it debug 0 on 7
  dn=$(settings get global private_dns_mode 2>/dev/null); [ "$dn" = hostname ] && it dns 1 on 0 || it dns 0 off 4
  if cok freezer; then [ "$(settings get global cached_apps_freezer 2>/dev/null)" = enabled ] && it freezer 1 on 0 || it freezer 0 off 6; fi
  bc=$(bloat_count); [ "$bc" -le 2 ] && it bloat 1 "$bc" 0 || it bloat 0 "$bc" 8
  [ $s -lt 5 ] && s=5
  echo "$s" > "$CFG/score"
  printf '{"score":%s,"items":[%s]}\n' "$s" "$items"
}
fix_all() { # one tap: balanced mode (unless a mode is already on) + clean
  local m; m=$(get mode)
  case "$m" in off|"") mode_set balance;; *) put enabled 1;; esac
  put turbo 1; put hidden 1; put ram 1
  put touch 1; [ "$(get dns)" = off ] && put dns cloudflare
  apply_global
  cok trim && pm trim-caches 999G >/dev/null 2>&1
  am kill-all >/dev/null 2>&1
  log "fix all"
}
clean_now() { # storage + RAM, prints freed MB
  local a b; a=$(storage_freemb)
  cok trim && pm trim-caches 999G >/dev/null 2>&1
  am kill-all >/dev/null 2>&1
  b=$(storage_freemb); log "clean: $((b-a)) MB"
  printf '{"freed":"%s","free":"%s","ram":"%s"}\n' "$((b-a))" "$b" "$(mem_free)"
}

# ---------------------------------------------------------------- benchmark
ms() { local n; n=$(date +%s%N 2>/dev/null); case "$n" in *N*|'') echo $(( $(date +%s) * 1000 ));; *) echo $(( n / 1000000 ));; esac; }
cpu_job() { awk 'BEGIN{s=0; for(i=1;i<=1500000;i++){s+=sqrt(i)*1.0001; if(i%7==0)s-=i/3} print s}' >/dev/null; }
bench_json() {
  local a b c1 cn n i w io rm sc
  n=$(grep -c '^processor' /proc/cpuinfo); [ "${n:-0}" -lt 1 ] && n=1; [ "$n" -gt 8 ] && n=8
  a=$(ms); cpu_job; b=$(ms); c1=$((b-a)); [ $c1 -lt 1 ] && c1=1
  a=$(ms); i=0; while [ $i -lt $n ]; do cpu_job & i=$((i+1)); done; wait; b=$(ms); cn=$((b-a)); [ $cn -lt 1 ] && cn=1
  a=$(ms); dd if=/dev/zero of="$CFG/io.tmp" bs=1048576 count=64 conv=fsync >/dev/null 2>&1; b=$(ms); rm -f "$CFG/io.tmp"
  w=$((b-a)); [ $w -lt 1 ] && w=1; io=$(( 64000 / w ))
  rm=$(awk '/MemAvailable/{printf "%d", $2/1024}' /proc/meminfo)
  sc=$(( 400000 / c1 + 400000 * n / cn / 2 + io * 3 + rm / 8 ))
  echo "$(date +%s) $sc $c1 $cn $io $rm" >> "$CFG/bench.hist"; tail -n 20 "$CFG/bench.hist" > "$CFG/bench.t" && mv "$CFG/bench.t" "$CFG/bench.hist"
  printf '{"score":%s,"single":%s,"multi":%s,"cores":%s,"io":%s,"ram":%s,"first":%s}\n' "$sc" "$c1" "$cn" "$n" "$io" "$rm" "$(head -1 "$CFG/bench.hist" | awk '{print $2}')"
}

# ---------------------------------------------------------------- maintenance (charging only)
maintenance() {
  [ "$1" = now ] || { on enabled && on maint && charging || return 0; }
  log "maintenance start"; echo 1 > "$CFG/maint_running"; state
  cok trim && pm trim-caches 999G >/dev/null 2>&1
  cok art && cmd package bg-dexopt-job >/dev/null 2>&1
  hibernate_run
  cok compile && cmd package compile -m speed-profile -a >/dev/null 2>&1
  date +%s > "$CFG/last_maint"; rm -f "$CFG/maint_running"; log "maintenance done"; state
}
maint_due() { local l; l=$(cat "$CFG/last_maint" 2>/dev/null); [ -z "$l" ] || [ $(( $(date +%s) - l )) -gt 72000 ]; }

# ---------------------------------------------------------------- game session (auto performance)
game_enter() {
  local p="$1" hz; log "game on: $p"; echo "$p" > "$CFG/ingame"
  am kill-all >/dev/null 2>&1
  cok jank && dumpsys gfxinfo "$p" reset >/dev/null 2>&1
  on gamednd && cok dnd && bset "$GBK" z:dnd priority
  if cok hz; then hz=$(max_hz); bset "$GBK" s:system:min_refresh_rate "$hz.0"; bset "$GBK" s:system:peak_refresh_rate "$hz.0"; fi
  [ "$(_read b:saver)" = 1 ] && bset "$GBK" b:saver 0
  state
}
game_exit() {
  local p; p=$(cat "$CFG/ingame" 2>/dev/null); log "game off: $p"
  [ -n "$p" ] && cok jank && jank_save "$p"
  brestore_all "$GBK"; rm -f "$CFG/ingame"; state
}
jank_save() { # frames + janky % + 90th percentile frame time of the session just played
  local g tot jk pc p90
  g=$(dumpsys gfxinfo "$1" 2>/dev/null)
  tot=$(echo "$g" | grep -m1 'Total frames rendered' | grep -oE '[0-9]+$')
  jk=$(echo "$g" | grep -m1 'Janky frames:' | sed 's/.*Janky frames: *//' | awk '{print $1}')
  pc=$(echo "$g" | grep -m1 'Janky frames:' | grep -oE '[0-9.]+%' | tr -d '%')
  p90=$(echo "$g" | grep -m1 '90th percentile' | grep -oE '[0-9]+ms' | tr -d 'ms')
  [ -n "$tot" ] && [ "$tot" -gt 0 ] && echo "$1 $tot ${jk:-0} ${pc:-0} ${p90:-0} $(date +%s)" > "$CFG/jank"
}

# ---------------------------------------------------------------- alerts + thermal
alert_tick() { # heat alert
  local tp now last
  tp=$(echo "$1" | grep -m1 'temperature:' | grep -oE '[0-9]+')
  if on thermal && [ "${tp:-0}" -ge 430 ]; then
    now=$(date +%s); last=$(cat "$CFG/alertheat" 2>/dev/null); last=${last:-0}
    [ $((now-last)) -gt 1800 ] && { echo "$now" > "$CFG/alertheat"; notify apoheat "$(get_msg heat) $((tp/10))°C"; log "alert heat $tp"; }
  fi
}
get_msg() {
  local l; l=$(get lang); [ "$l" = auto ] && l=$(getprop persist.sys.locale | cut -c1-2)
  case "$l" in pt) echo "Celular quente, o desempenho vai cair. Dê uma pausa:";; es) echo "Teléfono caliente, el rendimiento bajará. Descansa:";;
    id) echo "Ponsel panas, performa akan turun. Istirahat dulu:";; *) echo "Phone is hot, performance will drop. Give it a break:";; esac
}
thermal_tick() {
  local st; on thermal && cok thermal || return 0
  st=$(thermal_status); st=${st:-0}; echo "$st" > "$CFG/thermal_now"
  if [ "$st" -ge 2 ] && [ ! -f "$CFG/cooling" ]; then
    touch "$CFG/cooling"; log "thermal $st: cooling"; cok hz && bset "$TBK" s:system:peak_refresh_rate 60.0; am kill-all >/dev/null 2>&1
  elif [ "$st" -le 0 ] && [ -f "$CFG/cooling" ]; then rm -f "$CFG/cooling"; brestore_all "$TBK"; log "thermal normal"; fi
}

# ---------------------------------------------------------------- battery-aware loop
loop() {
  echo $$ > "$CFG/loop.pid"
  local cur="" was=1 t=55 fg b slp
  [ -f "$CFG/ingame" ] && game_exit
  while true; do
    if ! on enabled; then
      [ -n "$cur" ] && { game_exit; cur=""; }
      [ -f "$CFG/cooling" ] && { rm -f "$CFG/cooling"; brestore_all "$TBK"; }
      sleep 60; continue
    fi
    if screen_on; then
      was=1; slp=20
      if on gameauto && [ -s "$GAMES" ]; then
        fg=$(fg_pkg); slp=5
        if [ -n "$fg" ] && grep -q "^$fg\( \|$\)" "$GAMES"; then
          [ "$cur" != "$fg" ] && { [ -n "$cur" ] && game_exit; cur=$fg; game_enter "$fg"; }
        elif [ -n "$cur" ] && [ -n "$fg" ]; then game_exit; cur=""; fi
      fi
      t=$((t+slp))
      if [ $t -ge 60 ]; then t=0; b=$(bat); alert_tick "$b"; thermal_tick; state; fi
      sleep $slp
    else
      if [ $was = 1 ]; then was=0; [ -n "$cur" ] && { game_exit; cur=""; }; on ram && am kill-all >/dev/null 2>&1; state; fi
      b=$(bat); alert_tick "$b"
      [ -f "$CFG/cooling" ] && thermal_tick
      maint_due && maintenance
      sleep 60
    fi
  done
}
loop_running() { [ -f "$CFG/loop.pid" ] && kill -0 "$(cat "$CFG/loop.pid")" 2>/dev/null; }
start_loop() { loop_running || { MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" loop </dev/null >/dev/null 2>&1 & }; }

apply_bg() {
  touch "$CFG/pending"
  [ -d "$CFG/lock" ] && [ -n "$(find "$CFG/lock" -maxdepth 0 -mmin +2 2>/dev/null)" ] && rmdir "$CFG/lock" 2>/dev/null
  MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" worker </dev/null >/dev/null 2>&1 &
}
worker() {
  mkdir "$CFG/lock" 2>/dev/null || return 0
  while [ -f "$CFG/pending" ]; do rm -f "$CFG/pending"; apply_global; done
  rmdir "$CFG/lock" 2>/dev/null; state
}

# ---------------------------------------------------------------- json out
json_esc() { sed 's/\\/\\\\/g; s/"/\\"/g'; }
state() { # published for the WebUI to fetch() without blocking it
  local w="$MODDIR/webroot"
  [ -d "$w" ] || return 0
  status_json > "$w/.state.tmp" 2>/dev/null && mv -f "$w/.state.tmp" "$w/state.json"
}
info_cache() { local w="$MODDIR/webroot"; info_json > "$w/.info.tmp" 2>/dev/null && mv -f "$w/.info.tmp" "$w/info.json"; cat "$w/info.json"; }
status_json() {
  local b lv tp ch=false
  b=$(bat); lv=$(echo "$b" | grep -m1 ' level:' | grep -oE '[0-9]+'); tp=$(echo "$b" | grep -m1 'temperature:' | grep -oE '[0-9]+')
  echo "$b" | grep -qE '(AC|USB|Wireless) powered: true' && ch=true
  printf '{"settings":{'
  awk -F= 'NF>=2{printf "%s\"%s\":\"%s\"", (n++?",":""), $1, substr($0, index($0,"=")+1)}' "$SET"
  printf '},"compat":{'
  awk -F= 'NF>=2{printf "%s\"%s\":%s", (n++?",":""), $1, $2}' "$CFG/compat.conf" 2>/dev/null
  printf '},"games":['
  awk 'NF{printf "%s\"%s\"", (n++?",":""), $1}' "$GAMES"
  printf '],"applying":%s,"ingame":"%s","thermal":"%s","cooling":%s,"loop":%s,"backups":%s,"mem":"%s","bat":"%s","temp":"%s","charging":%s,"maint":%s,"last_maint":"%s","storage":"%s","score":"%s","restricted":%s,"hibernated":%s,"debloated":%s,"jank":"%s","bench":"%s"}\n' \
    "$( [ -d "$CFG/lock" ] && echo true || echo false)" "$(cat "$CFG/ingame" 2>/dev/null)" "$(cat "$CFG/thermal_now" 2>/dev/null)" \
    "$( [ -f "$CFG/cooling" ] && echo true || echo false)" "$(loop_running && echo true || echo false)" "$(ls "$BK" | wc -l)" \
    "$(mem_free)" "$lv" "$tp" "$ch" "$( [ -f "$CFG/maint_running" ] && echo true || echo false)" "$(cat "$CFG/last_maint" 2>/dev/null)" \
    "$(storage_free)" "$(cat "$CFG/score" 2>/dev/null)" "$(cat "$CFG/restricted" 2>/dev/null | wc -l)" "$(cat "$CFG/hibernated" 2>/dev/null | wc -l)" \
    "$(cat "$CFG/debloated" 2>/dev/null | wc -l)" "$(cat "$CFG/jank" 2>/dev/null)" "$(tail -1 "$CFG/bench.hist" 2>/dev/null | awk '{print $2}')"
}
info_json() {
  printf '{"model":"%s","brand":"%s","android":"%s","sdk":"%s","gpu":"%s","vendor":"%s","tier":"%s","ram":"%s","hz":"%s","size":"%s","soc":"%s"}\n' \
    "$(getprop ro.product.model | json_esc)" "$(getprop ro.product.brand | json_esc)" "$(getprop ro.build.version.release)" "$(sdk)" \
    "$(gpu_str | json_esc)" "$(gpu_vendor)" "$(tier)" "$(ram_gb)" "$(max_hz)" "$(phys_size)" \
    "$( { getprop ro.soc.model; getprop ro.board.platform; } | grep -m1 . | json_esc)"
}
apps_json() { # picker: [{"p":pkg,"g":1|0}], detected games first
  local p ap yes="" no=""
  for ap in $(pkgs_f | tr ' ' '|'); do
    p=${ap#*|}; ap=${ap%%|*}
    if is_game "$p" "$ap"; then yes="$yes $p"; else no="$no $p"; fi
  done
  { for p in $yes; do echo "$p 1"; done; for p in $no; do echo "$p 0"; done; } |
    awk 'BEGIN{printf "["} {printf "%s{\"p\":\"%s\",\"g\":%s}", (n++?",":""), $1, $2} END{print "]"}'
}


# ---------------------------------------------------------------- app icons
# Real icons for the WebUI. The manager's ksu://icon is tried first by the page;
# this is the fallback: the launcher icon is read straight out of the app's APK
# (shell can read base.apk) and cached in webroot/icons/<pkg>.png. Runs in the
# background, only for the apps the page is showing.
ICDIR="$MODDIR/webroot/icons"
icon_one() {
  local p apk ent out
  p=$1; case "$p" in *[!A-Za-z0-9._]*|'') return 1;; esac
  out="$ICDIR/$p.png"; [ -s "$out" ] && return 0
  [ -f "$ICDIR/$p.none" ] && return 1
  apk=$(pm path "$p" 2>/dev/null | sed -n 's/^package://p'); apk=$(echo "$apk" | grep -m1 'base\.apk$' || echo "$apk" | head -1)
  [ -n "$apk" ] && [ -r "$apk" ] || { : > "$ICDIR/$p.none"; return 1; }
  ent=$(unzip -l "$apk" 2>/dev/null | awk '{print $NF}' | grep -E '^res/(mipmap|drawable)[^/]*/[A-Za-z0-9_]+\.(png|webp)$' | awk '
    { n=$0; sub(/.*\//,"",n); sub(/\.[a-z]+$/,"",n); r=-1
      if (n=="ic_launcher") r=60; else if (n=="app_icon") r=58; else if (n=="ic_launcher_round") r=55
      else if (n ~ /^(icon|app_logo|ic_app|launcher_icon|ic_launcher_app|logo|ic_logo)$/) r=45
      else if (n ~ /launcher/ && n !~ /background|monochrome|banner/) r=35
      else if (n=="ic_launcher_foreground") r=25
      if (r < 0) next
      d=0; if ($0 ~ /xxxhdpi/) d=6; else if ($0 ~ /xxhdpi/) d=5; else if ($0 ~ /xhdpi/) d=4; else if ($0 ~ /hdpi/) d=3; else if ($0 ~ /mdpi/) d=2
      print r+d, $0 }' | sort -rn | head -1 | cut -d' ' -f2)
  [ -n "$ent" ] && unzip -p "$apk" "$ent" > "$out.tmp" 2>/dev/null
  if [ -s "$out.tmp" ]; then mv "$out.tmp" "$out"; chmod 644 "$out" 2>/dev/null; return 0; fi
  rm -f "$out.tmp"; : > "$ICDIR/$p.none"; return 1
}
icons_bg() { mkdir -p "$ICDIR"; for p in "$@"; do icon_one "$p"; done; date +%s > "$ICDIR/.stamp"; }

# ---------------------------------------------------------------- cli
cfg_init
case "$1" in
  status) status_json ;;
  info) info_cache ;;
  apps) apps_json ;;
  set) put "$2" "$3" && { case "$2" in lang|hibernate|thermal|maint|gameauto|gamednd) ;; *) [ "$(get mode)" != off ] && put mode custom;; esac
       log "set $2=$3"; apply_bg; } ;;
  mode) mode_set "$2" && { log "mode $2"; apply_bg; [ "$2" != off ] && start_loop; } ;;
  diagnose) diagnose_json ;;
  fixall) fix_all; start_loop; diagnose_json ;;
  health) health_json ;;
  drain) drain_json ;;
  restrict) restrict "$2" "$3"; echo '{"ok":true}' ;;
  bloat) bloat_json ;;
  debloat) debloat "$2" "$3"; echo '{"ok":true}' ;;
  optapp) case "$2" in *[!A-Za-z0-9._]*|'') ;; *) MODDIR=$MODDIR nohup sh -c "cmd package compile -m speed -f $2 >/dev/null 2>&1" </dev/null >/dev/null 2>&1 & log "optimize $2";; esac; echo '{"ok":true}' ;;
  clean) clean_now ;;
  optimize) MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" maint_now </dev/null >/dev/null 2>&1 & ;;
  maint_now) maintenance now ;;
  scan) scan_games; apply_bg ;;
  gadd) game_add "$2" && { grep -qx "$2" "$CFG/manual" 2>/dev/null || echo "$2" >> "$CFG/manual"; }; apply_bg ;;
  gdel) case "$2" in *[!A-Za-z0-9._]*|'') ;; *) sed -i "/^$2$/d" "$CFG/manual" 2>/dev/null;; esac; game_del "$2"; apply_bg ;;
  apply) apply_global ;;
  worker) worker ;;
  enable) [ "$(get mode)" = off ] && mode_set balance; put enabled 1; apply_bg; start_loop ;;
  disable) mode_set off; [ -f "$CFG/ingame" ] && game_exit; apply_bg ;;
  compat) compat ;;
  bench) bench_json ;;
  icons) shift; MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" icons_bg "$@" </dev/null >/dev/null 2>&1 & echo '{"ok":true}' ;;
  icons_bg) shift; icons_bg "$@" ;;
  compileall) MODDIR=$MODDIR nohup sh -c "cmd package compile -m speed-profile -a >/dev/null 2>&1" </dev/null >/dev/null 2>&1 & log "compile all"; echo '{"ok":true}' ;;
  restore) put enabled 0; put mode off; [ -f "$CFG/ingame" ] && game_exit; rm -f "$CFG/cooling"
           brestore_all "$TBK"; brestore_all "$GBK"; apply_global; brestore_all "$BK"
           for p in $(awk '{print $1}' "$CFG/restricted" 2>/dev/null); do restrict "$p" off; done
           unhibernate_all
           for p in $(cat "$CFG/debloated" 2>/dev/null); do pm enable "$p" >/dev/null 2>&1; done; rm -f "$CFG/debloated"
           for p in $(games_list); do cmd game mode standard "$p" >/dev/null 2>&1; done; log "restore all" ;;
  wipe) sh "$0" restore >/dev/null; rm -rf "$CFG" ;;
  log) tail -n 60 "$LOG" 2>/dev/null ;;
  loop) loop_running && exit 0; loop ;;
  boot) [ -f "$CFG/compat.conf" ] || compat
        on enabled && apply_global
        state; info_cache >/dev/null
        loop_running || loop ;;
  state) state; echo '{"ok":true}' ;;
  *) echo "usage: apo status|mode off|balance|perf|extreme|bench|diagnose|fixall|health|drain|compileall|restrict p on|off|bloat|debloat p on|off|optapp p|clean|optimize|scan|set k v|compat|restore|log" ;;
esac
case "$1" in set|mode|enable|disable|scan|gadd|gdel|compat|restore|optimize|restrict|debloat) state ;; esac
case "$1" in set|mode|enable|disable|scan|gadd|gdel|compat|restore|optimize) cat "$MODDIR/webroot/state.json" 2>/dev/null || status_json ;; esac
