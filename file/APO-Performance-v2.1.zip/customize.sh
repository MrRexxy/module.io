SKIPUNZIP=0
ui_print " "
ui_print "   █████╗ ██████╗  ██████╗ "
ui_print "  ██╔══██╗██╔══██╗██╔═══██╗"
ui_print "  ███████║██████╔╝██║   ██║"
ui_print "  ██╔══██║██╔═══╝ ██║   ██║"
ui_print "  ██║  ██║██║     ╚██████╔╝"
ui_print "  ╚═╝  ╚═╝╚═╝      ╚═════╝ "
ui_print "   PERFORMANCE LAB  v2.1"
ui_print "   ADB only - no root - performance first"
ui_print " "
[ "$API" -lt 26 ] && abort "! Android 8.0 or newer is required"
ui_print "- Device : $(getprop ro.product.model) (Android $(getprop ro.build.version.release))"
for f in core.sh service.sh action.sh uninstall.sh system/bin/apo; do
  [ -f "$MODPATH/$f" ] && chmod 0755 "$MODPATH/$f"
done
ui_print "- Testing what this device accepts..."
MODDIR=$MODPATH sh "$MODPATH/core.sh" compat >/dev/null 2>&1
ui_print "- Looking for games..."
MODDIR=$MODPATH sh "$MODPATH/core.sh" scan >/dev/null 2>&1
MODDIR=$MODPATH sh "$MODPATH/core.sh" info >/dev/null 2>&1
ui_print "- Done. Open the WebUI: run the benchmark, then 1-tap turbo."
ui_print " "
