/* APO Performance - WebUI (KernelSU WebUI API, works in AxManager without root) */
(() => {
const ID = "apo_performance";
/* Find the plugin folder: AxManager tells us (moduleInfo / PATH has <dir>/system/bin); fixed paths are only a fallback */
let MODDIR_JS = "";
try { if (window.ksu && ksu.moduleInfo) { const mi = JSON.parse(ksu.moduleInfo()); const md = mi.moduleDir || mi.dir || ""; MODDIR_JS = (md && typeof md === "object") ? String(md.path || md.absolutePath || "") : String(md); } } catch(e) {}
const CORE = `D='${MODDIR_JS}'; [ -f "$D/core.sh" ] || D=$(pwd); `
  + `if [ ! -f "$D/core.sh" ]; then OIFS=$IFS; IFS=:; for p in $PATH; do q=\${p%/system/bin}; [ "$q" != "$p" ] && [ -f "$q/core.sh" ] && { D=$q; break; }; done; IFS=$OIFS; fi; `
  + `[ -f "$D/core.sh" ] || for d in "$AXERONDIR/plugins/${ID}" /data/user_de/0/com.android.shell/axeron/plugins/${ID} /data/local/tmp/AxManager/plugins/${ID} /data/adb/modules/${ID}; do [ -f "$d/core.sh" ] && D=$d && break; done; `
  + `[ -f "$D/core.sh" ] || { echo "APO: pasta do plugin nao encontrada. PATH=\${PATH%%:*} D=$D" >&2; exit 2; }; `
  + `MODDIR=$D sh "$D/core.sh"`;
const HAS_API = typeof window.ksu !== "undefined" && typeof ksu.exec === "function";


let cbn = 0, QUEUE = Promise.resolve();
/* ksu.exec blocks the page while the shell runs: run one at a time, after the UI has painted */
const paint = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 20)));
function exec(cmd) {
  const p = QUEUE.then(paint).then(() => execNow(cmd));
  QUEUE = p.catch(() => {});
  return p;
}
function execNow(cmd) {
  return new Promise(res => {
    if (!HAS_API) return res({ errno:0, stdout:demo(cmd), stderr:"" });
    const n = "__apo" + (cbn++) + "_" + Date.now();
    let done = false;
    const fin = r => { if (done) return; done = true; delete window[n]; res(r); };
    window[n] = (e, o, er) => fin({ errno:e, stdout:o || "", stderr:er || "" });
    setTimeout(() => fin({ errno:124, stdout:"", stderr:"timeout" }), 150000);
    /* AxManager runs: sh -c "<cmd>" (naive double quotes), so quotes and $ would break/expand early.
       Send the script base64-encoded: only [A-Za-z0-9+/=] crosses that boundary. */
    const b64 = btoa(unescape(encodeURIComponent(cmd)));
    const wrapped = "echo " + b64 + " | base64 -d | sh";
    try { ksu.exec(wrapped, MODDIR_JS ? JSON.stringify({cwd: MODDIR_JS}) : "{}", n); } catch (x) { fin({ errno:1, stdout:"", stderr:String(x) }); }
  });
}
let LASTERR = "";
async function core(args) {
  const r = await exec(`${CORE} ${args}`);
  LASTERR = r.stderr || (r.errno ? "exit " + r.errno : "");
  return r.stdout || "";
}
async function coreJ(args) {
  const out = await core(args);
  const a = out.indexOf("{"), b = out.lastIndexOf("}");
  try { const j = JSON.parse(out.slice(a, b + 1)); if (j.settings) S = j; return j; }
  catch (e) { toast("⚠ " + (LASTERR || out || "no output").toString().slice(0, 140)); return null; }
}


const GAME_NAMES = {"com.dts.freefireth":"Free Fire","com.dts.freefiremax":"Free Fire MAX","com.activision.callofduty.shooter":"Call of Duty Mobile","com.garena.game.codm":"CODM Garena","com.tencent.ig":"PUBG Mobile","com.pubg.imobile":"BGMI","com.pubg.krmobile":"PUBG KR","com.vng.pubgmobile":"PUBG VN","com.mobile.legends":"Mobile Legends","com.riotgames.league.wildrift":"Wild Rift","com.levelinfinite.sgameGlobal":"Honor of Kings","com.pokemon.unite":"Pokémon Unite","com.supercell.brawlstars":"Brawl Stars","com.supercell.clashofclans":"Clash of Clans","com.supercell.clashroyale":"Clash Royale","com.gameloft.android.ANMP.GloftA9HM":"Asphalt 9","com.konami.pesam":"eFootball","jp.konami.pesam":"eFootball","com.ea.gp.fifamobile":"FC Mobile","com.miHoYo.GenshinImpact":"Genshin Impact","com.HoYoverse.hkrpgoversea":"Honkai: Star Rail","com.kurogame.wutheringwaves.global":"Wuthering Waves","com.roblox.client":"Roblox","com.mojang.minecraftpe":"Minecraft","com.farlightgames.farlight84.gp":"Farlight 84","com.axlebolt.standoff2":"Standoff 2","com.criticalforceentertainment.criticalops":"Critical Ops","com.innersloth.spacemafia":"Among Us","com.kiloo.subwaysurf":"Subway Surfers","com.sega.pjsekai":"Project Sekai","com.garena.game.df":"Delta Force","com.blueteam.bloodstrike":"Blood Strike","com.netease.newspike":"Blood Strike","com.carxtech.sr":"CarX Street","com.firsttouchgames.dls7":"Dream League Soccer","com.tencent.lolm":"LoL Mobile","com.blizzard.diablo.immortal":"Diablo Immortal","com.netease.idv.googleplay":"Identity V","com.imangi.templerun2":"Temple Run 2","com.YoStarEN.Arknights":"Arknights","com.hypergryph.arknights":"Arknights"};
const gname = p => LABELS[p] || GAME_NAMES[p] || (p.split(".").pop().replace(/^\w/, c => c.toUpperCase()));
const hue = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
/* ---------------- app icons ----------------
   1) the manager's own ksu://icon/<pkg> (KernelSU and managers that copy its API)
   2) icons/<pkg>.png, pulled out of the APK by core.sh in the background
   3) the coloured initials stay underneath when neither exists */
const ICON = { ksu: HAS_API && typeof ksu.listPackages === "function", q: new Set(), asked: new Set(), tm: null, v: Date.now() };
const LABELS = {};
function appIcon(p, cls, style, letters) {
  return `<div class="${cls} aic" data-ip="${p}" style="${style || ""}"><span>${letters}</span><img alt="" decoding="async"></div>`;
}
function hydrateIcons(root) {
  (root || document).querySelectorAll(".aic img:not([data-h])").forEach(img => {
    img.dataset.h = "1";
    const p = img.parentNode.dataset.ip;
    img.onload = () => { if (img.naturalWidth > 1) img.parentNode.classList.add("has"); };
    img.onerror = () => {
      const st = img.dataset.st;
      if (st === "k") { img.dataset.st = "f"; img.src = `icons/${p}.png?v=${ICON.v}`; }
      else if (st === "f") { img.dataset.st = "x"; askIcon(p); }
    };
    if (ICON.ksu) { img.dataset.st = "k"; img.src = "ksu://icon/" + p; }
    else { img.dataset.st = "f"; img.src = `icons/${p}.png?v=${ICON.v}`; }
  });
}
function askIcon(p) {
  if (!HAS_API || ICON.asked.has(p)) return;
  ICON.asked.add(p); ICON.q.add(p);
  clearTimeout(ICON.tm);
  ICON.tm = setTimeout(async () => {
    const list = [...ICON.q]; ICON.q.clear();
    await core(`icons ${list.join(" ")}`);
    [1200, 3500, 8000, 15000].forEach(d => setTimeout(() => retryIcons(list), d));
  }, 250);
}
function retryIcons(list) {
  ICON.v = Date.now();
  document.querySelectorAll(".aic:not(.has)").forEach(el => {
    if (!list.includes(el.dataset.ip)) return;
    const img = el.querySelector("img"); img.dataset.st = "r";
    img.onerror = null; img.src = `icons/${el.dataset.ip}.png?v=${ICON.v}`;
  });
}
function loadLabels(pkgs) { // real app names when the manager exposes getPackagesInfo
  if (!HAS_API || typeof ksu.getPackagesInfo !== "function") return;
  const need = pkgs.filter(p => p && !LABELS[p]); if (!need.length) return;
  try { JSON.parse(ksu.getPackagesInfo(JSON.stringify(need))).forEach(i => { if (i && i.packageName && i.appLabel) LABELS[i.packageName] = i.appLabel; }); } catch(e) {}
}
new MutationObserver(() => hydrateIcons()).observe(document.documentElement, { childList:true, subtree:true });


/* ---------------- state ---------------- */
let S = { settings:{}, compat:{}, games:[] };
const store = { m:{}, get(k){ try { return localStorage.getItem(k); } catch(e) { return this.m[k] || null; } }, set(k, v){ this.m[k] = v; try { localStorage.setItem(k, v); } catch(e) {} } };
let INFO = {}, L, LANG = "pt", PAGE = store.get("apo2_page") || "lab", pending = 0;
let DIAG = null, BENCH = null, BENCHING = false, DRAIN = null, BLOAT = null, HEALTH = null;
try { DIAG = JSON.parse(store.get("apo2_diag") || "null"); BENCH = JSON.parse(store.get("apo2_bench") || "null"); } catch(e) {}

async function fetchJ(name) {
  if (!HAS_API) return null;
  try { const r = await fetch(name + "?t=" + Date.now(), { cache:"no-store" }); if (!r.ok) return null; return JSON.parse(await r.text()); } catch(e) { return null; }
}
async function pullState() { const j = await fetchJ("state.json"); if (j && j.settings) { S = j; return true; } return false; }
async function coreRaw(args) { const out = await core(args); const a = out.search(/[\[{]/); const b = Math.max(out.lastIndexOf("}"), out.lastIndexOf("]")); try { return JSON.parse(out.slice(a, b + 1)); } catch(e) { return null; } }

/* ---------------- i18n ---------------- */
function pickLang() {
  const saved = store.get("apo_lang"); if (saved && I18N[saved]) return saved;
  const n = (navigator.language || "en").toLowerCase();
  if (n.startsWith("pt")) return "pt"; if (n.startsWith("es")) return "es"; if (n.startsWith("id") || n.startsWith("in")) return "id"; return "en";
}
const t = (k, v) => { let s = k.split(".").reduce((o, p) => o && o[p], L) ?? k; if (v) for (const x in v) s = s.replace("{" + x + "}", v[x]); return s; };
function applyLang() { L = I18N[LANG]; document.documentElement.lang = LANG; $("langCode").textContent = LANG.toUpperCase(); }

/* ---------------- helpers ---------------- */
const $ = id => document.getElementById(id);
function toast(m) { const el = $("toast"); el.textContent = m; el.classList.add("on"); clearTimeout(toast.h); toast.h = setTimeout(() => el.classList.remove("on"), 2300); }
function sheet(html) { $("sheetBody").innerHTML = html; $("sheet").classList.add("on"); $("scrim").classList.add("on"); $("sheet").scrollTop = 0; }
function closeSheet() { $("sheet").classList.remove("on"); $("scrim").classList.remove("on"); }
$("scrim").onclick = closeSheet;
const vib = () => { try { navigator.vibrate && navigator.vibrate(12); } catch(e){} };
const okc = c => !c || S.compat[c] !== 0;
const fmt = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === "en" ? "," : ".");
const esc = s => String(s || "").replace(/[<>&"]/g, c => ({ "<":"&lt;", ">":"&gt;", "&":"&amp;", '"':"&quot;" })[c]);
const pkgName = p => LABELS[p] || BLOAT_NAMES[p] || gname(p);

/* ---------------- icons ---------------- */
const I = {
  lab:'<path d="M9 3h6M10 3v6L4.5 19A1.5 1.5 0 0 0 6 21h12a1.5 1.5 0 0 0 1.5-2L14 9V3"/><path d="M7.5 15h9"/>',
  apps:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  system:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  games:'<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 11v3M5.5 12.5h3"/><circle cx="16" cy="11.5" r=".8"/><circle cx="18" cy="13.5" r=".8"/>',
  more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
  play:'<path d="M6 4l14 8-14 8z"/>', bolt:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  off:'<path d="M12 3v8"/><path d="M6.3 6.8a8 8 0 1 0 11.4 0"/>', balance:'<path d="M12 3v18M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z"/>',
  perf:'<path d="M12 14l4-4"/><path d="M3.3 19a10 10 0 1 1 17.4 0"/>', extreme:'<path d="M12 2c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  drain:'<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 11v2M7 10v4M11 10v4"/>', bloat:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6"/>',
  sleep:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>', code:'<path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/>',
  rocket:'<path d="M5 15c-1.5 1.5-2 5-2 5s3.5-.5 5-2M14 4c4-1 6 1 6 1s2 2 1 6l-7 7-7-7z"/><circle cx="15" cy="9" r="1.5"/>',
  clean:'<path d="M12 3l1.8 4.7L18.5 9l-4.7 1.8L12 15.5l-1.8-4.7L5.5 9l4.7-1.3z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', turbo:'<path d="M5 12h14M13 6l6 6-6 6"/>', renderer:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  hz:'<path d="M3 12h4l3-8 4 16 3-8h4"/>', touch:'<path d="M9 11V5a2 2 0 1 1 4 0v6"/><path d="M13 10a2 2 0 1 1 4 0v4a7 7 0 0 1-7 7h-.5A6.5 6.5 0 0 1 4 15.5V13a2 2 0 1 1 4 0"/>',
  ram:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10v4M11 10v4M15 10v4"/>', hidden:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><path d="M3 3l18 18"/>',
  dns:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>', gameauto:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  gamednd:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M3 3l18 18"/>', jank:'<path d="M3 3v18h18"/><path d="M7 15l4-6 3 4 5-7"/>',
  thermal:'<path d="M14 14.8V5a2 2 0 1 0-4 0v9.8a4 4 0 1 0 4 0z"/>', restore:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  compat:'<path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/>', log:'<path d="M5 4h14v16H5zM9 8h6M9 12h6M9 16h3"/>',
  scan:'<path d="M3 7V3h4M21 7V3h-4M3 17v4h4M21 17v4h-4M7 12h10"/>', plus:'<path d="M12 5v14M5 12h14"/>', trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  phone:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>'
};
const svg = k => `<svg viewBox="0 0 24 24">${I[k] || ""}</svg>`;
const BLOAT_NAMES = {"com.facebook.katana":"Facebook","com.facebook.orca":"Messenger","com.instagram.android":"Instagram","com.whatsapp":"WhatsApp","com.whatsapp.w4b":"WhatsApp Business","com.zhiliaoapp.musically":"TikTok","com.ss.android.ugc.trill":"TikTok","com.shopee.br":"Shopee","com.alibaba.aliexpresshd":"AliExpress","com.mercadolibre":"Mercado Livre","com.google.android.youtube":"YouTube","com.spotify.music":"Spotify","com.netflix.mediaclient":"Netflix","org.telegram.messenger":"Telegram","com.twitter.android":"X","com.kwai.video":"Kwai","com.snapchat.android":"Snapchat","br.com.brainweb.ifood":"iFood","com.nu.production":"Nubank","com.ubercab":"Uber","com.miui.msa.global":"MIUI System Ads","com.miui.analytics":"MIUI Analytics","com.miui.daemon":"MIUI Daemon","com.xiaomi.mipicks":"GetApps","com.facebook.appmanager":"Facebook App Manager","com.facebook.services":"Facebook Services","com.facebook.system":"Facebook App Installer","com.samsung.android.bixby.agent":"Bixby Voice","com.samsung.android.app.spage":"Samsung Free","com.samsung.android.app.tips":"Samsung Tips","com.netflix.partner.activation":"Netflix Activation","com.google.android.videos":"Google TV","com.opos.ads":"ColorOS Ads","com.heytap.pictorial":"Lock Screen Magazine","com.motorola.help":"Moto Help","com.mi.globalbrowser":"Mi Browser","com.miui.yellowpage":"Yellow Pages","com.xiaomi.glgm":"Xiaomi Games"};

/* ---------------- dock ---------------- */
const PAGES = ["lab","apps","system","games","more"];
function renderDock() {
  $("dock").innerHTML = PAGES.map(p => `<button data-p="${p}" class="${p === PAGE ? "on" : ""}">${svg(p)}${t("nav." + p)}</button>`).join("");
  $("dock").querySelectorAll("button").forEach(b => b.onclick = () => { PAGE = b.dataset.p; store.set("apo2_page", PAGE); renderDock(); render(true); window.scrollTo({ top:0 }); });
}

/* ---------------- shared rows ---------------- */
function tog(id, ic, c, extra) {
  const f = L.f[id] || [id, ""], on = S.settings[id] === "1", ok = okc(c);
  return `<div class="it${ok ? "" : " locked"}${on ? "" : " dim"}" data-row="${id}"><div class="ic">${svg(ic || id)}</div>
    <div class="tx"><b>${f[0]} <span class="q" data-i="${id}">?</span></b><small>${ok ? f[1] : "🔒 " + t("locked")}</small></div>
    <div class="sw ${on ? "on" : ""}" data-k="${id}"></div>${extra || ""}</div>`;
}
function segRow(id, ic, c, opts) {
  const f = L.f[id], v = S.settings[id], ok = okc(c);
  return `<div class="it col${ok ? "" : " locked"}" data-row="${id}"><div class="ic">${svg(ic || id)}</div>
    <div class="tx"><b>${f[0]} <span class="q" data-i="${id}">?</span></b><small>${ok ? f[1] : "🔒 " + t("locked")}</small></div>
    <div class="seg">${opts.map(([val, lab]) => `<button data-k="${id}" data-v="${val}" class="${v === val ? "on" : ""}">${lab === "keep" ? t("keep") : lab === "off" ? t("off") : lab}</button>`).join("")}</div></div>`;
}
function actRow(id, ic, btn, sub) {
  const f = L.f[id];
  return `<div class="it" data-row="${id}"><div class="ic">${svg(ic)}</div>
    <div class="tx"><b>${f[0]} <span class="q" data-i="${id}">?</span></b><small>${sub || f[1]}</small></div>${btn}</div>`;
}
function explain(id) {
  const f = L.f[id]; if (!f) return;
  sheet(`<h3>${f[0]}</h3><div class="lead">${f[1]}</div><p>${f[2]}</p>${f[3] ? `<div class="tip">${f[3]}</div>` : ""}`);
}

/* ---------------- LAB ---------------- */
function pageLab() {
  const b = BENCH, sc = b ? b.score : (S.bench ? +S.bench : 0);
  const delta = b && b.first && b.first !== b.score ? Math.round((b.score - b.first) * 100 / b.first) : null;
  const maxS = 1600, maxM = 4000;
  const bar = (lab, val, pct) => `<div class="br"><div><span>${lab}</span><b class="num">${val}</b></div><i><u style="width:${Math.max(4, Math.min(100, pct))}%"></u></i></div>`;
  const bars = b ? bar(t("b_single"), fmt(Math.round(400000 / b.single)), 400000 / b.single / maxS * 100)
      + bar(t("b_multi", { n:b.cores }), fmt(Math.round(400000 * b.cores / b.multi / 2)), 400000 * b.cores / b.multi / 2 / maxM * 100)
      + bar(t("b_io"), b.io + " MB/s", b.io / 6) + bar(t("b_ram"), fmt(b.ram) + " MB", b.ram / 120) : "";
  const m = S.settings.mode || "off";
  const d = DIAG, bad = d ? d.items.filter(x => !x.ok) : [];
  const ringC = !d ? "var(--c)" : d.score >= 80 ? "var(--ok)" : d.score >= 55 ? "var(--warn)" : "var(--bad)";
  return `<section class="lab"><div class="art"></div><div class="shade"></div><div class="in">
      <div class="kicker">${t("apo_score")}</div>
      <div class="big num ${sc ? "" : "empty"}" id="bigScore">${BENCHING ? "···" : sc ? fmt(sc) : t("not_tested")}</div>
      ${delta !== null ? `<div class="delta ${delta > 0 ? "" : "neutral"}">${delta > 0 ? "▲ +" : ""}${delta}% ${t("since_first")}</div>` : `<div class="delta neutral">${t("bench_hint")}</div>`}
      <div class="bars">${bars}</div>
      <button class="go ${BENCHING ? "run" : ""}" id="bBench">${svg("play")}<span>${BENCHING ? t("testing") : t("run_bench")}</span></button>
    </div></section>
    <div class="chips">
      <div class="chip"><b class="num">${S.mem ? S.mem + "%" : "—"}</b><span>${t("mem_free")}</span></div>
      <div class="chip"><b class="num">${S.storage ? S.storage + "%" : "—"}</b><span>${t("storage_free")}</span></div>
      <div class="chip"><b class="num" style="color:${S.temp >= 420 ? "var(--bad)" : S.temp >= 380 ? "var(--warn)" : "var(--ok)"}">${S.temp ? (S.temp / 10).toFixed(1) + "°" : "—"}</b><span>${t("temp")}</span></div>
    </div>
    <div class="card"><div class="ch"><div><h2>${t("mode_title")}</h2><small>${m === "custom" ? t("mode_custom") : t("mode_sub")}</small></div></div>
      <div class="modes">${["off","balance","perf","extreme"].map(x => `<button class="mode ${m === x ? "on" : ""} ${x === "extreme" && !okc("fixedperf") ? "custom" : ""}" data-m="${x}">${svg(x)}${t("m_" + x)}</button>`).join("")}</div>
      <div class="mdesc">${t("md_" + (m === "custom" ? "custom" : m))}</div></div>
    <div class="card"><div class="ch"><div><h2>${t("diag_title")}</h2><small>${d ? t("diag_found", { n:bad.length }) : t("diag_sub")}</small></div></div>
      <div class="health"><div class="ring" style="--p:${d ? d.score : 0};--rc:${ringC}"><b class="num">${d ? d.score : "?"}</b><small>${t("health")}</small></div>
        <div class="issues">${d ? (bad.length ? bad.slice(0, 5).map(x => `<div class="iss"><i></i><span>${t("d." + x.id)}</span><em>${esc(x.v)}</em></div>`).join("") : `<div class="iss ok"><i></i><span>${t("all_good")}</span></div>`)
          + (bad.length > 5 ? `<button class="more" id="bDiagAll">+${bad.length - 5} ${t("more")}</button>` : "") : `<div class="iss"><span style="color:var(--dim)">${t("diag_empty")}</span></div>`}</div></div>
      <div class="row2"><button class="btn" id="bDiag">${svg("scan")}${t("diagnose")}</button><button class="btn pri" id="bFix">${svg("bolt")}${t("fix_all")}</button></div></div>
    <div class="foot">${t("footer")}<br>v2.1 · ${t("backups", { n:S.backups || 0 })}</div>`;
}
async function runBench() {
  if (BENCHING) return; BENCHING = true; vib(); render();
  const r = await coreRaw("bench"); BENCHING = false;
  if (r && r.score) { BENCH = r; store.set("apo2_bench", JSON.stringify(r)); toast(t("bench_done", { s:fmt(r.score) })); } else toast("⚠ " + (LASTERR || "bench"));
  render();
}
async function runDiag(quiet) {
  if (!quiet) toast(t("diagnosing"));
  const r = await coreRaw("diagnose");
  if (r && r.items) { DIAG = r; store.set("apo2_diag", JSON.stringify(r)); }
  render();
}
function diagSheet() {
  sheet(`<h3>${t("diag_title")}</h3><div class="lead">${t("health")}: ${DIAG.score}/100</div><div class="list" style="margin-top:10px">${DIAG.items.map(x => `<div class="iss ${x.ok ? "ok" : ""}" style="padding:7px 0"><i></i><span>${t("d." + x.id)}</span><em>${esc(x.v)}</em></div>`).join("")}</div>`);
}

/* ---------------- APPS ---------------- */
function pageApps() {
  const dr = DRAIN, bl = BLOAT;
  const drainList = dr === null ? `<div class="empty">${t("drain_empty")}</div>` : dr.length ? dr.map(a => `<div class="it">${appIcon(a.p, "av", `background:linear-gradient(135deg,hsl(${hue(a.p)},65%,45%),hsl(${(hue(a.p)+50)%360},75%,35%))`, pkgName(a.p).slice(0,2).toUpperCase())}
      <div class="tx"><b>${esc(pkgName(a.p))}</b><small><span class="mah">${a.mah} mAh</span> · ${a.p}</small></div>
      <button class="mini ${a.r ? "on" : ""}" data-restrict="${a.p}" data-r="${a.r}">${a.r ? t("restricted") : t("restrict")}</button></div>`).join("") : `<div class="empty">${t("drain_none")}</div>`;
  const bloatList = bl === null ? `<div class="empty">${t("bloat_empty")}</div>` : bl.length ? bl.map(a => `<div class="it ${a.d ? "dim" : ""}">${appIcon(a.p, "av", "background:#1a2230;color:#8A96A8", svg("bloat"))}
      <div class="tx"><b>${esc(pkgName(a.p))}</b><small>${a.p}</small></div>
      <button class="mini ${a.d ? "" : "on"}" data-bloat="${a.p}" data-d="${a.d}">${a.d ? t("enable") : t("disable")}</button></div>`).join("") : `<div class="empty">${t("bloat_none")}</div>`;
  const lm = S.last_maint ? new Date(parseInt(S.last_maint) * 1000).toLocaleString(LANG, { day:"2-digit", month:"2-digit", hour:"2-digit", minute:"2-digit" }) : t("never");
  return `<div class="ttl">${t("sec.heavy")}</div>
    <div class="card"><div class="ch"><div><h2>${L.f.drain[0]} <span class="q" data-i="drain">?</span></h2><small>${L.f.drain[1]}</small></div><button class="mini" id="bDrain">${svg("scan")}</button></div>
      <div class="list">${drainList}</div></div>
    <div class="card"><div class="ch"><div><h2>${L.f.bloat[0]} <span class="q" data-i="bloat">?</span></h2><small>${bl ? t("bloat_found", { n:bl.filter(x => !x.d).length }) : L.f.bloat[1]}</small></div><button class="mini" id="bBloat">${svg("scan")}</button></div>
      <div class="list">${bloatList}</div></div>
    <div class="ttl">${t("sec.speed")}</div>
    <div class="card"><div class="list">
      ${actRow("compileall", "code", `<button class="mini" id="bCompile">${svg("rocket")}</button>`)}
      ${actRow("optapp", "rocket", `<button class="mini" id="bOptApp">${svg("plus")}</button>`)}
      ${actRow("clean", "clean", `<button class="mini" id="bClean">${svg("clean")}</button>`)}
      ${tog("hibernate", "sleep", "bucket")}
      ${tog("maint", "clock", "", "")}
      <div class="empty" style="text-align:left;padding:4px 0 0 50px">${t("last_maint")}: ${lm}${S.maint ? " · " + t("optimizing") : ""}</div>
    </div></div>
    <div class="foot">${t("apps_note")}</div>`;
}
async function loadDrain() { toast(t("analyzing")); DRAIN = (await coreRaw("drain")) || []; loadLabels(DRAIN.map(a => a.p)); render(); }
async function loadBloat() { BLOAT = (await coreRaw("bloat")) || []; loadLabels(BLOAT.map(a => a.p)); render(); }

/* ---------------- SYSTEM ---------------- */
function pageSystem() {
  return `<div class="ttl">${t("sec.ui")}</div><div class="card"><div class="list">
      ${tog("turbo", "turbo", "settings")}
      ${segRow("renderer", "renderer", "prop", [["keep","keep"],["skiagl","OpenGL"],["skiavk","Vulkan"]])}
      ${tog("smarthz", "hz", "hz")}
      ${tog("touch", "touch", "settings")}
    </div></div>
    <div class="ttl">${t("sec.bg")}</div><div class="card"><div class="list">
      ${tog("ram", "ram", "freezer")}
      ${tog("hidden", "hidden", "settings")}
      ${segRow("dns", "dns", "dns", [["off","off"],["cloudflare","Cloudflare"],["google","Google"],["adguard","AdGuard"]])}
    </div></div>
    <div class="ttl">${t("sec.protect")}</div><div class="card"><div class="list">
      ${tog("thermal", "thermal", "thermal")}
      <div class="empty" style="text-align:left;padding:4px 0 0 50px">${t("thermal_now")}: ${L.th[parseInt(S.thermal || "0") || 0]}${S.cooling ? " · " + t("cooling") : ""}</div>
    </div></div>`;
}

/* ---------------- GAMES ---------------- */
function pageGames() {
  const j = (S.jank || "").split(" ");
  const jank = j.length >= 5 && j[1] ? `<div class="jank"><div><b class="num" style="color:${+j[3] <= 5 ? "var(--ok)" : +j[3] <= 15 ? "var(--warn)" : "var(--bad)"}">${j[3]}%</b><span>${t("j_janky")}</span></div><div><b class="num">${j[4]}ms</b><span>${t("j_p90")}</span></div><div><b class="num">${fmt(j[1])}</b><span>${t("j_frames")}</span></div></div>
      <div class="empty">${esc(gname(j[0]))} · ${t("j_verdict_" + (+j[3] <= 5 ? "good" : +j[3] <= 15 ? "mid" : "bad"))}</div>` : `<div class="empty">${t("jank_empty")}</div>`;
  const g = S.games || [];
  const list = g.length ? g.map(p => `<div class="it" data-g="${p}">${appIcon(p, "av", `background:linear-gradient(135deg,hsl(${hue(p)},65%,45%),hsl(${(hue(p)+50)%360},75%,35%))`, gname(p).slice(0,2).toUpperCase())}
      <div class="tx"><b>${esc(gname(p))}</b><small>${S.ingame === p ? `<span class="tag ok">● ${t("in_game")}</span> ` : ""}${p}</small></div><button class="mini" data-gdel="${p}">${svg("trash")}</button></div>`).join("") : `<div class="empty">${t("no_list")}</div>`;
  return `<div class="ttl">${t("sec.boost")}</div><div class="card"><div class="list">${tog("gameauto", "gameauto", "")}${tog("gamednd", "gamednd", "dnd")}</div></div>
    <div class="card"><div class="ch"><div><h2>${L.f.jank[0]} <span class="q" data-i="jank">?</span></h2><small>${L.f.jank[1]}</small></div></div>${okc("jank") ? jank : `<div class="empty">🔒 ${t("locked")}</div>`}</div>
    <div class="ttl">${t("sec.list")}</div><div class="card"><div class="row2" style="margin-top:0"><button class="btn" id="bScan">${svg("scan")}${t("scan")}</button><button class="btn pri" id="bAdd">${svg("plus")}${t("add")}</button></div>
      <div class="list" style="margin-top:10px">${list}</div></div>`;
}

/* ---------------- MORE ---------------- */
function pageMore() {
  const names = { prop:"setprop debug", settings:"settings", devcfg:"device_config", blur:"Blur", hz:"> 60 Hz", freezer:"Freezer", trim:"Trim cache", art:"ART dexopt", compile:"Compile", dns:"Private DNS", gamemode:"Game Mode", fixedperf:"Fixed perf", saver:"Power mode", jank:"gfxinfo", icons:"Icons", dnd:"DND", notify:"Notify", bucket:"Standby", appops:"AppOps", drain:"Batterystats", thermal:"Thermal" };
  const h = HEALTH;
  return `<div class="ttl">${t("sec.device")}</div><div class="card"><div class="ch"><div><h2>${esc((INFO.brand ? INFO.brand.charAt(0).toUpperCase() + INFO.brand.slice(1) + " " : "") + (INFO.model || "Android"))}</h2><small>${esc(INFO.soc || INFO.gpu || "")}</small></div><span class="tag ok">${t("tier_" + (INFO.tier || "mid"))}</span></div>
      <div class="dev"><div><span>GPU</span><b>${esc((INFO.gpu || "—").split(",").slice(0, 2).join(","))}</b></div><div><span>RAM</span><b>${INFO.ram ? INFO.ram + " GB" : "—"}</b></div>
        <div><span>${t("display")}</span><b>${INFO.hz ? INFO.hz + " Hz" : "—"}</b></div><div><span>Android</span><b>${INFO.android || "—"}</b></div>
        <div><span>${t("battery")}</span><b>${h ? (h.level || "—") + "% · " + (h.temp ? (h.temp / 10).toFixed(1) + "°C" : "") : (S.bat ? S.bat + "%" : "—")}</b></div>
        <div><span>${t("bat_health")}</span><b>${h && h.cap ? h.cap + "%" : h && h.cycle ? h.cycle + " " + t("cycles") : h ? t("bh_" + (h.health === "2" ? "good" : "unk")) : "—"}</b></div></div></div>
    <div class="ttl">${t("sec.tools")}</div><div class="card"><div class="list">
      ${actRow("compat", "compat", `<button class="mini" id="bCompat">${svg("scan")}</button>`, t("compat_sub"))}
      <div class="clist">${Object.keys(names).map(k => `<div><span>${names[k]}</span><b class="${S.compat[k] === 0 ? "n" : "y"}">${S.compat[k] === 0 ? "✕" : "✓"}</b></div>`).join("")}</div>
      <div class="it" style="margin-top:10px"><div class="ic">${svg("log")}</div><div class="tx"><b>${t("log")}</b><small>${t("log_sub")}</small></div><button class="mini" id="bLog">${svg("log")}</button></div>
    </div></div>
    <div class="card"><div class="list">${actRow("restore", "restore", "", t("backups", { n:S.backups || 0 }))}</div><button class="btn bad full" id="bRestore">${svg("restore")}${t("restore_all")}</button></div>
    <div class="foot">${t("footer")}<br>v2.1</div>`;
}

/* ---------------- render + bind ---------------- */
function renderLive() {
  const m = S.settings.mode || "off", on = S.settings.enabled === "1", el = $("live");
  el.className = "live" + (!HAS_API ? "" : S.ingame ? " game" : on ? " on" : "");
  $("liveTxt").textContent = !HAS_API ? t("demo") : S.ingame ? gname(S.ingame) : on ? t("m_" + (m === "custom" ? "custom" : m)) : t("m_off");
}
function render(anim) {
  renderLive();
  const fn = { lab:pageLab, apps:pageApps, system:pageSystem, games:pageGames, more:pageMore }[PAGE] || pageLab;
  $("view").innerHTML = `<div class="${anim ? "page" : ""}">${fn()}</div>`;
  bind();
}
const on = (id, f) => { const e = $(id); if (e) e.onclick = f; };
function bind() {
  const v = $("view");
  v.querySelectorAll(".q").forEach(e => e.onclick = ev => { ev.stopPropagation(); explain(e.dataset.i); });
  v.querySelectorAll(".sw").forEach(e => e.onclick = () => { vib(); const k = e.dataset.k, nv = S.settings[k] === "1" ? "0" : "1"; e.classList.toggle("on", nv === "1"); e.closest(".it").classList.toggle("dim", nv !== "1"); setKey(k, nv); });
  v.querySelectorAll(".seg button").forEach(e => e.onclick = () => { vib(); e.parentNode.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === e)); setKey(e.dataset.k, e.dataset.v); });
  v.querySelectorAll(".mode").forEach(e => e.onclick = async () => { vib(); const m = e.dataset.m; S.settings.mode = m; S.settings.enabled = m === "off" ? "0" : "1"; render(); await coreJ(`mode ${m}`); toast(t("mode_set", { m:t("m_" + m) })); render(); });
  on("bBench", runBench);
  on("bDiag", () => runDiag());
  on("bDiagAll", diagSheet);
  on("bFix", async () => { vib(); toast(t("fixing")); const r = await coreRaw("fixall"); if (r && r.items) { DIAG = r; store.set("apo2_diag", JSON.stringify(r)); } await refreshState(); toast(t("fixed")); render(); });
  on("bDrain", loadDrain); on("bBloat", loadBloat);
  v.querySelectorAll("[data-restrict]").forEach(e => e.onclick = async () => { vib(); const p = e.dataset.restrict, nv = e.dataset.r === "1" ? "off" : "on"; await core(`restrict ${p} ${nv}`); const a = DRAIN.find(x => x.p === p); if (a) a.r = nv === "on" ? 1 : 0; toast(nv === "on" ? t("restricted_ok") : t("unrestricted_ok")); render(); });
  v.querySelectorAll("[data-bloat]").forEach(e => e.onclick = async () => {
    const p = e.dataset.bloat, dis = e.dataset.d === "1";
    const go = async () => { closeSheet(); await core(`debloat ${p} ${dis ? "off" : "on"}`); const a = BLOAT.find(x => x.p === p); if (a) a.d = dis ? 0 : 1; toast(dis ? t("enabled_ok") : t("disabled_ok")); render(); };
    if (dis) return go();
    sheet(`<h3>${t("disable")} ${esc(pkgName(p))}?</h3><p>${t("bloat_confirm")}</p><div class="row2"><button class="btn" id="cNo">${t("cancel")}</button><button class="btn pri" id="cYes">${t("disable")}</button></div>`);
    on("cNo", closeSheet); on("cYes", go);
  });
  on("bCompile", async () => { vib(); await core("compileall"); toast(t("compile_started")); });
  on("bOptApp", () => appPicker(t("pick_app"), true, async p => { await core(`optapp ${p}`); toast(t("optapp_started", { a:gname(p) })); }));
  on("bClean", async () => { vib(); toast(t("cleaning")); const r = await coreRaw("clean"); toast(r ? t("cleaned", { mb:r.freed, ram:r.ram }) : t("done")); refreshState().then(render); });
  on("bScan", async () => { toast(t("detecting")); await coreJ("scan"); toast(t("scan_done", { n:(S.games || []).length })); render(); });
  on("bAdd", () => appPicker(t("add"), false, async p => { await coreJ(`gadd ${p}`); render(); toast(t("saved")); }));
  v.querySelectorAll("[data-gdel]").forEach(e => e.onclick = async () => { await coreJ(`gdel ${e.dataset.gdel}`); render(); });
  on("bCompat", async () => { toast(t("testing")); await coreJ("compat"); toast(t("tested")); render(); });
  on("bLog", async () => { const l = (await core("log")).trim(); sheet(`<h3>${t("log")}</h3><pre class="log">${esc(l || t("empty_log"))}</pre>`); });
  on("bRestore", () => { sheet(`<h3>${t("restore_all")}</h3><p>${t("restore_q")}</p><div class="row2"><button class="btn" id="cNo">${t("cancel")}</button><button class="btn bad" id="cYes">${t("yes")}</button></div>`);
    on("cNo", closeSheet); on("cYes", async () => { closeSheet(); await coreJ("restore"); BLOAT = null; DRAIN = null; toast(t("restore_ok")); render(); }); });
}
const SETQ = {}, WANT = {};
function setKey(k, v) {
  S.settings[k] = v; WANT[k] = v;
  if (!["lang","hibernate","thermal","maint","gameauto","gamednd"].includes(k) && S.settings.mode !== "off") S.settings.mode = "custom";
  if (!SETQ[k]) pending++;
  clearTimeout(SETQ[k]);
  SETQ[k] = setTimeout(async () => {
    const val = WANT[k]; await coreJ(`set ${k} ${val}`);
    if (WANT[k] === val) { delete SETQ[k]; delete WANT[k]; pending = Math.max(0, pending - 1); }
    for (const x in WANT) S.settings[x] = WANT[x];
    renderLive();
  }, 250);
}
async function appPicker(title, allApps, pick) {
  sheet(`<h3>${title}</h3><input class="searchbox" id="q" placeholder="${t("search")}"><div class="seg" id="af" style="margin-bottom:8px"><button data-a="0" class="${allApps ? "" : "on"}">${t("only_games")}</button><button data-a="1" class="${allApps ? "on" : ""}">${t("show_all")}</button></div><div class="applist" id="al"><div class="empty">${t("detecting")}</div></div>`);
  let apps = [], all = allApps, q = "";
  try { apps = (await coreRaw("apps")) || []; } catch(e) {}
  const have = new Set(allApps ? [] : S.games);
  const draw = () => {
    const list = apps.filter(a => !have.has(a.p) && (all || a.g) && (!q || a.p.toLowerCase().includes(q) || gname(a.p).toLowerCase().includes(q))).slice(0, 150);
    loadLabels(list.map(a => a.p));
    $("al").innerHTML = list.map(a => `<button class="arow" data-p="${a.p}">${appIcon(a.p, "ai", `background:linear-gradient(135deg,hsl(${hue(a.p)},65%,45%),hsl(${(hue(a.p)+50)%360},75%,35%))`, pkgName(a.p).slice(0,2).toUpperCase())}<div class="tx2"><b>${a.g ? "🎮 " : ""}${esc(pkgName(a.p))}</b><small>${a.p}</small></div></button>`).join("") || `<div class="empty">${t("no_games")}</div>`;
    $("al").querySelectorAll("button").forEach(b => b.onclick = () => { closeSheet(); pick(b.dataset.p); });
  };
  document.querySelectorAll("#af button").forEach(b => b.onclick = () => { all = b.dataset.a === "1"; document.querySelectorAll("#af button").forEach(x => x.classList.toggle("on", x === b)); draw(); });
  draw(); $("q").oninput = e => { q = e.target.value.toLowerCase().trim(); draw(); };
}
function langSheet() {
  sheet(`<h3>${t("lang")}</h3><div class="langs">${Object.keys(I18N).map(k => `<button data-l="${k}" class="${k === LANG ? "on" : ""}">${I18N[k]._name}</button>`).join("")}</div>`);
  document.querySelectorAll(".langs button").forEach(b => b.onclick = () => { LANG = b.dataset.l; store.set("apo_lang", LANG); core(`setq lang ${LANG}`); closeSheet(); applyLang(); renderDock(); render(); });
}
$("langBtn").onclick = langSheet;
async function refreshState() { if (!(await pullState())) await coreJ("status"); }

/* ---------------- demo (browser preview) ---------------- */
let DM = null;
function demo(cmd) {
  if (!DM) DM = { settings:{enabled:"1",mode:"perf",turbo:"1",touch:"1",renderer:"skiavk",smarthz:"1",ram:"1",maint:"1",hidden:"1",dns:"cloudflare",gameauto:"1",gamednd:"0",hibernate:"1",thermal:"1",lang:"auto"},
    compat:{prop:1,settings:1,devcfg:1,blur:1,hz:1,freezer:1,trim:1,art:1,compile:1,dns:1,gamemode:1,fixedperf:1,saver:1,jank:1,dnd:1,notify:1,bucket:1,appops:1,drain:1,thermal:1},
    games:["com.dts.freefireth","com.mobile.legends","com.roblox.client"], ingame:"", thermal:"0", cooling:false, loop:true, backups:22, mem:"41", bat:"78", temp:"336", charging:false, maint:false, last_maint:"1760140800", storage:"38", score:"", restricted:1, hibernated:6, debloated:2, jank:"com.dts.freefireth 5400 162 3.00 14 1760180000", bench:"" };
  const a = cmd.split('core.sh" ').pop() || ""; const [c, k, v] = a.split(" ");
  if (c === "info") return JSON.stringify({model:"Redmi Note 13 Pro",brand:"xiaomi",android:"14",sdk:"34",gpu:"Qualcomm, Adreno (TM) 710, OpenGL ES 3.2",vendor:"adreno",tier:"mid",ram:"8",hz:"120",size:"1220x2712",soc:"SM7435"});
  if (c === "bench") return JSON.stringify({score:3480,single:640,multi:1180,cores:8,io:186,ram:3420,first:2950});
  if (c === "diagnose" || c === "fixall") return JSON.stringify(c === "fixall" ? {score:92,items:[{id:"ram",ok:1,v:"41%"},{id:"storage",ok:1,v:"38%"},{id:"anim",ok:1,v:"0.5x"},{id:"bloat",ok:0,v:"3"}]} : {score:58,items:[{id:"ram",ok:1,v:"41%"},{id:"storage",ok:1,v:"38%"},{id:"temp",ok:1,v:"33°C"},{id:"anim",ok:0,v:"1.0x"},{id:"blur",ok:0,v:"on"},{id:"scans",ok:0,v:"on"},{id:"mobiledata",ok:0,v:"on"},{id:"debug",ok:1,v:"off"},{id:"dns",ok:0,v:"off"},{id:"freezer",ok:0,v:"off"},{id:"bloat",ok:0,v:"5"}]});
  if (c === "drain") return JSON.stringify([{p:"com.facebook.katana",mah:"142.5",r:0},{p:"com.zhiliaoapp.musically",mah:"96.1",r:1},{p:"com.shopee.br",mah:"41.8",r:0}]);
  if (c === "bloat") return JSON.stringify([{p:"com.miui.msa.global",d:0},{p:"com.miui.analytics",d:0},{p:"com.facebook.appmanager",d:1},{p:"com.xiaomi.mipicks",d:0}]);
  if (c === "health") return JSON.stringify({level:"78",temp:"336",health:"2",cycle:"312",cap:"91"});
  if (c === "clean") return JSON.stringify({freed:"412",free:"40210",ram:"58"});
  if (c === "apps") return JSON.stringify([{p:"com.supercell.brawlstars",g:1},{p:"com.whatsapp",g:0},{p:"com.instagram.android",g:0}]);
  if (c === "log") return "10-11 09:12:01 mode perf\n10-11 09:40:02 game on: com.dts.freefireth\n10-11 03:10:40 maintenance done";
  if (c === "set") { DM.settings[k] = v; if (DM.settings.mode !== "off" && !["lang","hibernate","thermal","maint","gameauto","gamednd"].includes(k)) DM.settings.mode = "custom"; }
  if (c === "mode") { DM.settings.mode = k; DM.settings.enabled = k === "off" ? "0" : "1"; }
  if (c === "gadd") DM.games.push(k); if (c === "gdel") DM.games = DM.games.filter(x => x !== k);
  if (["restrict","debloat","optapp","compileall"].includes(c)) return '{"ok":true}';
  return JSON.stringify(DM);
}

/* ---------------- boot ---------------- */
(async () => {
  if (HAS_API && ksu.fullScreen) { try { ksu.fullScreen(true); } catch(e){} }
  LANG = pickLang(); applyLang(); renderDock();
  await refreshState();
  if (S.settings.lang && S.settings.lang !== "auto" && I18N[S.settings.lang] && !store.get("apo_lang")) { LANG = S.settings.lang; applyLang(); renderDock(); }
  loadLabels(S.games || []);
  render(true);
  INFO = (await fetchJ("info.json")) || {};
  if (!INFO.model) { try { INFO = (await coreRaw("info")) || {}; } catch(e) {} }
  if (!DIAG) runDiag(true);
  HEALTH = await coreRaw("health");
  if (PAGE === "more") render();
  setInterval(async () => {
    if (BENCHING || pending || document.hidden || $("sheet").classList.contains("on")) return;
    const old = S.ingame + S.thermal + S.mem + S.temp;
    if (!(await pullState())) return;
    renderLive(); if (old !== S.ingame + S.thermal + S.mem + S.temp && PAGE !== "apps") render();
  }, 4000);
})();
})();
