#!/system/bin/sh
MODDIR=${0%/*}
CFG=/data/local/tmp/void_gpu_engine
[ -f "$CFG/loop.pid" ] && kill "$(cat "$CFG/loop.pid")" 2>/dev/null
MODDIR=$MODDIR sh "$MODDIR/core.sh" wipe >/dev/null 2>&1
