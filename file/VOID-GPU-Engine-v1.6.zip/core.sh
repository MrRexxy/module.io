#!/system/bin/sh
# VOID GPU Engine - core
# ADB only (shell uid). No root. Every change saves the original value once and
# restores it exactly when the function is turned off or the module is removed.

MODDIR=${MODDIR:-${0%/*}}
CFG=/data/local/tmp/void_gpu_engine   # outside the module dir: survives updates
[ -n "$VGPU_CFG" ] && CFG=$VGPU_CFG
BK=$CFG/bk          # global backups: one file per key, holds the original value
GBK=$CFG/gbk        # in-game backups (reverted when the game closes)
SET=$CFG/settings.conf
GAMES=$CFG/games.conf
LOG=$CFG/engine.log
mkdir -p "$BK" "$GBK"

# ---------------------------------------------------------------- defaults
DEFAULTS='enabled=0
renderer=keep
nomsaa=1
debugclean=1
noblur=0
anim=keep
refresh=1
resolution=keep
gamemode=1
scale=1.0
fps=0
driver=0
angle=0
gminrefresh=1
fixedperf=1
nosaver=1
compile=1
freeram=1
freezer=0
cached=0
thermal=1
weak=0
autodetect=1
lang=auto'

KNOWN_GAMES='com.dts.freefireth com.dts.freefiremax com.activision.callofduty.shooter com.garena.game.codm com.tencent.ig com.pubg.imobile com.pubg.krmobile com.vng.pubgmobile com.rekoo.pubgm com.tencent.tmgp.pubgmhd com.mobile.legends com.mobiin.gp com.riotgames.league.wildrift com.levelinfinite.sgameGlobal com.tencent.tmgp.sgame com.pokemon.unite com.supercell.brawlstars com.supercell.clashofclans com.supercell.clashroyale com.gameloft.android.ANMP.GloftA9HM com.konami.pesam jp.konami.pesam com.ea.gp.fifamobile com.miHoYo.GenshinImpact com.HoYoverse.hkrpgoversea com.kurogame.wutheringwaves.global com.roblox.client com.mojang.minecraftpe com.netease.newspike com.proximabeta.mf.uamo com.farlightgames.farlight84.gp com.YoStarEN.Arknights com.gravity.romg com.ngame.allstar.eu com.tencent.lolm com.blizzard.diablo.immortal com.carxtech.sr com.firsttouchgames.dls7 com.criticalforceentertainment.criticalops com.axlebolt.standoff2 com.innersloth.spacemafia com.kiloo.subwaysurf com.imangi.templerun2 com.sega.pjsekai com.hypergryph.arknights com.garena.game.df com.netease.idv.googleplay com.blueteam.bloodstrike'

cfg_init() {
  [ -f "$CFG/.init6" ] && [ -f "$SET" ] && [ -f "$GAMES" ] && return 0
  [ -f "$SET" ] || echo "$DEFAULTS" > "$SET"
  # add keys introduced by newer versions
  echo "$DEFAULTS" | while IFS='=' read -r k v; do
    grep -q "^$k=" "$SET" || echo "$k=$v" >> "$SET"
  done
  [ -f "$GAMES" ] || touch "$GAMES"
  rm -f "$CFG"/.init*; touch "$CFG/.init6"
}
get() { grep -m1 "^$1=" "$SET" 2>/dev/null | cut -d= -f2-; }
put() {
  case "$1" in *[!a-z0-9_]*|'') return 1;; esac
  case "$2" in *[!A-Za-z0-9._-]*) return 1;; esac
  if grep -q "^$1=" "$SET"; then
    sed -i "s|^$1=.*|$1=$2|" "$SET"
  else
    echo "$1=$2" >> "$SET"
  fi
}
on() { [ "$(get "$1")" = 1 ]; }
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; [ "$(wc -l < "$LOG")" -gt 400 ] && sed -i '1,200d' "$LOG"; }
sdk() { getprop ro.build.version.sdk; }

# ---------------------------------------------------------------- backup helpers
# id = file name in backup dir; type: s:<ns>:<key> | p:<prop> | d:<ns>:<key>
_read() {
  case "$1" in
    s:*) set -- $(echo "$1" | tr ':' ' '); settings get "$2" "$3" 2>/dev/null ;;
    p:*) getprop "${1#p:}" ;;
    d:*) set -- $(echo "$1" | tr ':' ' '); device_config get "$2" "$3" 2>/dev/null ;;
  esac
}
_write() { # $1 type, $2 value ("null"/"" means delete)
  local t="$1" v="$2"
  case "$t" in
    s:*) set -- $(echo "$t" | tr ':' ' ')
         if [ "$v" = null ] || [ -z "$v" ]; then settings delete "$2" "$3" >/dev/null 2>&1
         else settings put "$2" "$3" "$v" >/dev/null 2>&1; fi ;;
    p:*) setprop "${t#p:}" "$v" >/dev/null 2>&1 ;;
    d:*) set -- $(echo "$t" | tr ':' ' ')
         if [ "$v" = null ] || [ -z "$v" ]; then device_config delete "$2" "$3" >/dev/null 2>&1
         else device_config put "$2" "$3" "$v" >/dev/null 2>&1; fi ;;
  esac
}
_fn() { echo "$1" | tr ':/' '__'; }
# set with backup: dir type value
bset() {
  local f="$1/$(_fn "$2")"
  [ -f "$f" ] || { printf '%s\n%s' "$2" "$(_read "$2")" > "$f"; }
  _write "$2" "$3"
}
# restore one: dir type
brestore() {
  local f="$1/$(_fn "$2")"
  [ -f "$f" ] || return 0
  _write "$2" "$(sed -n 2p "$f")"
  rm -f "$f"
}
brestore_all() {
  for f in "$1"/*; do
    [ -f "$f" ] || continue
    _write "$(sed -n 1p "$f")" "$(sed -n 2p "$f")"
    rm -f "$f"
  done
}

# ---------------------------------------------------------------- device info
max_hz() {
  [ -s "$CFG/maxhz" ] && { cat "$CFG/maxhz"; return; }
  _max_hz | tee "$CFG/maxhz"
}
_max_hz() {
  dumpsys display 2>/dev/null | grep -oE '(fps|refreshRate|renderFrameRate)=[0-9]+(\.[0-9]+)?' \
    | cut -d= -f2 | awk 'BEGIN{m=60}{v=int($1+0.5); if(v>m && v<=240)m=v}END{print m}'
}
phys_size() {
  [ -s "$CFG/physsize" ] && { cat "$CFG/physsize"; return; }
  wm size 2>/dev/null | grep -m1 Physical | grep -oE '[0-9]+x[0-9]+' | tee "$CFG/physsize"
}
gpu_str() {
  local g
  g=$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES:' | sed 's/.*GLES: *//')
  [ -z "$g" ] && g="$(getprop ro.hardware.egl) $(getprop ro.board.platform)"
  echo "$g" | tr -d '"\\'
}
gpu_vendor() {
  case "$(gpu_str)" in
    *Adreno*|*Qualcomm*) echo adreno ;;
    *Immortalis*|*Mali*|*ARM*) echo mali ;;
    *PowerVR*|*Imagination*) echo powervr ;;
    *Xclipse*|*Samsung*) echo xclipse ;;
    *) echo other ;;
  esac
}
ram_gb() { awk '/MemTotal/{printf "%d", ($2/1048576)+0.5}' /proc/meminfo; }
tier() {
  local g r; g="$(gpu_str)"; r=$(ram_gb)
  [ "${r:-4}" -lt 4 ] && { echo low; return; }
  case "$g" in
    *Mali-T*|*Mali-G31*|*Mali-G51*|*Mali-G52*|*Mali-G57*|*Mali-G68*|*PowerVR*GE8*|*PowerVR*Rogue*|*"Adreno (TM) 3"*|*"Adreno (TM) 4"*|*"Adreno (TM) 5"*|*"Adreno (TM) 60"*|*"Adreno (TM) 61"*) echo low ;;
    *"Adreno (TM) 7"[3-9]*|*"Adreno (TM) 8"*|*Immortalis*|*Mali-G7[1-9]*|*Mali-G7[1-9]0*|*Mali-G6[1-9]0*|*Xclipse*|*Mali-G720*|*Mali-G925*) echo high ;;
    *) echo mid ;;
  esac
}
recommended_renderer() {
  case "$(gpu_vendor)" in
    adreno|xclipse) echo skiavk ;;
    mali) [ "$(tier)" = low ] && echo skiagl || echo skiavk ;;
    *) echo skiagl ;;
  esac
}

# ---------------------------------------------------------------- compatibility
compat() {
  local s out; s=$(sdk); rm -f "$CFG/maxhz" "$CFG/physsize"
  out=$CFG/compat.conf; : > "$out"
  c() { echo "$1=$2" >> "$out"; }
  setprop debug.vgpu.probe 1 2>/dev/null; [ "$(getprop debug.vgpu.probe)" = 1 ] && c prop 1 || c prop 0
  setprop debug.vgpu.probe "" 2>/dev/null
  settings get global window_animation_scale >/dev/null 2>&1 && c settings 1 || c settings 0
  if device_config put vgpu_probe k 1 >/dev/null 2>&1 && [ "$(device_config get vgpu_probe k 2>/dev/null)" = 1 ]; then
    c devcfg 1; device_config delete vgpu_probe k >/dev/null 2>&1; else c devcfg 0; fi
  [ "$s" -ge 31 ] && cmd game help >/dev/null 2>&1 && c gamemode 1 || c gamemode 0
  [ "$s" -ge 33 ] && cmd game help 2>&1 | grep -q downscale && c gameset 1 || c gameset 0
  [ "$s" -ge 31 ] && c blur 1 || c blur 0
  cmd power help 2>&1 | grep -q fixed-performance && c fixedperf 1 || c fixedperf 0
  [ "$s" -ge 29 ] && c angle 1 || c angle 0
  [ -n "$(getprop ro.gfx.driver.0)$(getprop ro.gfx.driver.1)" ] && c driver 1 || c driver 0
  [ -n "$(phys_size)" ] && c wm 1 || c wm 0
  [ "$(max_hz)" -gt 60 ] && c hz 1 || c hz 0
  dumpsys thermalservice 2>/dev/null | grep -q 'Thermal Status' && c thermal 1 || c thermal 0
  [ "$s" -ge 30 ] && grep -q '^devcfg=1' "$out" && c freezer 1 || c freezer 0
  grep -q '^devcfg=1' "$out" && c cached 1 || c cached 0
  cmd package compile 2>&1 | grep -qiE 'compile|usage|error' && c compile 1 || c compile 0
}
cok() { [ "$(grep -m1 "^$1=" "$CFG/compat.conf" 2>/dev/null | cut -d= -f2)" != 0 ]; }

# ---------------------------------------------------------------- games
games_list() { awk 'NF{print $1}' "$GAMES"; }
game_field() { awk -v p="$1" -v i="$2" '$1==p{print $i; exit}' "$GAMES"; }
game_scale() { local v; v=$(game_field "$1" 2); [ -z "$v" ] || [ "$v" = g ] && v=$(get scale); echo "$v"; }
game_fps() { local v; v=$(game_field "$1" 3); [ -z "$v" ] || [ "$v" = g ] && v=$(get fps); echo "$v"; }
game_add() {
  case "$1" in *[!A-Za-z0-9._]*|'') return 1;; esac
  grep -q "^$1 " "$GAMES" || grep -qx "$1" "$GAMES" || echo "$1 g g" >> "$GAMES"
}
game_del() {
  case "$1" in *[!A-Za-z0-9._]*|'') return 1;; esac
  cmd game reset "$1" >/dev/null 2>&1
  sed -i "/^$1\( \|$\)/d" "$GAMES"
}
game_set() { # pkg scale fps  (g = use global)
  case "$1$2$3" in *[!A-Za-z0-9._]*) return 1;; esac
  game_add "$1"
  sed -i "s|^$1 .*|$1 $2 $3|" "$GAMES"
}
# ---- game detection (no root): known list > publisher/engine name > engine libs inside the APK
GAME_PAT='game|games|gameloft|supercell|tencent|garena|netease|mihoyo|hoyoverse|miniclip|activision|ubisoft|com\.ea\.|electronicarts|\.king\.|rovio|zynga|playrix|voodoo|outfit7|kiloo|imangi|nexon|square_?enix|bandainamco|sega|konami|lilith|moonton|mobile\.legends|yostar|funplus|ngame|roblox|mojang|dts\.|levelinfinite|proximabeta|krafton|pubg|riotgames|blizzard|bethesda|epicgames|scopely|playtika|moonactive|kabam|netmarble|ncsoft|com2us|gamevil|devsisters|smilegate|kurogame|hypergryph|papergames|farlight|habby|ketchapp|crazylabs|saygames|azurgames|amanotes|bigfish|glu\.|gameinsight|tapblaze|dreamgames|peak\.|socialpoint|naturalmotion|frogmind|dotemu|herocraft|rockstargames|take2|2k\.|wb\.|unity3d|criticalforce|axlebolt|carxtech|firsttouch|innersloth|chess|sudoku|solitaire|puzzle|racing|shooter|soccer|football|basket|minecraft|craft|clash|battle|arena|legends|ludo|domino|poker|casino|slots'
NOT_GAME_PAT='launcher|keyboard|inputmethod|wallpaper|theme|gallery|camera|browser|whatsapp|telegram|instagram|facebook|messenger|tiktok|youtube|spotify|netflix|bank|wallet|paypal|bradesco|itau|nubank|caixa|santander|bancointer|picpay|mercadopago|ifood|uber|99app|maps|waze|translate|vpn|cleaner|antivirus|recorder|gamebooster|gameturbo|gamespace|gamecenter|gameassistant|gamelauncher|com\.google\.android\.play\.games|axeron|axmanager|shizuku|termux|stream|discord|twitch'
ENGINE_PAT='libunity.so libil2cpp.so libUE4.so libUnreal.so libUnrealEngine libcocos2d libcocos2dcpp.so libcocos2djs.so libgodot_android.so libgdx.so libxlua.so libtolua.so libslua.so libSDL2.so libfmod.so libAkSoundEngine.so libyoyo.so librenpy libdefold libMyGame.so libgame.so assets/bin/Data/ libtersafe libanogs.so libgcloud.so libGameCore'
GCACHE="$CFG/gamecache"
ENGINE_ARGS=$(for e in $ENGINE_PAT; do printf "%s %s " -e "$e"; done)
is_game() { # pkg [base.apk] -> 0 game / 1 not
  local p="$1" paths key hit=0 a
  echo " $KNOWN_GAMES " | grep -q " $p " && return 0
  if [ -n "$2" ]; then paths="$2"; else paths=$(pm path "$p" 2>/dev/null | sed 's/^package://' | head -1); fi
  [ -n "$paths" ] || return 1
  key="$p $paths"
  a=${paths%/*}; for a in "$a"/split_config.arm64*.apk "$a"/split_config.armeabi*.apk "$a"/split_*.apk; do [ -f "$a" ] && case " $paths " in *" $a "*) ;; *) paths="$paths $a";; esac; done
  [ -f "$GCACHE" ] && a=$(grep -m1 "^$key " "$GCACHE" 2>/dev/null) && [ -n "$a" ] && { [ "${a##* }" = 1 ]; return; }
  for a in $paths; do
    [ -r "$a" ] || continue
    # zip central directory (file names) sits at the end of the apk
    tail -c 2500000 "$a" 2>/dev/null | grep -aqF $ENGINE_ARGS && { hit=1; break; }
  done
  [ "$hit" = 0 ] && ! echo "$p" | grep -qiE "$NOT_GAME_PAT" && echo "$p" | grep -qiE "$GAME_PAT" && hit=1
  echo "$p" | grep -qiE 'gamebooster|gameturbo|gamespace|gamecenter|gameassistant|gamelauncher|play\.games' && hit=0
  touch "$GCACHE"; sed -i "/^$p /d" "$GCACHE" 2>/dev/null; echo "$key $hit" >> "$GCACHE"
  [ "$hit" = 1 ]
}
pkgs_f() { # "base.apk pkg" for every third-party app, one pm call
  pm list packages -3 -f 2>/dev/null | sed 's/^package://' | awk '{i=match($0,/\.apk=/); if(i) print substr($0,1,i+3), substr($0,i+5)}' | sort -k2
}
detected_games() {
  pkgs_f | while read -r ap p; do
    [ -n "$p" ] && is_game "$p" "$ap" && echo "$p"
  done
}
scan_games() { # replace the auto list with what is really a game (keeps user-added entries and their settings)
  local found p
  [ -n "$(pkgs_f | head -1)" ] || return 0   # package list unavailable: change nothing
  found=$(detected_games)
  if [ -f "$GAMES" ]; then
    while read -r p rest; do
      [ -n "$p" ] || continue
      echo "$found" | grep -qx "$p" && continue
      grep -qx "$p" "$CFG/manual" 2>/dev/null && continue
      game_del "$p"
    done < "$GAMES"
  fi
  for p in $found; do game_add "$p"; done
}

# game mode intervention (persisted by GameManager on Android 13+)
apply_game_pkg() {
  local p="$1" sc fp args=""
  if on enabled && on gamemode && cok gamemode; then
    cmd game mode performance "$p" >/dev/null 2>&1
  fi
  if on enabled && cok gameset; then
    sc=$(game_scale "$p"); fp=$(game_fps "$p")
    [ -n "$THERMAL_SCALE" ] && sc=$THERMAL_SCALE
    [ -n "$THERMAL_FPS" ] && fp=$THERMAL_FPS
    if [ "$sc" != 1.0 ] && [ "$sc" != 1 ]; then args="$args --downscale $sc"; else args="$args --downscale disable"; fi
    if [ "$fp" != 0 ]; then args="$args --fps $fp"; else args="$args --fps disable"; fi
    on gamemode && args="--mode 2 $args"
    cmd game set $args "$p" >/dev/null 2>&1
  fi
}
reset_game_pkg() { cmd game reset "$1" >/dev/null 2>&1; }

# ---------------------------------------------------------------- global functions
apply_global() {
  local en=0; on enabled && en=1
  # 6 renderer
  r=$(get renderer)
  if [ $en = 1 ] && [ "$r" != keep ] && cok prop; then bset "$BK" p:debug.hwui.renderer "$r"; else brestore "$BK" p:debug.hwui.renderer; fi
  # 7 no forced MSAA
  if [ $en = 1 ] && on nomsaa && cok prop; then bset "$BK" p:debug.egl.force_msaa false; else brestore "$BK" p:debug.egl.force_msaa; fi
  # 8 debug cleanup
  for k in debug.hwui.overdraw debug.hwui.profile debug.hwui.show_dirty_regions debug.layout; do
    if [ $en = 1 ] && on debugclean && cok prop; then bset "$BK" p:$k false; else brestore "$BK" p:$k; fi
  done
  if [ $en = 1 ] && on debugclean; then bset "$BK" s:system:pointer_location 0; bset "$BK" s:system:show_touches 0
  else brestore "$BK" s:system:pointer_location; brestore "$BK" s:system:show_touches; fi
  # 9 no blur
  if [ $en = 1 ] && on noblur && cok blur; then bset "$BK" s:global:disable_window_blurs 1; else brestore "$BK" s:global:disable_window_blurs; fi
  # 10 animations
  a=$(get anim)
  for k in window_animation_scale transition_animation_scale animator_duration_scale; do
    if [ $en = 1 ] && [ "$a" != keep ]; then bset "$BK" s:global:$k "$a"; else brestore "$BK" s:global:$k; fi
  done
  # 11 max refresh lock
  if [ $en = 1 ] && on refresh && cok hz; then
    hz=$(max_hz); bset "$BK" s:system:peak_refresh_rate "$hz.0"; bset "$BK" s:system:min_refresh_rate "$hz.0"
  else brestore "$BK" s:system:peak_refresh_rate; [ -f "$GBK/$(_fn s:system:min_refresh_rate)" ] || brestore "$BK" s:system:min_refresh_rate; fi
  # 13/14 resolution
  rs=$(get resolution)
  if [ $en = 1 ] && [ "$rs" != keep ] && cok wm; then
    [ -f "$BK/wm_size" ] || wm size 2>/dev/null | grep -m1 Override | grep -oE '[0-9]+x[0-9]+' > "$BK/wm_size"
    if [ "$rs" = native ]; then wm size reset >/dev/null 2>&1
    else ps=$(phys_size); w=${ps%x*}; h=${ps#*x}
      wm size "$((w*85/100))x$((h*85/100))" >/dev/null 2>&1; fi
  elif [ -f "$BK/wm_size" ]; then
    o=$(cat "$BK/wm_size"); if [ -n "$o" ]; then wm size "$o" >/dev/null 2>&1; else wm size reset >/dev/null 2>&1; fi
    rm -f "$BK/wm_size"
  fi
  # 19 freezer
  if [ $en = 1 ] && on freezer && cok freezer; then
    bset "$BK" d:activity_manager_native_boot:use_freezer true; bset "$BK" s:global:cached_apps_freezer enabled
  else brestore "$BK" d:activity_manager_native_boot:use_freezer; brestore "$BK" s:global:cached_apps_freezer; fi
  # 20 fewer cached processes
  if [ $en = 1 ] && on cached && cok cached; then
    bset "$BK" d:activity_manager:max_cached_processes "$( [ "$(ram_gb)" -le 4 ] && echo 16 || echo 24 )"
  else brestore "$BK" d:activity_manager:max_cached_processes; fi
  # 4 game driver / 5 ANGLE  (per game list)
  list=$(games_list | tr '\n' ',' | sed 's/,$//')
  if [ $en = 1 ] && on driver && cok driver && [ -n "$list" ]; then
    bset "$BK" s:global:updatable_driver_production_opt_in_apps "$list"
  else brestore "$BK" s:global:updatable_driver_production_opt_in_apps; fi
  if [ $en = 1 ] && on angle && cok angle && [ -n "$list" ]; then
    vals=$(games_list | sed 's/.*/angle/' | tr '\n' ',' | sed 's/,$//')
    bset "$BK" s:global:angle_gl_driver_selection_pkgs "$list"
    bset "$BK" s:global:angle_gl_driver_selection_values "$vals"
  else brestore "$BK" s:global:angle_gl_driver_selection_pkgs; brestore "$BK" s:global:angle_gl_driver_selection_values; fi
  # 1/2/3 game mode per game
  for p in $(games_list); do
    if [ $en = 1 ]; then apply_game_pkg "$p"; else reset_game_pkg "$p"; fi
  done
}

# ---------------------------------------------------------------- in-game session
game_enter() {
  local p="$1"; log "game on: $p"
  echo "$p" > "$CFG/ingame"; state
  if on gminrefresh && cok hz; then hz=$(max_hz); bset "$GBK" s:system:min_refresh_rate "$hz.0"; fi
  if on fixedperf && cok fixedperf; then echo 1 > "$GBK/fixedperf"; cmd power set-fixed-performance-mode-enabled true >/dev/null 2>&1; fi
  if on nosaver; then bset "$GBK" s:global:low_power 0; cmd power set-mode 0 >/dev/null 2>&1; fi
  if on freeram; then am kill-all >/dev/null 2>&1; fi
  if on compile && cok compile; then
    vc=$(dumpsys package "$p" 2>/dev/null | grep -m1 versionCode | grep -oE 'versionCode=[0-9]+')
    if ! grep -qx "$p $vc" "$CFG/compiled" 2>/dev/null; then
      ( cmd package compile -m speed -f "$p" >/dev/null 2>&1 && { sed -i "/^$p /d" "$CFG/compiled" 2>/dev/null; echo "$p $vc" >> "$CFG/compiled"; log "compiled $p"; } ) &
    fi
  fi
  THERMAL_SCALE=""; THERMAL_FPS=""; TSTEP=0
}
game_exit() {
  local p; p=$(cat "$CFG/ingame" 2>/dev/null); log "game off: $p"
  [ -f "$GBK/fixedperf" ] && { cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1; rm -f "$GBK/fixedperf"; }
  brestore_all "$GBK"
  if [ -n "$TSTEP" ] && [ "$TSTEP" -gt 0 ] && [ -n "$p" ]; then THERMAL_SCALE=""; THERMAL_FPS=""; apply_game_pkg "$p"; fi
  TSTEP=0; rm -f "$CFG/ingame" "$CFG/thermal_now"; state
}
thermal_status() { dumpsys thermalservice 2>/dev/null | grep -m1 'Thermal Status' | grep -oE '[0-9]+'; }
thermal_tick() { # 21 thermal guard
  local p="$1" st sc fp
  on thermal && cok thermal && cok gameset || return
  st=$(thermal_status); st=${st:-0}
  [ "$(cat "$CFG/thermal_now" 2>/dev/null)" = "$st" ] || { echo "$st" > "$CFG/thermal_now"; state; }
  sc=$(game_scale "$p"); fp=$(game_fps "$p")
  if [ "$st" -ge 2 ] && [ "$TSTEP" -lt 3 ]; then
    TSTEP=$((TSTEP+1))
  elif [ "$st" -le 0 ] && [ "$TSTEP" -gt 0 ]; then
    TSTEP=$((TSTEP-1))
  else return; fi
  if [ "$TSTEP" = 0 ]; then THERMAL_SCALE=""; THERMAL_FPS=""
  else
    THERMAL_SCALE=$(awk -v s="$sc" -v t="$TSTEP" 'BEGIN{v=s-0.1*t; if(v<0.5)v=0.5; printf "%.1f", v}')
    if [ "$fp" -gt 60 ] 2>/dev/null; then THERMAL_FPS=60; elif [ "$TSTEP" -ge 3 ]; then THERMAL_FPS=45; else THERMAL_FPS=""; fi
  fi
  log "thermal $st step $TSTEP scale ${THERMAL_SCALE:-user} fps ${THERMAL_FPS:-user}"
  apply_game_pkg "$p"
}
fg_pkg() {
  dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' \
    | grep -oE '[A-Za-z0-9_.]+/' | head -1 | tr -d '/'
}
screen_on() { dumpsys power 2>/dev/null | grep -q 'mWakefulness=Awake'; }

loop() {
  echo $$ > "$CFG/loop.pid"
  local cur="" n=0 scr=1
  while true; do
    [ $((n % 4)) = 0 ] && { screen_on && scr=1 || scr=0; }
    if on enabled && on autodetect && [ "$scr" = 1 ]; then
      fg=$(fg_pkg)
      if [ -n "$fg" ] && grep -q "^$fg " "$GAMES"; then
        [ "$cur" != "$fg" ] && { [ -n "$cur" ] && game_exit; cur=$fg; game_enter "$fg"; }
        [ $((n % 4)) = 0 ] && thermal_tick "$fg"
      elif [ -n "$cur" ] && [ -n "$fg" ]; then game_exit; cur=""
      fi
      n=$((n+1)); sleep 4
    else
      [ -n "$cur" ] && { game_exit; cur=""; }
      n=0; sleep 10
    fi
  done
}
loop_running() { [ -f "$CFG/loop.pid" ] && kill -0 "$(cat "$CFG/loop.pid")" 2>/dev/null; }

# ---------------------------------------------------------------- presets
weak() {
  if [ "$1" = on ]; then
    on weak && return
    cp "$SET" "$CFG/weak.bak"
    for kv in scale=0.8 fps=60 noblur=1 anim=0.5 renderer=skiagl debugclean=1 nomsaa=1 freeram=1 thermal=1 fixedperf=0 cached=1; do
      put "${kv%%=*}" "${kv#*=}"; done
    put weak 1
  else
    [ -f "$CFG/weak.bak" ] || { put weak 0; return; }
    for k in scale fps noblur anim renderer debugclean nomsaa freeram thermal fixedperf cached; do
      put "$k" "$(grep -m1 "^$k=" "$CFG/weak.bak" | cut -d= -f2-)"; done
    rm -f "$CFG/weak.bak"; put weak 0
  fi
}
recommend() {
  put renderer "$(recommended_renderer)"
  [ "$(gpu_vendor)" = adreno ] && cok driver && put driver 1
  if [ "$(tier)" = low ]; then weak on; fi
}

# ---------------------------------------------------------------- background apply
# The WebUI must get an answer at once: the change is saved, then applied by a
# single background worker (one at a time, so backups never race).
apply_bg() {
  touch "$CFG/pending"
  [ -d "$CFG/lock" ] && [ -n "$(find "$CFG/lock" -maxdepth 0 -mmin +2 2>/dev/null)" ] && rmdir "$CFG/lock" 2>/dev/null
  MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" worker </dev/null >/dev/null 2>&1 &
}
worker() {
  mkdir "$CFG/lock" 2>/dev/null || return 0
  while [ -f "$CFG/pending" ]; do rm -f "$CFG/pending"; apply_global; done
  rmdir "$CFG/lock" 2>/dev/null
  state
}

# ---------------------------------------------------------------- json out
json_esc() { sed 's/\\/\\\\/g; s/"/\\"/g'; }
state() { # publish status for the WebUI to fetch() without blocking
  local w="$MODDIR/webroot"
  [ -d "$w" ] || return 0
  status_json > "$w/.state.tmp" 2>/dev/null && mv -f "$w/.state.tmp" "$w/state.json"
}
info_cache() { local w="$MODDIR/webroot"; info_json > "$w/.info.tmp" 2>/dev/null && mv -f "$w/.info.tmp" "$w/info.json"; cat "$w/info.json"; }
status_json() {
  printf '{"settings":{'
  awk -F= 'NF>=2{printf "%s\"%s\":\"%s\"", (n++?",":""), $1, substr($0, index($0,"=")+1)}' "$SET"
  printf '},"compat":{'
  awk -F= 'NF>=2{printf "%s\"%s\":%s", (n++?",":""), $1, $2}' "$CFG/compat.conf" 2>/dev/null
  printf '},"games":['
  awk 'NF{printf "%s{\"pkg\":\"%s\",\"scale\":\"%s\",\"fps\":\"%s\"}", (n++?",":""), $1, $2, $3}' "$GAMES"
  printf '],"applying":%s,"ingame":"%s","thermal":"%s","loop":%s,"backups":%s}\n' \
    "$( [ -d "$CFG/lock" ] && echo true || echo false)" "$(cat "$CFG/ingame" 2>/dev/null)" "$(cat "$CFG/thermal_now" 2>/dev/null)" \
    "$(loop_running && echo true || echo false)" "$(ls "$BK" | wc -l)"
}
info_json() {
  printf '{"model":"%s","brand":"%s","android":"%s","sdk":"%s","gpu":"%s","vendor":"%s","tier":"%s","ram":"%s","hz":"%s","size":"%s","rec":"%s","soc":"%s"}\n' \
    "$(getprop ro.product.model | json_esc)" "$(getprop ro.product.brand | json_esc)" "$(getprop ro.build.version.release)" "$(sdk)" \
    "$(gpu_str | json_esc)" "$(gpu_vendor)" "$(tier)" "$(ram_gb)" "$(max_hz)" "$(phys_size)" "$(recommended_renderer)" \
    "$(getprop ro.soc.model | json_esc)"
}
apps_json() { # picker: [{"p":pkg,"g":1|0}], detected games first
  local p yes="" no=""
  local ap
  for ap in $(pkgs_f | tr ' ' '|'); do
    p=${ap#*|}; ap=${ap%%|*}
    if is_game "$p" "$ap"; then yes="$yes $p"; else no="$no $p"; fi
  done
  { for p in $yes; do echo "$p 1"; done; for p in $no; do echo "$p 0"; done; } |
    awk 'BEGIN{printf "["} {printf "%s{\"p\":\"%s\",\"g\":%s}", (n++?",":""), $1, $2} END{print "]"}'
}

# ---------------------------------------------------------------- cli
cfg_init
case "$1" in
  status) status_json ;;
  info) info_cache ;;
  apps) apps_json ;;
  set) put "$2" "$3" && { log "set $2=$3"; apply_bg; } ;;
  setq) put "$2" "$3" ;;                      # set without applying
  apply) apply_global; status_json ;;
  worker) worker ;;
  enable) put enabled 1; log "enable"; apply_bg
          loop_running || { MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" loop </dev/null >/dev/null 2>&1 & }
          ;;
  disable) put enabled 0; log "disable"; [ -f "$CFG/ingame" ] && game_exit; apply_bg ;;
  weak) weak "$2"; log "weak $2"; apply_bg ;;
  recommend) recommend; log "recommend"; apply_bg ;;
  scan) scan_games; apply_bg ;;
  gadd) game_add "$2" && { grep -qx "$2" "$CFG/manual" 2>/dev/null || echo "$2" >> "$CFG/manual"; }; apply_bg ;;
  gdel) case "$2" in *[!A-Za-z0-9._]*|'') ;; *) sed -i "/^$2$/d" "$CFG/manual" 2>/dev/null;; esac; game_del "$2"; apply_bg ;;
  gset) game_set "$2" "$3" "$4"; on enabled && apply_game_pkg "$2" &
        ;;
  compile) for p in $(games_list); do cmd package compile -m speed -f "$p" >/dev/null 2>&1; done; echo '{"ok":true}' ;;
  compat) compat ;;
  restore) put enabled 0; [ -f "$CFG/ingame" ] && game_exit; brestore_all "$GBK"; apply_global; brestore_all "$BK"
           for p in $(games_list); do reset_game_pkg "$p"; done; log "restore all" ;;
  wipe) sh "$0" restore >/dev/null; rm -rf "$CFG" ;;
  reset) sh "$0" restore >/dev/null; echo "$DEFAULTS" > "$SET" ;;
  log) tail -n 60 "$LOG" 2>/dev/null ;;
  loop) loop_running && exit 0; loop ;;
  boot) [ -f "$CFG/compat.conf" ] || compat
        on enabled && apply_global
        state; info_cache >/dev/null
        loop_running || loop ;;
  state) state; echo '{"ok":true}' ;;
  *) echo "usage: core.sh status|info|set k v|enable|disable|apply|restore|compat|scan|gadd p|gdel p|gset p scale fps|weak on|off|recommend|log" ;;
esac
case "$1" in set|enable|disable|weak|recommend|scan|gadd|gdel|gset|compat|restore|reset) state; cat "$MODDIR/webroot/state.json" 2>/dev/null || status_json ;; setq) state ;; esac
