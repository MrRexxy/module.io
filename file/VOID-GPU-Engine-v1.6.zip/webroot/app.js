/* VOID GPU Engine - WebUI (KernelSU WebUI API, works in AxManager without root) */
(() => {
const ID = "void_gpu_engine";
/* Find the plugin folder: AxManager tells us (moduleInfo / PATH has <dir>/system/bin); fixed paths are only a fallback */
let MODDIR_JS = "";
try { if (window.ksu && ksu.moduleInfo) { const mi = JSON.parse(ksu.moduleInfo()); const md = mi.moduleDir || mi.dir || ""; MODDIR_JS = (md && typeof md === "object") ? String(md.path || md.absolutePath || "") : String(md); } } catch(e) {}
const CORE = `D='${MODDIR_JS}'; [ -f "$D/core.sh" ] || D=$(pwd); `
  + `if [ ! -f "$D/core.sh" ]; then OIFS=$IFS; IFS=:; for p in $PATH; do q=\${p%/system/bin}; [ "$q" != "$p" ] && [ -f "$q/core.sh" ] && { D=$q; break; }; done; IFS=$OIFS; fi; `
  + `[ -f "$D/core.sh" ] || for d in "$AXERONDIR/plugins/${ID}" /data/user_de/0/com.android.shell/axeron/plugins/${ID} /data/local/tmp/AxManager/plugins/${ID} /data/adb/modules/${ID}; do [ -f "$d/core.sh" ] && D=$d && break; done; `
  + `[ -f "$D/core.sh" ] || { echo "VOID: pasta do plugin nao encontrada. PATH=\${PATH%%:*} D=$D" >&2; exit 2; }; `
  + `MODDIR=$D sh "$D/core.sh"`;
const HAS_API = typeof window.ksu !== "undefined" && typeof ksu.exec === "function";

/* ---------------- icons ---------------- */
const I = {
  games:'<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 11v3M5.5 12.5h3"/><circle cx="16" cy="11.5" r=".8"/><circle cx="18" cy="13.5" r=".8"/>',
  gfx:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  screen:'<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',
  perf:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  guard:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  gamemode:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  scale:'<path d="M4 9V4h5M20 15v5h-5M4 4l7 7M20 20l-7-7"/>',
  fps:'<circle cx="12" cy="13" r="8"/><path d="M12 13l4-3M12 2v3"/>',
  driver:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M9 9h6v6H9zM9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"/>',
  angle:'<path d="M3 20L12 4l9 16z"/><path d="M8 13h8"/>',
  renderer:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  nomsaa:'<path d="M4 20L20 4"/><rect x="4" y="4" width="16" height="16" rx="3"/>',
  debugclean:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  noblur:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  anim:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  refresh:'<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
  gminrefresh:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  resolution:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 9h3M8 9v3M16 15h-3M16 15v-3"/>',
  fixedperf:'<path d="M4 18h16M6 18V9M10 18V5M14 18v-7M18 18V8"/>',
  nosaver:'<rect x="2" y="7" width="17" height="10" rx="2"/><path d="M22 11v2M9 9l-2 3h4l-2 3"/>',
  compile:'<path d="M8 6l-6 6 6 6M16 6l6 6-6 6"/>',
  freeram:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10v4M11 10v4M15 10v4"/>',
  freezer:'<path d="M12 2v20M4 7l16 10M20 7L4 17"/>',
  cached:'<path d="M4 6h16M4 12h10M4 18h6"/>',
  thermal:'<path d="M14 14.8V5a2 2 0 1 0-4 0v9.8a4 4 0 1 0 4 0z"/>',
  weak:'<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/>',
  autodetect:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/>',
  recommend:'<path d="M12 2l2.4 6.9H21l-5.4 4 2 7-5.6-4.2L6.4 20l2-7L3 9h6.6z"/>',
  compat:'<path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/>',
  restore:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  log:'<path d="M5 4h14v16H5zM9 8h6M9 12h6M9 16h3"/>',
  plus:'<path d="M12 5v14M5 12h14"/>', scan:'<path d="M3 7V3h4M21 7V3h-4M3 17v4h4M21 17v4h-4M7 12h10"/>',
  chev:'<path d="M9 6l6 6-6 6"/>', trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>'
};
const svg = k => `<svg viewBox="0 0 24 24">${I[k]||""}</svg>`;

/* ---------------- functions (26) ---------------- */
const SCALES = [["1.0","100%"],["0.9","90%"],["0.8","80%"],["0.7","70%"],["0.5","50%"]];
const FPSV = [["0","off"],["30","30"],["45","45"],["60","60"],["90","90"],["120","120"]];
const TABS = [
  { id:"games", sections:[
    { s:"games_fx", f:[ {id:"gamemode",c:"gamemode"}, {id:"scale",c:"gameset",seg:SCALES}, {id:"fps",c:"gameset",seg:FPSV}, {id:"driver",c:"driver"}, {id:"angle",c:"angle"} ] },
    { s:"list", custom:"games" } ] },
  { id:"gfx", sections:[
    { s:"engine", f:[ {id:"renderer",c:"prop",seg:[["keep","keep"],["skiagl","OpenGL"],["skiavk","Vulkan"]]}, {id:"nomsaa",c:"prop"} ] },
    { s:"clean", f:[ {id:"debugclean",c:"prop"}, {id:"noblur",c:"blur"}, {id:"anim",c:"settings",seg:[["keep","keep"],["0.5","0.5x"],["0","off"]]} ] } ] },
  { id:"screen", sections:[
    { s:"hz", f:[ {id:"refresh",c:"hz"}, {id:"gminrefresh",c:"hz"} ] },
    { s:"res", f:[ {id:"resolution",c:"wm",seg:[["keep","keep"],["native","native"],["light","light"]]} ] } ] },
  { id:"perf", sections:[
    { s:"sustain", f:[ {id:"fixedperf",c:"fixedperf"}, {id:"nosaver",c:"settings"}, {id:"compile",c:"compile"} ] },
    { s:"mem", f:[ {id:"freeram"}, {id:"freezer",c:"freezer"}, {id:"cached",c:"cached"} ] } ] },
  { id:"guard", sections:[
    { s:"guard", f:[ {id:"thermal",c:"thermal",meter:true}, {id:"weak",act:"weak"} ] },
    { s:"smart", f:[ {id:"autodetect"} ], custom:"smart" },
    { s:"tools", custom:"tools" } ] }
];
const COUNTED = ["gamemode","scale","fps","driver","angle","renderer","nomsaa","debugclean","noblur","anim","refresh","gminrefresh","resolution","fixedperf","nosaver","compile","freeram","freezer","cached","thermal","autodetect"];

const GAME_NAMES = {"com.dts.freefireth":"Free Fire","com.dts.freefiremax":"Free Fire MAX","com.activision.callofduty.shooter":"Call of Duty Mobile","com.garena.game.codm":"CODM Garena","com.tencent.ig":"PUBG Mobile","com.pubg.imobile":"BGMI","com.pubg.krmobile":"PUBG KR","com.vng.pubgmobile":"PUBG VN","com.mobile.legends":"Mobile Legends","com.riotgames.league.wildrift":"Wild Rift","com.levelinfinite.sgameGlobal":"Honor of Kings","com.pokemon.unite":"Pokémon Unite","com.supercell.brawlstars":"Brawl Stars","com.supercell.clashofclans":"Clash of Clans","com.supercell.clashroyale":"Clash Royale","com.gameloft.android.ANMP.GloftA9HM":"Asphalt 9","com.konami.pesam":"eFootball","jp.konami.pesam":"eFootball","com.ea.gp.fifamobile":"FC Mobile","com.miHoYo.GenshinImpact":"Genshin Impact","com.HoYoverse.hkrpgoversea":"Honkai: Star Rail","com.kurogame.wutheringwaves.global":"Wuthering Waves","com.roblox.client":"Roblox","com.mojang.minecraftpe":"Minecraft","com.farlightgames.farlight84.gp":"Farlight 84","com.axlebolt.standoff2":"Standoff 2","com.criticalforceentertainment.criticalops":"Critical Ops","com.innersloth.spacemafia":"Among Us","com.kiloo.subwaysurf":"Subway Surfers","com.sega.pjsekai":"Project Sekai","com.garena.game.df":"Delta Force","com.blueteam.bloodstrike":"Blood Strike","com.netease.newspike":"Blood Strike","com.carxtech.sr":"CarX Street","com.firsttouchgames.dls7":"Dream League Soccer","com.tencent.lolm":"LoL Mobile","com.blizzard.diablo.immortal":"Diablo Immortal","com.netease.idv.googleplay":"Identity V","com.imangi.templerun2":"Temple Run 2","com.YoStarEN.Arknights":"Arknights","com.hypergryph.arknights":"Arknights"};
const gname = p => GAME_NAMES[p] || (p.split(".").pop().replace(/^\w/, c => c.toUpperCase()));
const hue = s => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };

/* ---------------- state ---------------- */
let S = { settings:{}, compat:{}, games:[], ingame:"", thermal:"", loop:false, backups:0 };
/* localStorage can be blocked on the ax:// scheme: never let it break the page */
const store = { m:{}, get(k){ try { return localStorage.getItem(k); } catch(e) { return this.m[k] || null; } }, set(k, v){ this.m[k] = v; try { localStorage.setItem(k, v); } catch(e) {} } };
let INFO = {}, L, LANG = "pt", TAB = store.get("vg_tab") || "games", busy = false;

/* ---------------- exec ---------------- */
let cbn = 0, QUEUE = Promise.resolve();
/* ksu.exec blocks the page while the shell runs: run one at a time, after the UI has painted */
const paint = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 20)));
function exec(cmd) {
  const p = QUEUE.then(paint).then(() => execNow(cmd));
  QUEUE = p.catch(() => {});
  return p;
}
function execNow(cmd) {
  return new Promise(res => {
    if (!HAS_API) return res({ errno:0, stdout:demo(cmd), stderr:"" });
    const n = "__vg" + (cbn++) + "_" + Date.now();
    let done = false;
    const fin = r => { if (done) return; done = true; delete window[n]; res(r); };
    window[n] = (e, o, er) => fin({ errno:e, stdout:o || "", stderr:er || "" });
    setTimeout(() => fin({ errno:124, stdout:"", stderr:"timeout" }), 150000);
    /* AxManager runs: sh -c "<cmd>" (naive double quotes), so quotes and $ would break/expand early.
       Send the script base64-encoded: only [A-Za-z0-9+/=] crosses that boundary. */
    const b64 = btoa(unescape(encodeURIComponent(cmd)));
    const wrapped = "echo " + b64 + " | base64 -d | sh";
    try { ksu.exec(wrapped, MODDIR_JS ? JSON.stringify({cwd: MODDIR_JS}) : "{}", n); } catch (x) { fin({ errno:1, stdout:"", stderr:String(x) }); }
  });
}
let LASTERR = "";
async function core(args) {
  const r = await exec(`${CORE} ${args}`);
  LASTERR = r.stderr || (r.errno ? "exit " + r.errno : "");
  return r.stdout || "";
}
async function coreJ(args) {
  const out = await core(args);
  const a = out.indexOf("{"), b = out.lastIndexOf("}");
  try { const j = JSON.parse(out.slice(a, b + 1)); if (j.settings) S = j; return j; }
  catch (e) { toast("⚠ " + (LASTERR || out || "no output").toString().slice(0, 140)); return null; }
}

/* ---------------- i18n ---------------- */
function pickLang() {
  const saved = store.get("vg_lang");
  if (saved && I18N[saved]) return saved;
  const n = (navigator.language || "en").toLowerCase();
  if (n.startsWith("pt")) return "pt"; if (n.startsWith("es")) return "es";
  if (n.startsWith("id") || n.startsWith("in")) return "id"; return "en";
}
const t = (k, v) => { let s = k.split(".").reduce((o, p) => o && o[p], L) ?? k; if (v) for (const x in v) s = s.replace("{" + x + "}", v[x]); return s; };
function applyLang() {
  L = I18N[LANG]; document.documentElement.lang = LANG;
  document.getElementById("langCode").textContent = LANG.toUpperCase();
  document.querySelectorAll("[data-t]").forEach(e => e.textContent = t(e.dataset.t));
}

/* ---------------- ui helpers ---------------- */
const $ = id => document.getElementById(id);
function toast(m) {
  if (HAS_API && ksu.toast) { try { ksu.toast(m); return; } catch(e){} }
  const el = $("toast"); el.textContent = m; el.classList.add("on");
  clearTimeout(toast.h); toast.h = setTimeout(() => el.classList.remove("on"), 2200);
}
function sheet(html) { $("sheetBody").innerHTML = html; $("sheet").classList.add("on"); $("scrim").classList.add("on"); $("sheet").scrollTop = 0; }
function closeSheet() { $("sheet").classList.remove("on"); $("scrim").classList.remove("on"); }
$("scrim").onclick = closeSheet;
const vib = () => { try { navigator.vibrate && navigator.vibrate(12); } catch(e){} };
const okc = c => !c || S.compat[c] !== 0;
const segLabel = l => ({keep:t("keep"),off:t("off"),native:t("native"),light:t("light")}[l] || l);

function explain(id) {
  const f = L.f[id]; if (!f) return;
  sheet(`<div class="sh-ic">${svg(id)}</div><h3>${f[0]}</h3><div class="lead">${f[1]}</div>
    <div class="lbl">${t("why")}</div><p>${f[2]}</p>${f[3] ? `<div class="tipbox"><b>${t("tip")}</b>${f[3]}</div>` : ""}`);
}
function longPress(el, fn) {
  let tm, moved = false;
  el.addEventListener("touchstart", e => { moved = false; tm = setTimeout(() => { vib(); fn(); el.dataset.lp = 1; }, 480); }, { passive:true });
  el.addEventListener("touchmove", () => { moved = true; clearTimeout(tm); }, { passive:true });
  el.addEventListener("touchend", () => clearTimeout(tm));
  el.addEventListener("contextmenu", e => { e.preventDefault(); fn(); });
}

/* ---------------- render ---------------- */
function renderTabs() {
  $("tabs").innerHTML = TABS.map(x => `<button class="tab ${x.id === TAB ? "on" : ""}" data-tab="${x.id}">${svg(x.id)}${t("tabs." + x.id)}</button>`).join("");
  $("tabs").querySelectorAll(".tab").forEach(b => b.onclick = () => { TAB = b.dataset.tab; store.set("vg_tab", TAB); renderTabs(); renderPanels(true); window.scrollTo({ top: $("tabs").offsetTop - 70, behavior:"smooth" }); });
}
function fnRow(f) {
  const v = S.settings[f.id], ok = okc(f.c), tx = L.f[f.id];
  let ctrl = "", lit = false, col = "";
  if (f.seg) {
    lit = v && v !== "keep" && !(f.id === "scale" && v === "1.0") && v !== "0" || (f.id === "anim" && v === "0");
    col = " col";
    ctrl = `<div class="seg">${f.seg.map(([val, lab]) => `<button data-k="${f.id}" data-v="${val}" class="${v === val ? "on" : ""}">${segLabel(lab)}</button>`).join("")}</div>`;
  } else {
    lit = v === "1";
    ctrl = `<div class="sw ${lit ? "on" : ""}" data-k="${f.id}" data-act="${f.act || ""}"></div>`;
  }
  let extra = "";
  if (f.meter) {
    const th = parseInt(S.thermal || "0") || 0;
    extra = `<div style="flex-basis:100%;margin-left:50px"><div class="meter">${[0,1,2,3,4,5].map(i => `<i class="${i <= th ? (th >= 3 ? "hot" : "on") : ""}"></i>`).join("")}</div>
      <small style="font-size:11px;color:var(--dim)">${t("thermal_now")}: ${L.th[th] || L.th[0]}</small></div>`;
    col = " col";
  }
  return `<div class="fn${col}${lit && ok ? " lit" : ""}${ok ? "" : " locked"}" data-fn="${f.id}">
    <div class="fi">${svg(f.id)}</div>
    <div class="ft"><b>${tx[0]} <span class="info" data-i="${f.id}">i</span></b><small>${ok ? tx[1] : "🔒 " + t("locked")}</small></div>
    ${f.seg ? "" : ctrl}${f.seg ? ctrl : ""}${extra}</div>`;
}
function gamesBlock() {
  const g = S.games || [];
  const list = g.length ? g.map(x => {
    const sc = x.scale === "g" ? S.settings.scale : x.scale, fp = x.fps === "g" ? S.settings.fps : x.fps;
    const live = S.ingame === x.pkg;
    return `<div class="game" data-g="${x.pkg}">
      <div class="gav" style="background:linear-gradient(135deg,hsl(${hue(x.pkg)},70%,45%),hsl(${(hue(x.pkg)+50)%360},80%,35%))">${gname(x.pkg).slice(0,2).toUpperCase()}</div>
      <div class="gt"><b>${gname(x.pkg)}</b><small>${x.pkg}</small>
        <div class="gtags">${live ? `<span class="gtag live">● ${t("st_game")}</span>` : ""}<span class="gtag">${Math.round(parseFloat(sc) * 100)}%${x.scale === "g" ? "" : " ★"}</span><span class="gtag">${fp === "0" ? t("off") : fp + " FPS"}${x.fps === "g" ? "" : " ★"}</span></div></div>
      <span class="chev">${svg("chev")}</span></div>`;
  }).join("") : `<div class="empty">${t("no_games")}</div>`;
  return `<div class="btnrow"><button class="btn ghost" id="bScan">${svg("scan")}${t("scan")}</button><button class="btn" id="bAdd">${svg("plus")}${t("add")}</button></div>
    <div class="group">${list}</div>
    <div class="btnrow"><button class="btn ghost" id="bCompile">${svg("compile")}${t("compile_now")}</button></div>`;
}
function smartBlock() {
  return `<div class="group" style="margin-top:8px"><div class="fn" data-fn="recommend"><div class="fi">${svg("recommend")}</div>
    <div class="ft"><b>${L.f.recommend[0]} <span class="info" data-i="recommend">i</span></b><small>${INFO.gpu ? INFO.gpu : L.f.recommend[1]}</small></div>
    <button class="btn ghost" id="bRec2" style="padding:9px 12px">${svg("recommend")}</button></div></div>`;
}
function toolsBlock() {
  const names = { prop:"setprop debug", settings:"settings", devcfg:"device_config", gamemode:"Game Mode", gameset:"Scale / FPS", blur:"Blur", fixedperf:"Fixed perf", angle:"ANGLE", driver:"Game Driver", wm:"wm size", hz:"> 60 Hz", thermal:"Thermal", freezer:"Freezer", cached:"Cached procs", compile:"Compile" };
  const cl = Object.keys(names).map(k => `<div><span>${names[k]}</span><b class="${S.compat[k] === 0 ? "n" : "y"}">${S.compat[k] === 0 ? "✕" : "✓"}</b></div>`).join("");
  return `<div class="group"><div class="fn col" data-fn="compat"><div class="fi">${svg("compat")}</div>
      <div class="ft"><b>${L.f.compat[0]} <span class="info" data-i="compat">i</span></b><small>${t("compat_title")}</small></div>
      <div style="flex-basis:100%"><div class="clist">${cl}</div><div class="btnrow"><button class="btn ghost" id="bCompat">${svg("refresh")}${t("retest")}</button><button class="btn ghost" id="bLog">${svg("log")}${t("log")}</button></div></div></div>
    <div class="fn col" data-fn="restore"><div class="fi">${svg("restore")}</div>
      <div class="ft"><b>${L.f.restore[0]} <span class="info" data-i="restore">i</span></b><small>${t("backups", { n:S.backups || 0 })}</small></div>
      <div style="flex-basis:100%;margin-top:8px"><button class="btn danger full" id="bRestore">${svg("restore")}${t("restore_all")}</button></div></div></div>`;
}
function renderPanels(anim) {
  const tab = TABS.find(x => x.id === TAB);
  let h = "";
  for (const s of tab.sections) {
    h += `<div class="sec">${t("sec." + s.s)}</div>`;
    if (s.f) h += `<div class="group">${s.f.map(fnRow).join("")}</div>`;
    if (s.custom === "games") h += gamesBlock();
    if (s.custom === "smart") h += smartBlock();
    if (s.custom === "tools") h += toolsBlock();
  }
  const p = $("panels"); p.innerHTML = `<div class="panel on${anim ? " anim" : ""}">${h}</div>`;
  bindPanel(p);
}
/* quick taps: the switch flips at once, the shell call is debounced per key (last value wins) */
const SETQ = {}, WANT = {};
function setKey(k, v, row) {
  S.settings[k] = v; WANT[k] = v;
  if (!SETQ[k]) pending++;
  clearTimeout(SETQ[k]);
  SETQ[k] = setTimeout(async () => {
    const val = WANT[k];
    await coreJ(`set ${k} ${val}`);
    if (WANT[k] === val) { delete SETQ[k]; delete WANT[k]; pending = Math.max(0, pending - 1); }
    for (const x in WANT) S.settings[x] = WANT[x];   // keep taps not sent yet
    if (row && !SETQ[k]) syncRow(row, k);
    renderHero();
  }, 250);
}
function bindPanel(p) {
  p.querySelectorAll(".info").forEach(e => e.onclick = ev => { ev.stopPropagation(); explain(e.dataset.i); });
  p.querySelectorAll(".fn").forEach(e => longPress(e, () => explain(e.dataset.fn)));
  p.querySelectorAll(".sw").forEach(e => e.onclick = async ev => {
    ev.stopPropagation();
    const row = e.closest(".fn"); if (row.classList.contains("locked")) { toast(t("locked")); return; }
    if (row.dataset.lp) { delete row.dataset.lp; return; }
    vib(); const k = e.dataset.k, nv = e.classList.contains("on") ? "0" : "1";
    e.classList.toggle("on"); row.classList.toggle("lit");
    S.settings[k] = nv; renderHero();
    if (e.dataset.act === "weak") { const j = await coreJ(`weak ${nv === "1" ? "on" : "off"}`); if (j) { toast(nv === "1" ? t("weak_on") : t("weak_off")); refresh(); } }
    else setKey(k, nv, row);
  });
  p.querySelectorAll(".seg button").forEach(b => b.onclick = async ev => {
    ev.stopPropagation();
    const row = b.closest(".fn"); if (row.classList.contains("locked")) { toast(t("locked")); return; }
    vib(); b.parentNode.querySelectorAll("button").forEach(x => x.classList.remove("on")); b.classList.add("on");
    setKey(b.dataset.k, b.dataset.v, row); renderHero();
  });
  p.querySelectorAll(".game").forEach(g => g.onclick = () => gameSheet(g.dataset.g));
  const on = (id, fn) => { const e = $(id); if (e) e.onclick = fn; };
  on("bScan", async () => { toast(t("detecting")); const r = await coreJ("scan"); refresh(); if (r) toast(t("scan_done", { n:(r.games || []).length })); });
  on("bAdd", addSheet);
  on("bCompile", async () => { toast(t("compiling")); exec(`${CORE} compile >/dev/null 2>&1 &`); });
  on("bRec2", recommend);
  on("bCompat", async () => { await coreJ("compat"); refresh(); toast(t("tested")); });
  on("bLog", async () => { const l = (await core("log")).trim(); sheet(`<div class="sh-ic">${svg("log")}</div><h3>${t("log")}</h3><pre class="log">${(l || t("empty_log")).replace(/</g,"&lt;")}</pre>`); });
  on("bRestore", () => {
    sheet(`<div class="sh-ic" style="background:linear-gradient(135deg,#ff5c7a,#a2305a)">${svg("restore")}</div><h3>${t("restore_all")}</h3><p>${t("restore_q")}</p>
      <div class="btnrow" style="margin-top:18px"><button class="btn ghost" id="rNo">${t("cancel")}</button><button class="btn danger" id="rYes">${t("yes")}</button></div>`);
    $("rNo").onclick = closeSheet;
    $("rYes").onclick = async () => { closeSheet(); await coreJ("restore"); refresh(); toast(t("restore_ok")); };
  });
}
/* put a row back in line with the saved state (if saving failed, the switch flips back) */
function syncRow(row, k) {
  const v = S.settings[k];
  const sw = row.querySelector(".sw");
  if (sw) { sw.classList.toggle("on", v === "1"); row.classList.toggle("lit", v === "1"); }
  row.querySelectorAll(".seg button").forEach(b => b.classList.toggle("on", b.dataset.v === v));
  if (row.querySelector(".seg")) row.classList.toggle("lit", !!v && v !== "keep" && v !== "1.0" && !(k === "fps" && v === "0"));
}
function gameSheet(pkg) {
  const g = S.games.find(x => x.pkg === pkg); if (!g) return;
  let sc = g.scale, fp = g.fps;
  const segs = (arr, cur, key) => `<div class="seg" data-key="${key}"><button data-v="g" class="${cur === "g" ? "on" : ""}">${t("global")}</button>${arr.map(([v, l]) => `<button data-v="${v}" class="${cur === v ? "on" : ""}">${segLabel(l)}</button>`).join("")}</div>`;
  sheet(`<div class="sh-ic" style="background:linear-gradient(135deg,hsl(${hue(pkg)},70%,45%),hsl(${(hue(pkg)+50)%360},80%,35%));font-weight:800;font-size:18px">${gname(pkg).slice(0,2).toUpperCase()}</div>
    <h3>${gname(pkg)}</h3><div class="lead">${pkg} · ${t("per_game")}</div>
    <div class="lbl">${t("scale_lbl")}</div>${segs(SCALES.slice(0,4).concat([SCALES[4]]), sc, "s")}
    <div class="lbl">${t("fps_lbl")}</div>${segs(FPSV, fp, "f")}
    <div class="btnrow" style="margin-top:20px"><button class="btn danger" id="gDel">${svg("trash")}${t("remove")}</button><button class="btn" id="gSave">${t("save")}</button></div>`);
  document.querySelectorAll("#sheetBody .seg").forEach(sg => sg.querySelectorAll("button").forEach(b => b.onclick = () => {
    sg.querySelectorAll("button").forEach(x => x.classList.remove("on")); b.classList.add("on");
    if (sg.dataset.key === "s") sc = b.dataset.v; else fp = b.dataset.v;
  }));
  $("gSave").onclick = async () => { closeSheet(); await coreJ(`gset ${pkg} ${sc} ${fp}`); refresh(); toast(t("saved")); };
  $("gDel").onclick = async () => { closeSheet(); await coreJ(`gdel ${pkg}`); refresh(); };
}
async function addSheet() {
  sheet(`<div class="sh-ic">${svg("plus")}</div><h3>${t("add")}</h3><input class="searchbox" id="q" placeholder="${t("search")}">
    <div class="seg" id="af" style="margin-bottom:10px"><button data-a="0" class="on">${t("only_games")}</button><button data-a="1">${t("show_all")}</button></div>
    <div class="applist" id="al"><div class="empty">${t("detecting")}</div></div>`);
  let apps = [], all = false, q = "";
  try { apps = JSON.parse((await core("apps")).trim()).map(x => typeof x === "string" ? { p:x, g:0 } : x); } catch(e) {}
  const have = new Set(S.games.map(x => x.pkg));
  const draw = () => {
    const list = apps.filter(a => !have.has(a.p) && (all || a.g) && (!q || a.p.toLowerCase().includes(q) || gname(a.p).toLowerCase().includes(q))).slice(0, 150);
    $("al").innerHTML = list.map(a => `<button data-p="${a.p}"><b>${a.g ? "🎮 " : ""}${gname(a.p)}</b><small>${a.p}</small></button>`).join("")
      || `<div class="empty">${all || q ? "—" : t("no_games")}</div>`;
    $("al").querySelectorAll("button").forEach(b => b.onclick = async () => { closeSheet(); await coreJ(`gadd ${b.dataset.p}`); refresh(); toast(t("saved")); });
  };
  document.querySelectorAll("#af button").forEach(b => b.onclick = () => { all = b.dataset.a === "1"; document.querySelectorAll("#af button").forEach(x => x.classList.toggle("on", x === b)); draw(); });
  draw(); $("q").oninput = e => { q = e.target.value.toLowerCase().trim(); draw(); };
}
function langSheet() {
  sheet(`<div class="sh-ic">${'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>'}</div><h3>${t("lang")}</h3>
    <div class="langs" style="margin-top:12px">${Object.keys(I18N).map(k => `<button data-l="${k}" class="${k === LANG ? "on" : ""}">${I18N[k]._name}</button>`).join("")}</div>`);
  document.querySelectorAll(".langs button").forEach(b => b.onclick = () => { LANG = b.dataset.l; store.set("vg_lang", LANG); core(`setq lang ${LANG}`); closeSheet(); applyLang(); refresh(); });
}
$("langBtn").onclick = langSheet;

async function recommend() { vib(); await coreJ("recommend"); refresh(); toast(t("rec_done")); }
$("recBtn").onclick = recommend;

/* ---------------- hero ---------------- */
function renderHero() {
  const on = S.settings.enabled === "1";
  const p = $("power"); p.classList.toggle("on", on); p.classList.toggle("busy", busy);
  $("powerTxt").textContent = busy ? "···" : (on ? t("active") : t("activate"));
  const n = COUNTED.filter(k => { const v = S.settings[k]; const f = TABS.flatMap(x => x.sections).flatMap(s => s.f || []).find(x => x.id === k);
    if (f && !okc(f.c)) return false; if (k === "scale") return v && v !== "1.0"; if (k === "fps") return v && v !== "0"; return v === "1" || (v && v !== "0" && v !== "keep" && isNaN(+v)) || (k === "anim" && (v === "0" || v === "0.5")); }).length;
  $("powerSub").textContent = busy ? t("activating") : !on ? t("sub_off") : S.ingame ? t("sub_game", { g:gname(S.ingame) }) : t("sub_on", { n });
  const pill = $("pill"); pill.className = "pill" + (on ? (S.ingame ? " game" : " on") : "");
  $("pillTxt").textContent = !HAS_API ? t("st_noapi") : !on ? t("st_off") : S.ingame ? t("st_game") : t("st_on");
  const g = S.ingame && S.games.find(x => x.pkg === S.ingame);
  const sc = g && g.scale !== "g" ? g.scale : S.settings.scale, fp = g && g.fps !== "g" ? g.fps : S.settings.fps;
  $("sFps").textContent = fp && fp !== "0" ? fp : "—";
  $("sScale").textContent = sc ? Math.round(parseFloat(sc) * 100) + "%" : "—";
  const th = parseInt(S.thermal || "0") || 0; $("sTherm").textContent = L.th[th];
  $("sTherm").style.color = th >= 3 ? "var(--bad)" : th >= 1 ? "var(--warn)" : "var(--ok)";
  $("bkCount").textContent = t("backups", { n:S.backups || 0 });
}
$("power").onclick = async () => {
  if (busy) return; busy = true; vib(); renderHero();
  const guard = setTimeout(() => { busy = false; renderHero(); }, 45000);
  await coreJ(S.settings.enabled === "1" ? "disable" : "enable");
  clearTimeout(guard); busy = false; refresh();
};
function renderDevice() {
  $("dModel").textContent = (INFO.brand ? INFO.brand.charAt(0).toUpperCase() + INFO.brand.slice(1) + " " : "") + (INFO.model || "Android");
  $("dGpu").textContent = INFO.gpu || "—";
  $("vendorIcon").textContent = ({ adreno:"ADR", mali:"MALI", powervr:"PVR", xclipse:"XCL" })[INFO.vendor] || "GPU";
  const tr = $("dTier"); tr.className = "tier " + (INFO.tier || "mid"); tr.textContent = t("tier_" + (INFO.tier || "mid"));
  $("dRam").textContent = INFO.ram ? INFO.ram + " GB" : "—";
  $("dHz").textContent = INFO.hz ? INFO.hz + " Hz" : "—";
  $("dRes").textContent = INFO.size ? INFO.size.replace("x", "×") : "—";
  $("dAnd").textContent = INFO.android || "—";
}
function refresh() { renderHero(); renderPanels(); }

/* ---------------- demo (browser preview) ---------------- */
let DM = null;
function demo(cmd) {
  if (!DM) DM = { settings:{enabled:"1",renderer:"skiavk",nomsaa:"1",debugclean:"1",noblur:"1",anim:"0.5",refresh:"1",resolution:"keep",gamemode:"1",scale:"0.9",fps:"90",driver:"1",angle:"0",gminrefresh:"1",fixedperf:"1",nosaver:"1",compile:"1",freeram:"1",freezer:"0",cached:"0",thermal:"1",weak:"0",autodetect:"1",lang:"auto"},
    compat:{prop:1,settings:1,devcfg:1,gamemode:1,gameset:1,blur:1,fixedperf:1,angle:1,driver:1,wm:1,hz:1,thermal:1,freezer:1,cached:1,compile:1},
    games:[{pkg:"com.dts.freefireth",scale:"g",fps:"g"},{pkg:"com.activision.callofduty.shooter",scale:"0.8",fps:"60"},{pkg:"com.mobile.legends",scale:"g",fps:"120"}], ingame:"com.dts.freefireth", thermal:"1", loop:true, backups:21 };
  const a = cmd.split('core.sh" ').pop() || "";
  const [c, k, v, w] = a.split(" ");
  if (c === "info") return JSON.stringify({model:"Redmi Note 13 Pro",brand:"xiaomi",android:"14",sdk:"34",gpu:"Qualcomm, Adreno (TM) 710, OpenGL ES 3.2",vendor:"adreno",tier:"mid",ram:"8",hz:"120",size:"1220x2712",rec:"skiavk"});
  if (c === "apps") return JSON.stringify([{p:"com.supercell.brawlstars",g:1},{p:"com.roblox.client",g:1},{p:"com.whatsapp",g:0},{p:"com.spotify.music",g:0}]);
  if (c === "log") return "10-11 09:12:01 game on: com.dts.freefireth\n10-11 09:12:02 compiled com.dts.freefireth\n10-11 09:31:40 thermal 2 step 1 scale 0.8 fps 60";
  if (c === "set") DM.settings[k] = v;
  if (c === "enable") DM.settings.enabled = "1"; if (c === "disable") DM.settings.enabled = "0";
  if (c === "gadd") DM.games.push({ pkg:k, scale:"g", fps:"g" });
  if (c === "gdel") DM.games = DM.games.filter(x => x.pkg !== k);
  if (c === "gset") { const g = DM.games.find(x => x.pkg === k); if (g) { g.scale = v; g.fps = w; } }
  if (c === "weak") DM.settings.weak = k === "on" ? "1" : "0";
  return JSON.stringify(DM);
}

/* status / info are published by core.sh as files in webroot: fetch() never blocks the page */
async function fetchJ(name) {
  if (!HAS_API) return null;
  try { const r = await fetch(name + "?t=" + Date.now(), { cache:"no-store" }); if (!r.ok) return null; const j = JSON.parse(await r.text()); return j; } catch(e) { return null; }
}
async function pullState() {
  const j = await fetchJ("state.json");
  if (j && j.settings) { S = j; return true; }
  return false;
}
let pending = 0;
/* ---------------- boot ---------------- */
(async () => {
  if (HAS_API && ksu.fullScreen) { try { ksu.fullScreen(true); } catch(e){} }
  LANG = pickLang(); applyLang(); renderTabs();
  if (!(await pullState())) await coreJ("status");
  if (S.settings.lang && S.settings.lang !== "auto" && I18N[S.settings.lang] && !store.get("vg_lang")) { LANG = S.settings.lang; applyLang(); renderTabs(); }
  refresh();
  INFO = (await fetchJ("info.json")) || {};
  if (!INFO.model) { try { INFO = JSON.parse((await core("info")).trim()); } catch(e) {} }
  renderDevice(); renderPanels();
  let miss = 0;
  setInterval(async () => {
    if (busy || pending || document.hidden || $("sheet").classList.contains("on")) return;
    const old = S.ingame + S.thermal;
    if (await pullState()) miss = 0; else if (++miss % 4 === 0) await coreJ("status"); else return;
    renderHero(); if (old !== S.ingame + S.thermal) renderPanels();
  }, 3000);
})();
})();
