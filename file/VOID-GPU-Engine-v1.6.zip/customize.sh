SKIPUNZIP=0
ui_print " "
ui_print "  ██╗   ██╗ ██████╗ ██╗██████╗ "
ui_print "  ██║   ██║██╔═══██╗██║██╔══██╗"
ui_print "  ╚██╗ ██╔╝██║   ██║██║██║  ██║"
ui_print "   ╚████╔╝ ╚██████╔╝██║██████╔╝"
ui_print "    ╚═══╝   ╚═════╝ ╚═╝╚═════╝ "
ui_print "        GPU ENGINE  v1.6"
ui_print "     ADB only - no root needed"
ui_print " "
[ "$API" -lt 26 ] && abort "! Android 8.0 or newer is required"
ui_print "- Device : $(getprop ro.product.model) (Android $(getprop ro.build.version.release))"
for f in core.sh service.sh action.sh uninstall.sh system/bin/vgpu; do
  [ -f "$MODPATH/$f" ] && chmod 0755 "$MODPATH/$f"
done
ui_print "- Testing what this device accepts..."
MODDIR=$MODPATH sh "$MODPATH/core.sh" compat >/dev/null 2>&1
MODDIR=$MODPATH sh "$MODPATH/core.sh" scan >/dev/null 2>&1
G=$(MODDIR=$MODPATH sh "$MODPATH/core.sh" info 2>/dev/null | sed 's/.*"gpu":"\([^"]*\)".*/\1/')
ui_print "- GPU    : $G"
ui_print "- Done. Open the WebUI and tap ACTIVATE."
ui_print " "
