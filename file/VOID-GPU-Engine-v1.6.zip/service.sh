#!/system/bin/sh
MODDIR=${0%/*}
# wait for the system to settle after boot / AxManager start
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 2; done
sleep 8
MODDIR=$MODDIR nohup sh "$MODDIR/core.sh" boot >/dev/null 2>&1 &
