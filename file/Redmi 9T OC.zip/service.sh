#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done

for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    chmod 644 "$cpu/scaling_governor" 2>/dev/null
    echo "performance" > "$cpu/scaling_governor" 2>/dev/null
    if [ -f "$cpu/cpuinfo_max_freq" ]; then
        MAX_FREQ=$(cat "$cpu/cpuinfo_max_freq")
        chmod 644 "$cpu/scaling_min_freq" 2>/dev/null
        echo "$MAX_FREQ" > "$cpu/scaling_min_freq" 2>/dev/null
    fi
done

GPU_PATH="/sys/class/kgsl/kgsl-3d0"
if [ -d "$GPU_PATH" ]; then
    chmod 644 $GPU_PATH/devfreq/governor 2>/dev/null
    echo "performance" > $GPU_PATH/devfreq/governor 2>/dev/null
    echo "0" > $GPU_PATH/bus_split 2>/dev/null
    echo "1" > $GPU_PATH/force_clk_on 2>/dev/null
    echo "10000" > $GPU_PATH/idle_timer 2>/dev/null
fi

stop mi_thermald 2>/dev/null
stop thermal-engine 2>/dev/null
stop thermald 2>/dev/null
stop vendor.thermal-engine 2>/dev/null
stop vendor.thermal-hal-1-0 2>/dev/null
stop vendor.thermal-hal-2-0 2>/dev/null
stop vendor.thermal-hal-2-0-qti 2>/dev/null
stop android.hardware.thermal@1.0-service 2>/dev/null
stop android.hardware.thermal@2.0-service.qti 2>/dev/null

if [ -d /sys/module/msm_thermal/parameters ]; then
    echo "0" > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
    echo "0" > /sys/module/msm_thermal/parameters/core_control 2>/dev/null
    echo "0" > /sys/module/msm_thermal/parameters/freq_mitigation 2>/dev/null
fi

for zone in /sys/class/thermal/thermal_zone*; do
    if [ -f "$zone/mode" ]; then
        chmod 666 "$zone/mode" 2>/dev/null
        echo "disabled" > "$zone/mode" 2>/dev/null
        chmod 444 "$zone/mode" 2>/dev/null
    fi
done