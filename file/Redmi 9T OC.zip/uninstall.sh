#!/system/bin/sh
for cpu in /sys/devices/system/cpu/cpu*/cpufreq; do
    chmod 644 "$cpu/scaling_governor" 2>/dev/null
    echo "schedutil" > "$cpu/scaling_governor" 2>/dev/null
done

GPU_PATH="/sys/class/kgsl/kgsl-3d0"
if [ -d "$GPU_PATH" ]; then
    chmod 644 $GPU_PATH/devfreq/governor 2>/dev/null
    echo "msm-adreno-tz" > $GPU_PATH/devfreq/governor 2>/dev/null
    echo "0" > $GPU_PATH/force_clk_on 2>/dev/null
fi

if [ -d /sys/module/msm_thermal/parameters ]; then
    echo "1" > /sys/module/msm_thermal/parameters/enabled 2>/dev/null
    echo "1" > /sys/module/msm_thermal/parameters/core_control 2>/dev/null
    echo "1" > /sys/module/msm_thermal/parameters/freq_mitigation 2>/dev/null
fi

for zone in /sys/class/thermal/thermal_zone*; do
    if [ -f "$zone/mode" ]; then
        chmod 666 "$zone/mode" 2>/dev/null
        echo "enabled" > "$zone/mode" 2>/dev/null
    fi
done