#!/system/bin/sh
SKIPUNZIP=0

ui_print "-------------------------------------------"
ui_print "   REDMI 9T OC & THERMAL DISABLER     "
ui_print "       Target: Snapdragon 662 (lime)       "
ui_print "-------------------------------------------"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755

ui_print "- Izin direktori dan skrip disiapkan."
ui_print "- Instalasi modul selesai!"