#!/system/bin/sh
# Pemakaian: apply.sh <hemat|seimbang|performa|gaming>
SELF=$(cd "${0%/*}" && pwd)
MODDIR=$(cd "$SELF/.." && pwd)
. "$SELF/common.sh"
P=$1
if [ ! -f "$MODDIR/profiles/$P.sh" ]; then echo "Profil tidak ada: $P"; exit 1; fi
restore_all
. "$MODDIR/profiles/$P.sh"
echo "PROFILE=$P" > "$MODDIR/config.txt"
echo "Profil '$P' diterapkan."
