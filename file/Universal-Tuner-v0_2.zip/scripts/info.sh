#!/system/bin/sh
# Menampilkan jalur dan nilai yang tersedia di HP ini (untuk membantu mengisi profil).
echo "Platform: $(getprop ro.board.platform) | Kernel: $(uname -r)"
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  echo ""; echo "== $(basename $p)"
  echo "governor : $(cat $p/scaling_governor 2>/dev/null)"
  echo "tersedia : $(cat $p/scaling_available_governors 2>/dev/null)"
  echo "min/max  : $(cat $p/scaling_min_freq 2>/dev/null) / $(cat $p/scaling_max_freq 2>/dev/null)"
  echo "frekuensi: $(cat $p/scaling_available_frequencies 2>/dev/null)"
done
echo ""; echo "== GPU (devfreq)"
for d in /sys/class/devfreq/*; do
  [ -d "$d" ] || continue
  echo "$(basename $d): cur=$(cat $d/cur_freq 2>/dev/null) tersedia=$(cat $d/available_frequencies 2>/dev/null)"
done
echo ""; echo "== Jalur GPU/performa umum (ada/tidak)"
for x in /sys/class/kgsl/kgsl-3d0 /sys/kernel/gpu /sys/kernel/ged/hal /proc/gpufreq /proc/gpufreqv2 /proc/ppm /sys/devices/platform/mali /sys/module/mali; do
  if [ -e "$x" ]; then echo "ada   : $x"; else echo "tidak : $x"; fi
done
echo ""; echo "== Penyimpanan & memori"
echo "swappiness: $(cat /proc/sys/vm/swappiness 2>/dev/null)"
for q in /sys/block/mmcblk*/queue /sys/block/sd*/queue; do
  [ -d "$q" ] && echo "$q read_ahead_kb=$(cat $q/read_ahead_kb 2>/dev/null) scheduler=$(cat $q/scheduler 2>/dev/null)"
done
echo ""; echo "== Suhu (dalam miliderajat)"
for z in /sys/class/thermal/thermal_zone*; do
  echo "$(cat $z/type 2>/dev/null): $(cat $z/temp 2>/dev/null)"
done | head -n 15
