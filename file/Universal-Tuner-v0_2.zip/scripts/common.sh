#!/system/bin/sh
# Fungsi bersama. Dipanggil dengan: . common.sh
# MODDIR diisi oleh skrip pemanggil (apply.sh / uninstall.sh).
[ -n "$MODDIR" ] || MODDIR=/data/adb/modules/universal_tuner
BK="$MODDIR/backup"
mkdir -p "$BK" 2>/dev/null

# w <nilai> <berkas> : simpan nilai asli (sekali), lalu tulis nilai baru.
# Jalur yang tidak ada atau tidak bisa ditulis dilewati tanpa error.
w() {
  [ -w "$2" ] || return 1
  n=$(echo "$2" | sed 's#/#@#g')
  [ -f "$BK/$n" ] || cat "$2" > "$BK/$n" 2>/dev/null
  echo "$1" > "$2" 2>/dev/null
}

# cap <folder policy> <persen> : batasi frekuensi maksimum CPU ke persen tertentu
cap() {
  p=$1; pct=$2
  mx=$(cat "$p/cpuinfo_max_freq" 2>/dev/null)
  [ -n "$mx" ] || return 1
  t=$((mx * pct / 100)); best=""
  for f in $(cat "$p/scaling_available_frequencies" 2>/dev/null); do
    if [ "$f" -le "$t" ] && { [ -z "$best" ] || [ "$f" -gt "$best" ]; }; then best=$f; fi
  done
  [ -n "$best" ] && w "$best" "$p/scaling_max_freq"
}

# floor <folder policy> <persen> : naikkan frekuensi minimum CPU ke persen tertentu
# (tidak akan melebihi frekuensi maksimum yang sedang aktif)
floor() {
  p=$1; pct=$2
  mx=$(cat "$p/cpuinfo_max_freq" 2>/dev/null)
  cur=$(cat "$p/scaling_max_freq" 2>/dev/null)
  [ -n "$mx" ] && [ -n "$cur" ] || return 1
  t=$((mx * pct / 100)); best=""
  for f in $(cat "$p/scaling_available_frequencies" 2>/dev/null); do
    if [ "$f" -ge "$t" ] && [ "$f" -le "$cur" ] && { [ -z "$best" ] || [ "$f" -lt "$best" ]; }; then best=$f; fi
  done
  [ -n "$best" ] && w "$best" "$p/scaling_min_freq"
}

# readahead <kb> : atur read-ahead penyimpanan internal
readahead() {
  for q in /sys/block/mmcblk*/queue/read_ahead_kb /sys/block/sd*/queue/read_ahead_kb /sys/block/sd*/queue/read_ahead_kb; do
    w "$1" "$q"
  done
}

# restore_all : kembalikan semua nilai yang pernah diubah modul
restore_all() {
  for f in "$BK"/*; do
    [ -f "$f" ] || continue
    path=$(basename "$f" | sed 's#@#/#g')
    [ -w "$path" ] && cat "$f" > "$path" 2>/dev/null
  done
}
