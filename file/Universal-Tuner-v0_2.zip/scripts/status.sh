#!/system/bin/sh
SELF=$(cd "${0%/*}" && pwd)
MODDIR=$(cd "$SELF/.." && pwd)
PROFILE=seimbang
. "$MODDIR/config.txt" 2>/dev/null
echo "Profil aktif: $PROFILE"
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p" ] || continue
  echo "$(basename $p): $(cat $p/scaling_cur_freq 2>/dev/null) kHz (maks $(cat $p/scaling_max_freq 2>/dev/null))"
done
t=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
[ -n "$t" ] && echo "Suhu baterai: $((t / 10)) C"
