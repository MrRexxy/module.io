# Universal Tuner (v0.2)
Profil: Hemat (CPU maks 70%), Seimbang (bawaan), Performa (min CPU 35%), Gaming (min CPU 50%).
Berjalan di Snapdragon, MediaTek, dan Exynos selama kernel menyediakan cpufreq. Pengaturan GPU tidak diubah.
WebUI bergaya ModulHub. Tulisan "Dibuat oleh" dibaca dari baris author di module.prop.
Edit berkas di folder profiles/ memakai fungsi w, cap, floor, dan readahead dari scripts/common.sh.
Belum diuji di perangkat asli. Cadangkan data dan siapkan cara pulih sebelum memasang.
