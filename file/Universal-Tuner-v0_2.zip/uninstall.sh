#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/scripts/common.sh"
restore_all
