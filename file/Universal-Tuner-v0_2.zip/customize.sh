#!/system/bin/sh
ui_print "- Universal Tuner v0.1"
ui_print "- Platform: $(getprop ro.board.platform) | Android $(getprop ro.build.version.release)"
if [ ! -d /sys/devices/system/cpu/cpufreq ]; then
  ui_print "! Peringatan: pengaturan frekuensi CPU (cpufreq) tidak ditemukan."
  ui_print "! Sebagian profil mungkin tidak berpengaruh di perangkat ini."
fi
ui_print "- Mengatur izin berkas"
set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm_recursive "$MODPATH/profiles" 0 0 0755 0644
ui_print "- Selesai. Mulai ulang, lalu buka WebUI dari aplikasi root-mu."
