# Hemat: batasi frekuensi maksimum semua cluster CPU ke 70%.
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  cap "$p" 70
done
