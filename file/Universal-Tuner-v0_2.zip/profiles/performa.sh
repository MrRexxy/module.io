# Performa (konservatif): naikkan frekuensi minimum CPU ke 35% dan perbesar read-ahead.
# Efeknya: respons lebih cepat, baterai sedikit lebih boros.
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  floor "$p" 35
done
readahead 256
