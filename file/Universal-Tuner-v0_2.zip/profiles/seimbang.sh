# Seimbang = bawaan HP. Semua nilai dikembalikan oleh apply.sh sebelum berkas ini dipanggil.
