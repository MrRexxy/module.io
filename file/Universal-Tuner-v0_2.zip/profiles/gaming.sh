# Gaming: frekuensi minimum CPU 50% dan read-ahead lebih besar.
# Efeknya: lag naik frekuensi berkurang, tapi baterai lebih boros dan HP lebih cepat panas.
# Untuk GPU, tambahkan sendiri setelah mengecek jalurnya lewat "Info perangkat":
#   w <nilai> <berkas>     (nilai asli otomatis dicadangkan)
# Jangan menonaktifkan pembatas suhu (thermal), karena berisiko merusak perangkat.
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  floor "$p" 50
done
readahead 512
