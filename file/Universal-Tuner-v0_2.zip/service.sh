#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
sleep 20
PROFILE=seimbang
. "$MODDIR/config.txt" 2>/dev/null
sh "$MODDIR/scripts/apply.sh" "$PROFILE" >/dev/null 2>&1
