#!/system/bin/sh
MODDIR=${0%/*}
LOG=/data/local/tmp/lime_smooth.log
. "$MODDIR/config.conf"

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 5; done
sleep 30

echo "== Lime Smooth UI $(date) ==" > "$LOG"

w() {
  if [ -w "$1" ]; then
    echo "$2" > "$1" 2>/dev/null && echo "OK   $1 = $2" >> "$LOG" || echo "FAIL $1" >> "$LOG"
  else
    echo "SKIP $1 (tidak ada/tidak writable)" >> "$LOG"
  fi
}

# ---------- Animasi & sentuhan (settings) ----------
for k in window_animation_scale transition_animation_scale animator_duration_scale; do
  settings put global "$k" "$ANIM_SCALE" && echo "OK   settings global $k = $ANIM_SCALE" >> "$LOG"
done
if [ "$LONG_PRESS_MS" -gt 0 ] 2>/dev/null; then
  settings put secure long_press_timeout "$LONG_PRESS_MS" && echo "OK   long_press_timeout = $LONG_PRESS_MS" >> "$LOG"
fi

# ---------- schedutil rate limit ----------
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -d "$p/schedutil" ] || continue
  [ "$UP_RATE_US" -gt 0 ]   2>/dev/null && w "$p/schedutil/up_rate_limit_us"   "$UP_RATE_US"
  [ "$DOWN_RATE_US" -gt 0 ] 2>/dev/null && w "$p/schedutil/down_rate_limit_us" "$DOWN_RATE_US"
done

# ---------- Input boost (qcom cpu_boost, bila ada) ----------
if [ "$INPUT_BOOST_MS" -gt 0 ] 2>/dev/null; then
  w /sys/module/cpu_boost/parameters/input_boost_ms "$INPUT_BOOST_MS"
fi

# ---------- schedtune top-app (kernel 4.14), bila ada ----------
ST=/dev/stune/top-app
if [ -d "$ST" ]; then
  [ "$TOPAPP_BOOST" -ge 0 ] 2>/dev/null && w "$ST/schedtune.boost" "$TOPAPP_BOOST"
  w "$ST/schedtune.prefer_idle" "$TOPAPP_PREFER_IDLE"
else
  echo "SKIP schedtune: $ST tidak ada" >> "$LOG"
fi

# ---------- VM ----------
[ "$VFS_CACHE_PRESSURE" -gt 0 ] 2>/dev/null && w /proc/sys/vm/vfs_cache_pressure "$VFS_CACHE_PRESSURE"

# ---------- Kunci 60 Hz ----------
if [ "$LOCK_60HZ" = "1" ]; then
  settings put system peak_refresh_rate 60.0 && echo "OK   peak_refresh_rate = 60.0" >> "$LOG"
  settings put system min_refresh_rate 60.0  && echo "OK   min_refresh_rate = 60.0" >> "$LOG"
fi

echo "== selesai ==" >> "$LOG"
