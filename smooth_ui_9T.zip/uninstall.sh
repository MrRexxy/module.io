#!/system/bin/sh
# Kembalikan nilai bawaan saat modul dihapus
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings put secure long_press_timeout 400
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
rm -f /data/local/tmp/lime_smooth.log
