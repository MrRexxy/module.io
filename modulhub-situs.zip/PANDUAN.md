# Panduan Memasang ModulHub di GitHub Pages

Isi paket ini:

- `situs/index.html` : tampilan situs (tidak perlu diubah)
- `situs/data.json`  : daftar modul dan plugin (ini yang kamu edit)
- `situs/files/`     : file .zip modul (sudah berisi 3 modul pertamamu)

## A. Memasang situs (sekali saja)

1. Buat akun di https://github.com lalu buat repositori baru, misalnya `modulhub`. Pilih **Public**.
2. Di halaman repositori, tekan **Add file > Upload files**.
3. Unggah isi folder `situs` (`index.html`, `data.json`, dan folder `files`). Tekan **Commit changes**.
4. Buka **Settings > Pages**. Pada "Branch" pilih `main` dan folder `/ (root)`, lalu **Save**.
5. Tunggu sekitar 1-2 menit. Alamat situsmu akan muncul di halaman yang sama, bentuknya `https://namakamu.github.io/modulhub/`.

Catatan: situs tidak bisa dibuka dengan klik dua kali `index.html` dari penyimpanan HP/komputer, karena data dibaca lewat `data.json`. Buka lewat alamat GitHub Pages.

Tiga modul pertama (AOSP Enhancer, Lime Extra Smooth, Lime Smooth UI) sudah terpasang di `data.json` dan folder `files`.

## B. Menambah modul baru (setiap kali update)

1. Buka repositori, masuk ke folder `files`, tekan **Add file > Upload files**, unggah file .zip modul (maksimal 100 MB per file).
2. Buka `data.json`, tekan ikon pensil (Edit), lalu tambahkan satu entri baru di dalam daftar `modul`:

```
{
  "name": "Nama Modul",
  "cat": "Sistem",
  "ver": "v1.0",
  "android": "8.0+",
  "desc": "Penjelasan singkat modul.",
  "size": "1.2 MB",
  "log": "Catatan perubahan versi ini.",
  "file": "files/nama-modul-v1.0.zip"
}
```

3. Tekan **Commit changes**. Situs diperbarui dalam 1-2 menit.

Aturan penting di `data.json`:
- Setiap entri dipisah koma, kecuali entri terakhir.
- Semua teks memakai tanda kutip dua.
- Nama file di `"file"` harus sama persis dengan file di folder `files`, termasuk huruf besar-kecilnya. Hindari spasi di nama file.

## C. Menambah plugin AX Manager

Sama seperti modul, tetapi tambahkan entri di daftar `plugin`. Plugin boleh punya satu kolom tambahan:

```
"axmin": "v1.0+"
```

(versi AX Manager minimal yang dibutuhkan)

## D. Arti tiap kolom

| Kolom   | Fungsi |
|---------|--------|
| name    | Nama yang tampil di kartu |
| cat     | Kategori untuk tombol filter (kategori baru muncul otomatis) |
| ver     | Versi |
| android | Versi Android minimal |
| desc    | Penjelasan singkat |
| size    | Ukuran file (hanya tampilan) |
| log     | Catatan perubahan |
| file    | Lokasi file .zip di situs ini, misalnya `files/modul.zip` |
| url     | Opsional. Tautan ke situs lain, dipakai kalau `file` kosong |

Kalau `file` dan `url` sama-sama kosong, tombol menampilkan "Segera hadir".

## E. Hal lain

- **Tautan donasi:** di `data.json`, isi `"donasi": ""` dengan tautan Saweria atau Trakteer milikmu. Selama kosong, bagian donasi disembunyikan.
- **Kolom `android` dan `author`:** `android` boleh dikosongkan (tidak tampil). `author` opsional dan tampil sebagai "Pembuat" di jendela Detail. Kolom `android` di tiga modul awal masih kosong, isi sesuai versi Android yang didukung.
- **Nama situs:** cari teks `ModulHub` di `index.html` dan ganti sesuai keinginan.
- **Alamat sendiri (opsional):** di Settings > Pages kamu bisa menyambungkan domain milik sendiri.
- Hanya unggah modul yang memang boleh kamu bagikan (buatanmu sendiri atau berlisensi terbuka), dan cantumkan sumber aslinya.
